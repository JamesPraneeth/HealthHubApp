using System;
using System.Windows.Controls;

namespace HealthHub.App.Views
{
    /// <summary>
    /// Static delegate bridge so Views can trigger navigation and auth
    /// without referencing HealthHubApplication directly (which would
    /// create a circular project reference since HealthHubApplication
    /// already references HealthHub.App.Views).
    ///
    /// MainWindow wires these once at startup. Views call through them.
    /// </summary>
    public static class AppShell
    {
        public static Action? ShowLogin        { get; set; }
        public static Action? ShowApplication  { get; set; }
        public static Action<UserControl>? Navigate { get; set; }

        public static Func<string, string, bool>? ValidateUser  { get; set; }
        public static Func<string, string, bool>? RegisterUser  { get; set; }
        public static Action? LoadApplicationAfterLogin { get; set; }
    }
}

using System;
using System.Globalization;
using System.Windows.Data;

namespace HealthHub.App.Views.Converters
{
    public class StatusToTimeConverter : IValueConverter
    {
        public object? Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null && value.ToString() == "Available") return "--:--";
            return value;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}

using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Threading;

namespace HealthHub.App.Views.Localization
{
    public static class LocalizationService
    {
        private static ResourceManager? _rm;
        private static ResourceManager Rm =>
            _rm ??= new ResourceManager("HealthHubApplication.Properties.Resources", Assembly.GetEntryAssembly()!);

        public static string GetText(string key) => Rm.GetString(key, CultureInfo.CurrentUICulture) ?? key;

        public static void SetCulture(string cultureName)
        {
            var c = new CultureInfo(cultureName);
            Thread.CurrentThread.CurrentCulture = c;
            Thread.CurrentThread.CurrentUICulture = c;
            CultureInfo.DefaultThreadCurrentCulture = c;
            CultureInfo.DefaultThreadCurrentUICulture = c;
        }
    }
}

using System.Windows.Controls;

namespace HealthHub.App.Views.SurgeonSearchBar
{
    /// DataContext set externally by MainWindow.
    public partial class SurgeonSearchBarView : UserControl
    {
        public SurgeonSearchBarView() { InitializeComponent(); }
    }
}

using System.Windows;
namespace HealthHub.App.Views.PatientDetails
{ public partial class EditPatientWindow : Window { public EditPatientWindow() { InitializeComponent(); } } }

using System.Windows.Controls;

namespace HealthHub.App.Views.PatientDetails
{
    /// DataContext set externally by MainWindow.
    public partial class PatientDetailsView : UserControl
    {
        public PatientDetailsView() { InitializeComponent(); }
        private void PatientGrid_SelectionChanged(object sender, SelectionChangedEventArgs e) { }
    }
}

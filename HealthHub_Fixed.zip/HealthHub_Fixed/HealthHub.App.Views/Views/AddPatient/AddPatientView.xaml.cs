using System.Windows.Controls;
namespace HealthHub.App.Views.AddPatient
{ public partial class AddPatientView : UserControl { public AddPatientView() { InitializeComponent(); } } }

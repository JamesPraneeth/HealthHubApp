using System.Windows.Controls;

namespace HealthHub.App.Views.SurgeonDetails
{
    /// DataContext set externally by MainWindow.
    public partial class SurgeonDetailsView : UserControl
    {
        public SurgeonDetailsView() { InitializeComponent(); }
    }
}

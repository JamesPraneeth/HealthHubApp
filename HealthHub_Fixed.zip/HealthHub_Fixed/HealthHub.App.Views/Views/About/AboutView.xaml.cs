using System.Windows.Controls;
namespace HealthHub.App.Views.About
{ public partial class AboutView : UserControl { public AboutView() { InitializeComponent(); } } }

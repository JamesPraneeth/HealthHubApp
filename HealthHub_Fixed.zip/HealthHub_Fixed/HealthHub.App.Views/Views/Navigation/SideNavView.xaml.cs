using System.Windows.Controls;
namespace HealthHub.App.Views.Navigation
{ public partial class SideNavView : UserControl { public SideNavView() { InitializeComponent(); } } }

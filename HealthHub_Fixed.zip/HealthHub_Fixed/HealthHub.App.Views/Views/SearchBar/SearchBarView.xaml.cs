using System.Windows.Controls;

namespace HealthHub.App.Views.SearchBar
{
    /// DataContext set externally by MainWindow.
    public partial class SearchBarView : UserControl
    {
        public SearchBarView() { InitializeComponent(); }
    }
}

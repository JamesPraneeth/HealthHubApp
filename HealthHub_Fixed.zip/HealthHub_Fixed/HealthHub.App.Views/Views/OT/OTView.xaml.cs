using System.Windows.Controls;

namespace HealthHub.App.Views.OT
{
    /// DataContext is set by HealthHubApplication.MainWindow.
    /// Cannot set it here because OTViewModel lives in HealthHubApplication
    /// and App.Views cannot reference it without creating a circular dependency.
    public partial class OTView : UserControl
    {
        public OTView() { InitializeComponent(); }
    }
}

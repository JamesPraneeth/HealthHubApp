using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace HealthHub.App.Views.Login
{
    public partial class RegisterView : UserControl
    {
        private bool _isPwV, _isConfPwV, _uidT, _pwT, _confPwT;

        public RegisterView() { InitializeComponent(); }

        private string GetPw()     => _isPwV     ? txtVisiblePassword.Text        : txtPassword.Password;
        private string GetConfPw() => _isConfPwV ? txtVisibleConfirmPassword.Text : txtConfirmPassword.Password;

        private bool ValidateUid(string id, out string err)
        {
            err = "";
            if (string.IsNullOrWhiteSpace(id))          { err = "User ID is required."; return false; }
            if (id.Contains(" "))                        { err = "User ID should not contain spaces."; return false; }
            if (id.Length < 4)                           { err = "Minimum 4 characters."; return false; }
            if (Regex.IsMatch(id, @"[!@#%^&*()]"))       { err = "No special symbols."; return false; }
            if (!Regex.IsMatch(id, @"\d"))               { err = "Must contain a number."; return false; }
            return true;
        }

        private bool ValidatePw(string pw, out string err)
        {
            err = "";
            if (string.IsNullOrWhiteSpace(pw))           { err = "Password is required."; return false; }
            if (pw.Contains(" "))                        { err = "No spaces allowed."; return false; }
            if (pw.Length < 8 || pw.Length > 16)         { err = "Must be 8-16 characters."; return false; }
            if (!Regex.IsMatch(pw, @"[!@#%^&*]"))        { err = "One special symbol required."; return false; }
            if (!Regex.IsMatch(pw, @"\d"))               { err = "One number required."; return false; }
            if (!Regex.IsMatch(pw, @"[A-Z]"))            { err = "One uppercase letter required."; return false; }
            return true;
        }

        private string ValidateConfPw()
        {
            if (string.IsNullOrWhiteSpace(GetConfPw())) return "Confirm Password is required.";
            return GetPw() != GetConfPw() ? "Passwords do not match." : string.Empty;
        }

        private void RefreshUid()    { if (!_uidT) { txtUserIdError.Text = ""; return; } ValidateUid(txtUserId.Text.Trim(), out string err); txtUserIdError.Text = err; }
        private void RefreshPw()     { if (!_pwT)  { txtPasswordError.Text = ""; return; } ValidatePw(GetPw(), out string err); txtPasswordError.Text = err; }
        private void RefreshConfPw() => txtConfirmPasswordError.Text = _confPwT ? ValidateConfPw() : string.Empty;

        private void txtUserId_GotFocus(object s, RoutedEventArgs e)                   { _uidT = true; RefreshUid(); }
        private void txtUserId_TextChanged(object s, TextChangedEventArgs e)           => RefreshUid();
        private void txtPassword_GotFocus(object s, RoutedEventArgs e)                 { _pwT = true; RefreshPw(); if (_confPwT) RefreshConfPw(); }
        private void txtPassword_PasswordChanged(object s, RoutedEventArgs e)          { RefreshPw(); if (_confPwT) RefreshConfPw(); }
        private void txtVisiblePassword_TextChanged(object s, TextChangedEventArgs e)  { RefreshPw(); if (_confPwT) RefreshConfPw(); }
        private void txtConfirmPassword_GotFocus(object s, RoutedEventArgs e)          { _confPwT = true; RefreshConfPw(); }
        private void txtConfirmPassword_PasswordChanged(object s, RoutedEventArgs e)   => RefreshConfPw();
        private void txtVisibleConfirmPassword_TextChanged(object s, TextChangedEventArgs e) => RefreshConfPw();

        private void TogglePassword(object s, RoutedEventArgs e)
        {
            if (!_isPwV) { txtVisiblePassword.Text = txtPassword.Password; txtVisiblePassword.Visibility = Visibility.Visible; txtPassword.Visibility = Visibility.Collapsed; _isPwV = true; }
            else         { txtPassword.Password = txtVisiblePassword.Text; txtPassword.Visibility = Visibility.Visible; txtVisiblePassword.Visibility = Visibility.Collapsed; _isPwV = false; }
            RefreshPw(); if (_confPwT) RefreshConfPw();
        }

        private void ToggleConfirmPassword(object s, RoutedEventArgs e)
        {
            if (!_isConfPwV) { txtVisibleConfirmPassword.Text = txtConfirmPassword.Password; txtVisibleConfirmPassword.Visibility = Visibility.Visible; txtConfirmPassword.Visibility = Visibility.Collapsed; _isConfPwV = true; }
            else             { txtConfirmPassword.Password = txtVisibleConfirmPassword.Text; txtConfirmPassword.Visibility = Visibility.Visible; txtVisibleConfirmPassword.Visibility = Visibility.Collapsed; _isConfPwV = false; }
            RefreshConfPw();
        }

        private void btnRegister_Click(object s, RoutedEventArgs e)
        {
            _uidT = _pwT = _confPwT = true;
            RefreshUid(); RefreshPw(); RefreshConfPw();
            if (!string.IsNullOrEmpty(txtUserIdError.Text) || !string.IsNullOrEmpty(txtPasswordError.Text) || !string.IsNullOrEmpty(txtConfirmPasswordError.Text)) return;

            if (AppShell.RegisterUser != null && AppShell.RegisterUser(txtUserId.Text.Trim(), GetPw()))
                AppShell.Navigate?.Invoke(new LoginView());
            else
                txtUserIdError.Text = "User ID already exists.";
        }

        private void LoginLink_Click(object s, RoutedEventArgs e) =>
            AppShell.Navigate?.Invoke(new LoginView());
    }
}

using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using HealthHub.App.Views.Localization;

namespace HealthHub.App.Views.Login
{
    public partial class LoginView : UserControl
    {
        private bool _isPwVisible, _userIdTouched, _pwTouched;
        private TextBlock? _txtTitle, _lblUserId, _lblPassword, _lblSelectLanguage;
        private ComboBox? _cmbLanguage;
        private Run? _runDontHaveAccount, _runRegisterHere;

        public LoginView()
        {
            InitializeComponent();
            Loaded += (s, e) =>
            {
                _txtTitle           = FindName("txtTitle") as TextBlock;
                _lblUserId          = FindName("lblUserId") as TextBlock;
                _lblPassword        = FindName("lblPassword") as TextBlock;
                _lblSelectLanguage  = FindName("lblSelectLanguage") as TextBlock;
                _cmbLanguage        = FindName("cmbLanguage") as ComboBox;
                _runDontHaveAccount = FindName("runDontHaveAccount") as Run;
                _runRegisterHere    = FindName("runRegisterHere") as Run;
                this.Language = XmlLanguage.GetLanguage(CultureInfo.CurrentUICulture.IetfLanguageTag);
                SetSelectedLanguage();
                SetLocalizedText();
                UpdateButtonState();
            };
        }

        private string T(string key) => LocalizationService.GetText(key);

        private void SetLocalizedText()
        {
            if (_txtTitle != null)           _txtTitle.Text           = "Welcome to HealthHub";
            if (_lblUserId != null)          _lblUserId.Text          = T("UserId");
            if (_lblPassword != null)        _lblPassword.Text        = T("Password");
            btnLogin.Content = T("Login");
            if (_runDontHaveAccount != null) _runDontHaveAccount.Text = T("DontHaveAccount") + " ";
            if (_runRegisterHere != null)    _runRegisterHere.Text    = T("RegisterHere");
            if (_lblSelectLanguage != null)  _lblSelectLanguage.Text  = T("SelectLanguage");
            RefreshUserIdV(); RefreshPwV();
        }

        private void SetSelectedLanguage()
        {
            if (_cmbLanguage == null) return;
            foreach (ComboBoxItem item in _cmbLanguage.Items)
                if ((item.Tag?.ToString() ?? "") == CultureInfo.CurrentUICulture.Name)
                { _cmbLanguage.SelectedItem = item; return; }
            _cmbLanguage.SelectedIndex = 0;
        }

        private string GetPw() => _isPwVisible ? txtVisiblePassword.Text : txtPassword.Password;
        private void UpdateButtonState() =>
            btnLogin.IsEnabled = !string.IsNullOrWhiteSpace(txtUserId.Text) && !string.IsNullOrWhiteSpace(GetPw());
        private void RefreshUserIdV() =>
            txtUserIdError.Text = _userIdTouched && string.IsNullOrWhiteSpace(txtUserId.Text.Trim()) ? T("UserIdRequired") : string.Empty;
        private void RefreshPwV() =>
            txtPasswordError.Text = _pwTouched && string.IsNullOrWhiteSpace(GetPw()) ? T("PasswordRequired") : string.Empty;

        private void txtUserId_GotFocus(object s, RoutedEventArgs e)           { _userIdTouched = true; RefreshUserIdV(); }
        private void txtUserId_TextChanged(object s, TextChangedEventArgs e)   { RefreshUserIdV(); UpdateButtonState(); txtError.Text = string.Empty; }
        private void txtPassword_GotFocus(object s, RoutedEventArgs e)         { _pwTouched = true; RefreshPwV(); }
        private void txtPassword_PasswordChanged(object s, RoutedEventArgs e)
        { if (!_isPwVisible) txtVisiblePassword.Text = txtPassword.Password; RefreshPwV(); UpdateButtonState(); txtError.Text = string.Empty; }
        private void txtVisiblePassword_TextChanged(object s, TextChangedEventArgs e)
        { if (_isPwVisible) txtPassword.Password = txtVisiblePassword.Text; RefreshPwV(); UpdateButtonState(); txtError.Text = string.Empty; }

        private void TogglePassword(object s, RoutedEventArgs e)
        {
            if (!_isPwVisible)
            { txtVisiblePassword.Text = txtPassword.Password; txtVisiblePassword.Visibility = Visibility.Visible; txtPassword.Visibility = Visibility.Collapsed; _isPwVisible = true; }
            else
            { txtPassword.Password = txtVisiblePassword.Text; txtPassword.Visibility = Visibility.Visible; txtVisiblePassword.Visibility = Visibility.Collapsed; _isPwVisible = false; }
            RefreshPwV(); UpdateButtonState();
        }

        private void Language_Changed(object s, SelectionChangedEventArgs e)
        {
            if (_cmbLanguage?.SelectedItem is not ComboBoxItem item || item.Tag == null) return;
            LocalizationService.SetCulture(item.Tag.ToString()!);
            this.Language = XmlLanguage.GetLanguage(CultureInfo.CurrentUICulture.IetfLanguageTag);
            SetLocalizedText();
        }

        private void btnLogin_Click(object s, RoutedEventArgs e)
        {
            _userIdTouched = _pwTouched = true;
            RefreshUserIdV(); RefreshPwV();
            if (!string.IsNullOrEmpty(txtUserIdError.Text) || !string.IsNullOrEmpty(txtPasswordError.Text)) return;

            if (AppShell.ValidateUser != null && AppShell.ValidateUser(txtUserId.Text.Trim(), GetPw()))
            { txtError.Text = string.Empty; AppShell.LoadApplicationAfterLogin?.Invoke(); }
            else
                txtError.Text = T("InvalidCredentials");
        }

        private void RegisterLink_Click(object s, RoutedEventArgs e) =>
            AppShell.Navigate?.Invoke(new RegisterView());
    }
}

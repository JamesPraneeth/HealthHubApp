using HealthHub.Domain.Entities;

namespace HealthHub.Domain.Repositories
{
    /// <summary>Persists to Data\Patients.xml</summary>
    public class PatientRepository : XmlRepository<Patient>
    {
        public PatientRepository() : base("Patients.xml", "Patients") { }
    }

    /// <summary>Persists to Data\Surgeons.xml</summary>
    public class SurgeonRepository : XmlRepository<Surgeon>
    {
        public SurgeonRepository() : base("Surgeons.xml", "Surgeons") { }
    }

    /// <summary>Persists to Data\Rooms.xml</summary>
    public class RoomRepository : XmlRepository<HospitalRoom>
    {
        public RoomRepository() : base("Rooms.xml", "Rooms") { }
    }

    /// <summary>Persists to Data\SurgicalLogs.xml</summary>
    public class SurgicalLogRepository : XmlRepository<SurgicalLog>
    {
        public SurgicalLogRepository() : base("SurgicalLogs.xml", "SurgicalLogs") { }
    }

    /// <summary>Persists to Data\Users.xml</summary>
    public class UserRepository : XmlRepository<UserAccount>
    {
        public UserRepository() : base("Users.xml", "Users") { }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace HealthHub.Domain.Repositories
{
    /// <summary>
    /// Base class for "one XML file per entity type".
    /// Serializes List&lt;T&gt; directly so each file has a clean root element
    /// (e.g. &lt;Patients&gt;&lt;Patient/&gt;...&lt;/Patients&gt;).
    /// </summary>
    public abstract class XmlRepository<T> where T : class
    {
        private readonly string _filePath;
        private readonly XmlSerializer _serializer;

        /// <summary>
        /// Raised instead of showing a MessageBox directly, keeping this
        /// project free of any WPF reference. The WPF startup code
        /// (App.xaml.cs) subscribes and shows the dialog.
        /// </summary>
        public event Action<string>? Error;

        protected XmlRepository(string fileName, string rootElement)
        {
            // Data folder sits next to the solution (3 levels up from bin\Debug\<tfm>)
            string dataDir = Path.GetFullPath(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\Data"));
            Directory.CreateDirectory(dataDir);
            _filePath   = Path.Combine(dataDir, fileName);
            _serializer = new XmlSerializer(typeof(List<T>), new XmlRootAttribute(rootElement));
        }

        public List<T> LoadAll()
        {
            if (!File.Exists(_filePath)) return new List<T>();
            try
            {
                using var stream = new FileStream(_filePath, FileMode.Open, FileAccess.Read);
                return (List<T>?)_serializer.Deserialize(stream) ?? new List<T>();
            }
            catch (Exception ex)
            {
                Error?.Invoke(
                    $"Failed to read {Path.GetFileName(_filePath)}.\n\n" +
                    $"The file may be corrupted. Starting with empty data.\n\nError: {ex.Message}");
                return new List<T>();
            }
        }

        public void SaveAll(List<T> items)
        {
            try
            {
                using var stream = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                _serializer.Serialize(stream, items);
            }
            catch (Exception ex)
            {
                Error?.Invoke($"Failed to save {Path.GetFileName(_filePath)}: {ex.Message}");
            }
        }
    }
}

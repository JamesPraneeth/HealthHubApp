using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories;

namespace HealthHub.App.Services
{
    /// <summary>
    /// Manages HospitalRoom data (OT/ICU/OPD) and resolves PatientId/SurgeonId
    /// to display names from PatientStore and SurgeonStore on load and after
    /// each save. This is the single source of truth for room scheduling data.
    /// </summary>
    public class RoomStore
    {
        private readonly RoomRepository _roomRepo;
        private readonly SurgicalLogRepository _logRepo;
        private readonly PatientStore _patientStore;
        private readonly SurgeonStore _surgeonStore;

        public ObservableCollection<HospitalRoom> Rooms { get; } = new();
        public ObservableCollection<SurgicalLog>  SurgicalLogs { get; } = new();

        public event Action<string>? Error;

        public RoomStore(
            RoomRepository roomRepo,
            SurgicalLogRepository logRepo,
            PatientStore patientStore,
            SurgeonStore surgeonStore)
        {
            _roomRepo     = roomRepo;
            _logRepo      = logRepo;
            _patientStore = patientStore;
            _surgeonStore = surgeonStore;

            // Load rooms and resolve names
            foreach (var room in _roomRepo.LoadAll())
            {
                ResolveRoomNames(room);
                Rooms.Add(room);
            }

            // Load surgical logs and resolve names
            foreach (var log in _logRepo.LoadAll())
            {
                ResolveLogNames(log);
                SurgicalLogs.Add(log);
            }
        }

        // ── Name resolution ───────────────────────────────────────────────

        public void ResolveRoomNames(HospitalRoom room)
        {
            foreach (var icu in room.ICUPatients)
                icu.PatientName = ResolveName(_patientStore.Patients, icu.PatientId);

            foreach (var opd in room.OPDPatients)
            {
                opd.PatientName   = ResolveName(_patientStore.Patients, opd.PatientId);
                opd.PhysicianName = ResolveSurgeonName(_surgeonStore.Surgeons, opd.SurgeonId);
            }

            foreach (var surg in room.OTSurgeries)
            {
                surg.PatientName        = ResolveName(_patientStore.Patients, surg.PatientId);
                surg.PrimarySurgeonName = ResolveSurgeonName(_surgeonStore.Surgeons, surg.SurgeonId);
            }
        }

        public void ResolveLogNames(SurgicalLog log)
        {
            log.PatientName        = ResolveName(_patientStore.Patients, log.PatientId);
            log.PrimarySurgeonName = ResolveSurgeonName(_surgeonStore.Surgeons, log.SurgeonId);
        }

        private static string ResolveName(ObservableCollection<Patient> patients, string patientId)
            => patients.FirstOrDefault(p => p.PatientId == patientId)?.Name ?? patientId;

        private static string ResolveSurgeonName(ObservableCollection<Surgeon> surgeons, string surgeonId)
            => surgeons.FirstOrDefault(s => s.SurgeonId == surgeonId)?.Name ?? surgeonId;

        // ── Persistence ───────────────────────────────────────────────────

        public void SaveRooms()
        {
            _roomRepo.Error += OnError;
            _roomRepo.SaveAll(new List<HospitalRoom>(Rooms));
            _roomRepo.Error -= OnError;
            // Re-resolve after save so XmlIgnore names stay fresh
            foreach (var room in Rooms) ResolveRoomNames(room);
        }

        public void AddSurgicalLog(SurgicalLog log)
        {
            ResolveLogNames(log);
            SurgicalLogs.Add(log);
            _logRepo.Error += OnError;
            _logRepo.SaveAll(new List<SurgicalLog>(SurgicalLogs));
            _logRepo.Error -= OnError;
        }

        private void OnError(string msg) => Error?.Invoke(msg);
    }
}

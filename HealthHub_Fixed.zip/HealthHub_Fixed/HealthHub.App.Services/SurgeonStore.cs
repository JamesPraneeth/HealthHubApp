using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories;

namespace HealthHub.App.Services
{
    public class SurgeonStore : INotifyPropertyChanged
    {
        private readonly SurgeonRepository _repo;
        public ObservableCollection<Surgeon> Surgeons { get; } = new();

        private string _searchText = string.Empty;
        private string _selectedSearchBy = "Name";
        private string _selectedFilterBy = "None";
        private string _selectedFilterValue = "All";

        public event Action<string>? Error;

        public SurgeonStore(SurgeonRepository repo)
        {
            _repo = repo;
            var list = _repo.LoadAll();
            foreach (var s in list) { s.PropertyChanged += Item_Changed; Surgeons.Add(s); }
            Surgeons.CollectionChanged += Collection_Changed;
        }

        private void Collection_Changed(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null) foreach (Surgeon s in e.OldItems) s.PropertyChanged -= Item_Changed;
            if (e.NewItems != null) foreach (Surgeon s in e.NewItems) s.PropertyChanged += Item_Changed;
            Save();
        }

        private void Item_Changed(object? sender, PropertyChangedEventArgs e)
        { if (e.PropertyName != nameof(Surgeon.IsSelected)) Save(); }

        private void Save()
        {
            _repo.Error += OnError;
            _repo.SaveAll(new List<Surgeon>(Surgeons));
            _repo.Error -= OnError;
        }

        private void OnError(string msg) => Error?.Invoke(msg);

        public string SearchText { get => _searchText; set => Set(ref _searchText, value); }
        public string SelectedSearchBy { get => _selectedSearchBy; set => Set(ref _selectedSearchBy, value); }
        public string SelectedFilterBy { get => _selectedFilterBy; set => Set(ref _selectedFilterBy, value); }
        public string SelectedFilterValue { get => _selectedFilterValue; set => Set(ref _selectedFilterValue, value); }

        public void ClearFilters()
        { SearchText = string.Empty; SelectedSearchBy = "Name"; SelectedFilterBy = "None"; SelectedFilterValue = "All"; }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void Set<T>(ref T f, T v, [CallerMemberName] string p = "")
        { if (!Equals(f, v)) { f = v; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p)); } }
    }
}

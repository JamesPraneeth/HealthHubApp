using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories;

namespace HealthHub.App.Services
{
    public class PatientStore : INotifyPropertyChanged
    {
        private readonly PatientRepository _repo;
        public ObservableCollection<Patient> Patients { get; } = new();

        private string _searchText = string.Empty;
        private string _selectedSearchBy = "Name";
        private string _selectedFilterBy = "None";
        private string _selectedFilterValue = "All";

        public event Action<string>? Error;

        public PatientStore(PatientRepository repo)
        {
            _repo = repo;
            var list = _repo.LoadAll();
            foreach (var p in list) { p.PropertyChanged += Item_Changed; Patients.Add(p); }
            Patients.CollectionChanged += Collection_Changed;
        }

        private void Collection_Changed(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null) foreach (Patient p in e.OldItems) p.PropertyChanged -= Item_Changed;
            if (e.NewItems != null) foreach (Patient p in e.NewItems) p.PropertyChanged += Item_Changed;
            Save();
        }

        private void Item_Changed(object? sender, PropertyChangedEventArgs e)
        { if (e.PropertyName != nameof(Patient.IsSelected)) Save(); }

        private void Save()
        {
            _repo.Error += OnError;
            _repo.SaveAll(new List<Patient>(Patients));
            _repo.Error -= OnError;
        }

        private void OnError(string msg) => Error?.Invoke(msg);

        public string SearchText { get => _searchText; set => Set(ref _searchText, value); }
        public string SelectedSearchBy { get => _selectedSearchBy; set => Set(ref _selectedSearchBy, value); }
        public string SelectedFilterBy { get => _selectedFilterBy; set => Set(ref _selectedFilterBy, value); }
        public string SelectedFilterValue { get => _selectedFilterValue; set => Set(ref _selectedFilterValue, value); }

        public void ClearFilters()
        { SearchText = string.Empty; SelectedSearchBy = "Name"; SelectedFilterBy = "None"; SelectedFilterValue = "All"; }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void Set<T>(ref T f, T v, [CallerMemberName] string p = "")
        { if (!Equals(f, v)) { f = v; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p)); } }
    }
}

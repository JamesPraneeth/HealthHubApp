using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories;

namespace HealthHub.App.Services
{
    // ── UserStore ──────────────────────────────────────────────────────────
    public class UserStore
    {
        private readonly UserRepository _repo;
        private readonly List<UserAccount> _users;

        public event Action<string>? Error;

        public UserStore(UserRepository repo)
        {
            _repo = repo;
            _repo.Error += msg => Error?.Invoke(msg);
            _users = _repo.LoadAll();
        }

        public bool RegisterUser(string userId, string password)
        {
            if (_users.Any(u => u.UserId == userId)) return false;
            _users.Add(new UserAccount { UserId = userId, Password = password });
            _repo.SaveAll(_users);
            return true;
        }

        public bool ValidateUser(string userId, string password)
            => _users.Any(u => u.UserId == userId && u.Password == password);
    }

    // ── StatusService ──────────────────────────────────────────────────────
    public static class StatusService
    {
        public static event Action<string>? StatusChanged;
        public static void Publish(string message) => StatusChanged?.Invoke(message);
    }

    // ── RelayCommand ───────────────────────────────────────────────────────
    public class RelayCommand : ICommand
    {
        private readonly Action? _execute;
        private readonly Action<object?>? _executeParam;
        private readonly Func<bool>? _canExecute;
        private readonly Func<object?, bool>? _canExecuteParam;

        public event EventHandler? CanExecuteChanged;

        public RelayCommand(Action execute, Func<bool>? canExecute = null)
        { _execute = execute; _canExecute = canExecute; }

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        { _executeParam = execute; _canExecuteParam = canExecute; }

        public bool CanExecute(object? parameter)
        {
            if (_canExecute != null) return _canExecute();
            if (_canExecuteParam != null) return _canExecuteParam(parameter);
            return true;
        }

        public void Execute(object? parameter)
        { _execute?.Invoke(); _executeParam?.Invoke(parameter); }

        public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}

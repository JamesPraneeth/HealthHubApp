using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace HealthHub.Domain.Entities
{
    /// <summary>
    /// A hospital room (OT, ICU, or OPD).
    /// ICU/OPD/OT entries reference Patient and Surgeon by their IDs
    /// rather than duplicating name strings — the display names are
    /// resolved at runtime from PatientStore / SurgeonStore.
    /// </summary>
    public class HospitalRoom
    {
        public string RoomName { get; set; } = string.Empty;
        public string RoomType { get; set; } = string.Empty;
        public int MaxCapacity { get; set; } = 0;

        [XmlArray("ICUPatients")]
        [XmlArrayItem("ICUAdmission")]
        public List<ICUAdmission> ICUPatients { get; set; } = new();

        [XmlArray("OPDPatients")]
        [XmlArrayItem("OPDAppointment")]
        public List<OPDAppointment> OPDPatients { get; set; } = new();

        [XmlArray("OTSurgeries")]
        [XmlArrayItem("OTScheduledSurgery")]
        public List<OTScheduledSurgery> OTSurgeries { get; set; } = new();

        [XmlIgnore] public string DisplayName => $"{RoomType} - {RoomName}";
        [XmlIgnore] public int AvailableOPDSlots => MaxCapacity - OPDPatients.Count;
        [XmlIgnore] public int AvailableICUBeds  => MaxCapacity - ICUPatients.Count;
    }

    /// <summary>
    /// ICU admission — references a Patient by PatientId.
    /// PatientName is a resolved display property (not persisted).
    /// </summary>
    public class ICUAdmission
    {
        /// <summary>Foreign key → Patient.PatientId</summary>
        public string PatientId { get; set; } = string.Empty;

        public DateTime StartDate { get; set; }
        public DateTime EndDate   { get; set; }

        /// <summary>Resolved at runtime from PatientStore — not stored in XML.</summary>
        [XmlIgnore] public string PatientName { get; set; } = string.Empty;
    }

    /// <summary>
    /// OPD appointment — references a Patient by PatientId
    /// and a Surgeon (physician) by SurgeonId.
    /// Display names are resolved at runtime.
    /// </summary>
    public class OPDAppointment
    {
        /// <summary>Foreign key → Patient.PatientId</summary>
        public string PatientId { get; set; } = string.Empty;

        /// <summary>Foreign key → Surgeon.SurgeonId</summary>
        public string SurgeonId { get; set; } = string.Empty;

        public DateTime Date   { get; set; }
        public string   Time   { get; set; } = string.Empty;
        public string   Reason { get; set; } = string.Empty;

        /// <summary>Resolved at runtime from PatientStore — not stored in XML.</summary>
        [XmlIgnore] public string PatientName  { get; set; } = string.Empty;
        /// <summary>Resolved at runtime from SurgeonStore — not stored in XML.</summary>
        [XmlIgnore] public string PhysicianName { get; set; } = string.Empty;
    }

    /// <summary>
    /// A scheduled OT surgery — references Patient and Surgeon by ID.
    /// Display names are resolved at runtime.
    /// </summary>
    public class OTScheduledSurgery
    {
        public string   OTName        { get; set; } = string.Empty;
        public DateTime SurgeryDate   { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime   { get; set; }
        public bool     IsCompleted   { get; set; }

        /// <summary>Foreign key → Surgeon.SurgeonId</summary>
        public string SurgeonId { get; set; } = string.Empty;

        /// <summary>Foreign key → Patient.PatientId</summary>
        public string PatientId { get; set; } = string.Empty;

        public string ProcedureName { get; set; } = string.Empty;

        /// <summary>Resolved at runtime from SurgeonStore — not stored in XML.</summary>
        [XmlIgnore] public string PrimarySurgeonName { get; set; } = string.Empty;
        /// <summary>Resolved at runtime from PatientStore — not stored in XML.</summary>
        [XmlIgnore] public string PatientName { get; set; } = string.Empty;

        [XmlIgnore] public string TimeRange => $"{StartDateTime:HH:mm} - {EndDateTime:HH:mm}";
        [XmlIgnore]
        public string Status
        {
            get
            {
                if (IsCompleted) return "Completed";
                var now = DateTime.Now;
                if (now < StartDateTime)                          return "Scheduled";
                if (now >= StartDateTime && now <= EndDateTime)   return "In Progress";
                return "Time Completed";
            }
        }
    }

    /// <summary>
    /// Completed-surgery log entry — also references Patient and Surgeon by ID.
    /// </summary>
    public class SurgicalLog
    {
        public string   OTName        { get; set; } = string.Empty;
        public DateTime SurgeryDate   { get; set; }
        public string   Duration      { get; set; } = string.Empty;
        public string   ProcedureName { get; set; } = string.Empty;
        public string   DocumentName  { get; set; } = string.Empty;

        /// <summary>Foreign key → Surgeon.SurgeonId</summary>
        public string SurgeonId { get; set; } = string.Empty;

        /// <summary>Foreign key → Patient.PatientId</summary>
        public string PatientId { get; set; } = string.Empty;

        /// <summary>Resolved at runtime — not stored in XML.</summary>
        [XmlIgnore] public string PrimarySurgeonName { get; set; } = string.Empty;
        [XmlIgnore] public string PatientName        { get; set; } = string.Empty;
    }

    /// <summary>
    /// A user account (stored in Users.xml).
    /// </summary>
    public class UserAccount
    {
        public string UserId   { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}

using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HealthHub.Domain.Entities
{
    public class Surgeon : INotifyPropertyChanged
    {
        private string _surgeonId = string.Empty;
        private string _name = string.Empty;
        private string _department = string.Empty;
        private string _email = string.Empty;
        private string _contactNo = string.Empty;
        private string _specialization = string.Empty;
        private string _experience = string.Empty;
        private string _availability = string.Empty;
        private bool _isSelected;

        public string SurgeonId { get => _surgeonId; set { _surgeonId = value; OnPropertyChanged(); } }
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public string Department { get => _department; set { _department = value; OnPropertyChanged(); } }
        public string Email { get => _email; set { _email = value; OnPropertyChanged(); } }
        public string ContactNo { get => _contactNo; set { _contactNo = value; OnPropertyChanged(); } }
        public string Specialization { get => _specialization; set { _specialization = value; OnPropertyChanged(); } }
        public string Experience { get => _experience; set { _experience = value; OnPropertyChanged(); } }
        public string Availability { get => _availability; set { _availability = value; OnPropertyChanged(); } }
        public bool IsSelected { get => _isSelected; set { _isSelected = value; OnPropertyChanged(); } }

        public Surgeon Clone() => new Surgeon
        {
            SurgeonId = SurgeonId, Name = Name, Department = Department, Email = Email,
            ContactNo = ContactNo, Specialization = Specialization,
            Experience = Experience, Availability = Availability, IsSelected = IsSelected
        };

        public void CopyFrom(Surgeon o)
        {
            SurgeonId = o.SurgeonId; Name = o.Name; Department = o.Department; Email = o.Email;
            ContactNo = o.ContactNo; Specialization = o.Specialization;
            Experience = o.Experience; Availability = o.Availability; IsSelected = o.IsSelected;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? p = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));
    }
}

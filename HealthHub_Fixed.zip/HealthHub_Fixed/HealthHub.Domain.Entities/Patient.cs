using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HealthHub.Domain.Entities
{
    public class Patient : INotifyPropertyChanged
    {
        private string _patientId = string.Empty;
        private string _name = string.Empty;
        private DateTime _dob;
        private string _gender = "I Prefer Not To Say";
        private string _email = string.Empty;
        private string _phoneNo = string.Empty;
        private string _address = string.Empty;
        private bool _isSelected;

        public string PatientId { get => _patientId; set { _patientId = value; OnPropertyChanged(); } }
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public DateTime DOB { get => _dob; set { _dob = value; OnPropertyChanged(); } }
        public string Gender { get => _gender; set { _gender = value; OnPropertyChanged(); } }
        public string Email { get => _email; set { _email = value; OnPropertyChanged(); } }
        public string PhoneNo
        {
            get => _phoneNo;
            set { _phoneNo = value; OnPropertyChanged(); OnPropertyChanged(nameof(MaskedPhoneNo)); }
        }
        public string MaskedPhoneNo
        {
            get
            {
                if (string.IsNullOrWhiteSpace(PhoneNo)) return string.Empty;
                var p = PhoneNo.Trim();
                return p.Length <= 4 ? p : new string('X', p.Length - 4) + p[^4..];
            }
        }
        public string Address { get => _address; set { _address = value; OnPropertyChanged(); } }
        public bool IsSelected { get => _isSelected; set { _isSelected = value; OnPropertyChanged(); } }

        public Patient Clone() => new Patient
        {
            PatientId = PatientId, Name = Name, DOB = DOB, Gender = Gender,
            Email = Email, PhoneNo = PhoneNo, Address = Address, IsSelected = IsSelected
        };

        public void CopyFrom(Patient o)
        {
            PatientId = o.PatientId; Name = o.Name; DOB = o.DOB; Gender = o.Gender;
            Email = o.Email; PhoneNo = o.PhoneNo; Address = o.Address; IsSelected = o.IsSelected;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? p = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));
    }
}

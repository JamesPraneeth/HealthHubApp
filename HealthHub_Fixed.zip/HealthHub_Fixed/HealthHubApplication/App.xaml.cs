using System.Windows;
using HealthHub.App.Services;
using HealthHub.Domain.Repositories;

namespace HealthHubApplication
{
    public partial class App : Application
    {
        // All stores are singletons wired here and accessed by ViewModels
        public static PatientStore PatientStore { get; private set; } = null!;
        public static SurgeonStore SurgeonStore { get; private set; } = null!;
        public static RoomStore    RoomStore    { get; private set; } = null!;
        public static UserStore    UserStore    { get; private set; } = null!;

        public App()
        {
            // Repositories
            var patientRepo    = new PatientRepository();
            var surgeonRepo    = new SurgeonRepository();
            var roomRepo       = new RoomRepository();
            var surgicalLogRepo = new SurgicalLogRepository();
            var userRepo       = new UserRepository();

            // Wire error events — repos fire these; WPF shows the MessageBox here
            void ShowError(string msg) =>
                MessageBox.Show(msg, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);

            patientRepo.Error    += ShowError;
            surgeonRepo.Error    += ShowError;
            roomRepo.Error       += ShowError;
            surgicalLogRepo.Error += ShowError;
            userRepo.Error       += ShowError;

            // Stores — PatientStore and SurgeonStore must be created before RoomStore
            // so RoomStore can resolve PatientId/SurgeonId → names on load
            PatientStore = new PatientStore(patientRepo);
            SurgeonStore = new SurgeonStore(surgeonRepo);
            RoomStore    = new RoomStore(roomRepo, surgicalLogRepo, PatientStore, SurgeonStore);
            UserStore    = new UserStore(userRepo);

            PatientStore.Error += ShowError;
            SurgeonStore.Error += ShowError;
            RoomStore.Error    += ShowError;
            UserStore.Error    += ShowError;

            // Seed demo user — no-op if it already exists in Users.xml
            UserStore.RegisterUser("user123", "User@123");
        }
    }
}

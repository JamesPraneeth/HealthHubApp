using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HealthHub.App.Views;
using HealthHub.App.Views.About;
using HealthHub.App.Views.Home;
using HealthHub.App.Views.Login;
using HealthHub.App.Views.Navigation;
using HealthHub.App.Views.OT;
using HealthHub.App.Views.PatientDetails;
using HealthHub.App.Views.SearchBar;
using HealthHub.App.Views.SurgeonDetails;
using HealthHub.App.Views.SurgeonSearchBar;
using HealthHubApplication.ViewModels.Home;
using HealthHubApplication.ViewModels.Navigation;
using HealthHubApplication.ViewModels.OT;
using HealthHubApplication.ViewModels.PatientDetails;
using HealthHubApplication.ViewModels.SearchBar;
using HealthHubApplication.ViewModels.SurgeonDetails;
using HealthHubApplication.ViewModels.SurgeonSearchBar;

namespace HealthHubApplication
{
    public partial class MainWindow : Window
    {
        public static MainWindow Instance { get; private set; } = null!;

        private SideNavViewModel? _navVM;
        private HomeView?   _homeView;
        private AboutView?  _aboutView;
        private OTView?     _otView;
        private Grid?       _patientPage;
        private Grid?       _surgeonPage;
        private bool        _appLoaded;

        public MainWindow()
        {
            InitializeComponent();
            Instance = this;

            // Wire AppShell so HealthHub.App.Views can navigate / auth
            // without referencing HealthHubApplication directly.
            AppShell.ShowLogin               = LoadLoginScreen;
            AppShell.LoadApplicationAfterLogin = LoadApplicationAfterLogin;
            AppShell.Navigate                = Navigate;
            AppShell.ValidateUser            = (uid, pw) => App.UserStore.ValidateUser(uid, pw);
            AppShell.RegisterUser            = (uid, pw) => App.UserStore.RegisterUser(uid, pw);

            LoadLoginScreen();
        }

        public void LoadLoginScreen()
        {
            ShowLoginShell();
            MainContent.Content = new LoginView();
        }

        public void Navigate(UserControl view) => MainContent.Content = view;

        private void ShowLoginShell()
        {
            var bg = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E6F91"));
            Background = RootLayout.Background = bg;
            HeaderControl.Visibility = SideNav.Visibility = Visibility.Collapsed;
            RootLayout.RowDefinitions[0].Height    = new GridLength(0);
            RootLayout.ColumnDefinitions[0].Width  = new GridLength(0);
            Grid.SetRow(MainContent, 0);    Grid.SetColumn(MainContent, 0);
            Grid.SetRowSpan(MainContent, 2); Grid.SetColumnSpan(MainContent, 2);
        }

        private void ShowApplicationShell()
        {
            Background = RootLayout.Background = Brushes.White;
            HeaderControl.Visibility = SideNav.Visibility = Visibility.Visible;
            RootLayout.RowDefinitions[0].Height   = new GridLength(90);
            RootLayout.ColumnDefinitions[0].Width = GridLength.Auto;
            Grid.SetRow(MainContent, 1);    Grid.SetColumn(MainContent, 1);
            Grid.SetRowSpan(MainContent, 1); Grid.SetColumnSpan(MainContent, 1);
        }

        public void LoadApplicationAfterLogin()
        {
            if (!_appLoaded)
            {
                _navVM = new SideNavViewModel();
                HeaderControl.DataContext = SideNav.DataContext = _navVM;

                // Views whose DataContext cannot be set in their own constructors
                // (because ViewModels live in HealthHubApplication and App.Views
                // cannot reference it — that would be circular). We set them here.
                _homeView = new HomeView(new HomeViewModel(App.SurgeonStore, App.RoomStore));
                _aboutView = new AboutView();

                _otView = new OTView();
                _otView.DataContext = new OTViewModel();

                CreatePatientPage();
                CreateSurgeonPage();

                _navVM.ShowHome    = () => MainContent.Content = _homeView;
                _navVM.ShowPatient = () => MainContent.Content = _patientPage;
                _navVM.ShowSurgeon = () => MainContent.Content = _surgeonPage;
                _navVM.ShowAbout   = () => MainContent.Content = _aboutView;
                _navVM.ShowOT      = () => MainContent.Content = _otView;

                _appLoaded = true;
            }

            ShowApplicationShell();
            MainContent.Content = _homeView;
        }

        private void CreatePatientPage()
        {
            _patientPage = new Grid();
            _patientPage.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _patientPage.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            var searchBar = new SearchBarView();
            searchBar.DataContext = new SearchBarViewModel();

            var details = new PatientDetailsView();
            details.DataContext = new PatientDetailsViewModel(App.PatientStore);

            Grid.SetRow(searchBar, 0);
            Grid.SetRow(details, 1);
            _patientPage.Children.Add(searchBar);
            _patientPage.Children.Add(details);
        }

        private void CreateSurgeonPage()
        {
            _surgeonPage = new Grid();
            _surgeonPage.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _surgeonPage.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            var surgeonSearch = new SurgeonSearchBarView();
            surgeonSearch.DataContext = new SurgeonSearchBarViewModel();

            var surgeonDetails = new SurgeonDetailsView();
            surgeonDetails.DataContext = new SurgeonDetailsViewModel(App.SurgeonStore);

            Grid.SetRow(surgeonSearch, 0);
            Grid.SetRow(surgeonDetails, 1);
            _surgeonPage.Children.Add(surgeonSearch);
            _surgeonPage.Children.Add(surgeonDetails);
        }
    }
}

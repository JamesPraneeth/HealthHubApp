using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using HealthHub.App.Services;
using HealthHub.App.Views.AddSurgeon;
using HealthHub.Domain.Entities;
using HealthHub.App.Services;
using HealthHubApplication.ViewModels.AddSurgeon;

namespace HealthHubApplication.ViewModels.SurgeonDetails
{
    public class SurgeonDetailsViewModel : INotifyPropertyChanged
    {
        private readonly SurgeonStore _store;
        private int _currentPage = 1;
        private int _pageSize = 10;

        public ICollectionView SurgeonsView { get; }

        public ICommand EditCommand { get; } = null!;
        public ICommand DeleteCommand { get; } = null!;
        public ICommand NextPageCommand { get; } = null!;
        public ICommand PreviousPageCommand { get; } = null!;

        public event PropertyChangedEventHandler? PropertyChanged;

        public int CurrentPage
        {
            get => _currentPage;
            set
            {
                if (_currentPage != value)
                {
                    _currentPage = value;
                    OnPropertyChanged(nameof(CurrentPage));

                    (NextPageCommand as RelayCommand)?.RaiseCanExecuteChanged();
                    (PreviousPageCommand as RelayCommand)?.RaiseCanExecuteChanged();

                    SurgeonsView.Refresh();
                }
            }
        }

        public int PageSize
        {
            get => _pageSize;
            set
            {
                if (_pageSize != value)
                {
                    _pageSize = value;
                    CurrentPage = 1;
                    OnPropertyChanged(nameof(PageSize));
                    SurgeonsView.Refresh();
                }
            }
        }

        public SurgeonDetailsViewModel(SurgeonStore store)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));

            SurgeonsView = CollectionViewSource.GetDefaultView(_store.Surgeons);
            SurgeonsView.Filter = FilterSurgeon;

            _store.PropertyChanged += Store_PropertyChanged;
            _store.Surgeons.CollectionChanged += Surgeons_CollectionChanged;

            EditCommand = new RelayCommand(OnEdit);
            DeleteCommand = new RelayCommand(OnDelete);

            NextPageCommand = new RelayCommand(_ => NextPage(), _ => CanGoNext());
            PreviousPageCommand = new RelayCommand(_ => PreviousPage(), _ => CanGoPrevious());
        }

        private void Surgeons_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            EnsureCurrentPageValid();
            SurgeonsView.Refresh();
            OnPropertyChanged(nameof(CurrentPage));

            (NextPageCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (PreviousPageCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }

        private void Store_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SurgeonStore.SearchText) ||
                e.PropertyName == nameof(SurgeonStore.SelectedSearchBy) ||
                e.PropertyName == nameof(SurgeonStore.SelectedFilterBy) ||
                e.PropertyName == nameof(SurgeonStore.SelectedFilterValue))
            {
                CurrentPage = 1;
                SurgeonsView.Refresh();
            }
        }

        private bool FilterSurgeon(object obj)
        {
            if (obj is not Surgeon surgeon)
                return false;

            if (!MatchesSearch(surgeon))
                return false;

            if (!MatchesFilter(surgeon))
                return false;

            var filteredSurgeons = _store.Surgeons
                .Where(s => MatchesSearch(s) && MatchesFilter(s))
                .ToList();

            int index = filteredSurgeons.IndexOf(surgeon);

            if (index < 0)
                return false;

            int start = (CurrentPage - 1) * PageSize;
            int end = start + PageSize - 1;

            return index >= start && index <= end;
        }

        private bool MatchesSearch(Surgeon surgeon)
        {
            if (string.IsNullOrWhiteSpace(_store.SearchText))
                return true;

            string search = "*" + _store.SearchText.Trim() + "*";

            return _store.SelectedSearchBy switch
            {
                "Name" => MatchWildcard(surgeon.Name ?? string.Empty, search),
                "Surgeon ID" => MatchWildcard(surgeon.SurgeonId ?? string.Empty, search),
                "Specialization" => MatchWildcard(surgeon.Specialization ?? string.Empty, search),
                _ => true
            };
        }


        private bool MatchWildcard(string input, string pattern)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;

            string regexPattern = "^" +
                System.Text.RegularExpressions.Regex.Escape(pattern)
                    .Replace("\\*", ".*")
                    .Replace("\\?", ".") +
                "$";

            return System.Text.RegularExpressions.Regex.IsMatch(
                input,
                regexPattern,
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        private bool MatchesFilter(Surgeon surgeon)
        {
            if (_store.SelectedFilterBy == "None" ||
                string.IsNullOrWhiteSpace(_store.SelectedFilterValue) ||
                _store.SelectedFilterValue == "All")
            {
                return true;
            }

            return _store.SelectedFilterBy switch
            {
                "Availability" => string.Equals(
                    surgeon.Availability,
                    _store.SelectedFilterValue,
                    StringComparison.OrdinalIgnoreCase),

                "Department" => string.Equals(
                    surgeon.Department,
                    _store.SelectedFilterValue,
                    StringComparison.OrdinalIgnoreCase),

                _ => true
            };
        }

        private int GetFilteredCount()
        {
            return _store.Surgeons.Count(s => MatchesSearch(s) && MatchesFilter(s));
        }

        private bool CanGoNext()
        {
            return CurrentPage < Math.Ceiling((double)GetFilteredCount() / PageSize);
        }

        private bool CanGoPrevious()
        {
            return CurrentPage > 1;
        }

        private void NextPage()
        {
            if (CanGoNext())
                CurrentPage++;
        }

        private void PreviousPage()
        {
            if (CanGoPrevious())
                CurrentPage--;
        }

        private void EnsureCurrentPageValid()
        {
            int filteredCount = GetFilteredCount();
            int totalPages = Math.Max(1, (int)Math.Ceiling((double)filteredCount / PageSize));

            if (CurrentPage > totalPages)
            {
                CurrentPage = totalPages;
            }
        }

        private void OnEdit(object? parameter)
        {
            if (parameter is not Surgeon surgeon)
                return;

            var viewModel = new AddSurgeonViewModel(surgeon);

            var view = new AddSurgeonView
            {
                DataContext = viewModel
            };

            var window = new Window
            {
                Title = "Edit Surgeon",
                Content = view,
                Width = 520,
                Height = 560,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                ResizeMode = ResizeMode.NoResize,
                Owner = Application.Current.MainWindow
            };

            viewModel.CloseAction = () => window.Close();

            window.ShowDialog();

            SurgeonsView.Refresh();
        }

        private void OnDelete(object? parameter)
        {
            if (parameter is not Surgeon surgeon)
                return;

            var result = MessageBox.Show(
                $"Delete surgeon: {surgeon.Name} ?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                _store.Surgeons.Remove(surgeon);
                EnsureCurrentPageValid();
                SurgeonsView.Refresh();
            }
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

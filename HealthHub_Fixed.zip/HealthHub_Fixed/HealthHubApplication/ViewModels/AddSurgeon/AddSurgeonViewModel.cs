using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Input;
using HealthHub.Domain.Entities;
using HealthHub.App.Services;

namespace HealthHubApplication.ViewModels.AddSurgeon
{
    public class AddSurgeonViewModel : INotifyPropertyChanged
    {
        private readonly HealthHub.App.Services.SurgeonStore _store;
        private readonly Surgeon? _originalSurgeon;
        private readonly bool _isEditMode;

        private string _surgeonId = string.Empty;
        private string _name = string.Empty;
        private string _department = string.Empty;
        private string _email = string.Empty;
        private string _contactNo = string.Empty;
        private string _specialization = string.Empty;
        private string _experience = string.Empty;
        private string _availability = "Available";

        private string _nameError = string.Empty;
        private string _departmentError = string.Empty;
        private string _emailError = string.Empty;
        private string _contactNoError = string.Empty;
        private string _specializationError = string.Empty;
        private string _experienceError = string.Empty;

        public event PropertyChangedEventHandler? PropertyChanged;

        public Action? CloseAction { get; set; }

        public string HeaderTitle => _isEditMode ? "Edit Surgeon" : "Add Surgeon";

        public string SaveButtonText => _isEditMode ? "Save" : "Add Surgeon";

        public ObservableCollection<string> DepartmentOptions { get; } =
            new ObservableCollection<string>
            {
                "Cardiology",
                "Neurology",
                "Orthopedics",
                "ENT",
                "General Surgery",
                "Urology",
                "Gastroenterology",
                "Oncology",
                "Pediatrics",
                "Dermatology",
                "Ophthalmology",
                "Pulmonology",
                "Gynecology",
                "Vascular Surgery"
            };

        public ObservableCollection<string> AvailabilityOptions { get; } =
            new ObservableCollection<string>
            {
                "Available",
                "Busy",
                "On Leave"
            };

        public string SurgeonId
        {
            get => _surgeonId;
            set
            {
                if (_surgeonId != value)
                {
                    _surgeonId = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    ValidateName();
                    OnPropertyChanged();
                }
            }
        }

        public string Department
        {
            get => _department;
            set
            {
                if (_department != value)
                {
                    _department = value;
                    ValidateDepartment();
                    OnPropertyChanged();
                }
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                if (_email != value)
                {
                    _email = value;
                    ValidateEmail();
                    OnPropertyChanged();
                }
            }
        }

        public string ContactNo
        {
            get => _contactNo;
            set
            {
                if (_contactNo != value)
                {
                    _contactNo = value;
                    ValidateContactNo();
                    OnPropertyChanged();
                }
            }
        }

        public string Specialization
        {
            get => _specialization;
            set
            {
                if (_specialization != value)
                {
                    _specialization = value;
                    ValidateSpecialization();
                    OnPropertyChanged();
                }
            }
        }

        public string Experience
        {
            get => _experience;
            set
            {
                if (_experience != value)
                {
                    _experience = value;
                    ValidateExperience();
                    OnPropertyChanged();
                }
            }
        }

        public string Availability
        {
            get => _availability;
            set
            {
                if (_availability != value)
                {
                    _availability = value;
                    OnPropertyChanged();
                }
            }
        }

        public string NameError
        {
            get => _nameError;
            set
            {
                if (_nameError != value)
                {
                    _nameError = value;
                    OnPropertyChanged();
                }
            }
        }

        public string DepartmentError
        {
            get => _departmentError;
            set
            {
                if (_departmentError != value)
                {
                    _departmentError = value;
                    OnPropertyChanged();
                }
            }
        }

        public string EmailError
        {
            get => _emailError;
            set
            {
                if (_emailError != value)
                {
                    _emailError = value;
                    OnPropertyChanged();
                }
            }
        }

        public string ContactNoError
        {
            get => _contactNoError;
            set
            {
                if (_contactNoError != value)
                {
                    _contactNoError = value;
                    OnPropertyChanged();
                }
            }
        }

        public string SpecializationError
        {
            get => _specializationError;
            set
            {
                if (_specializationError != value)
                {
                    _specializationError = value;
                    OnPropertyChanged();
                }
            }
        }

        public string ExperienceError
        {
            get => _experienceError;
            set
            {
                if (_experienceError != value)
                {
                    _experienceError = value;
                    OnPropertyChanged();
                }
            }
        }

        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        // Add mode constructor
        public AddSurgeonViewModel()
        {
            _store = App.SurgeonStore;
            _isEditMode = false;

            SurgeonId = GenerateSurgeonId();
            Availability = "Available";

            SaveCommand = new RelayCommand(Save);
            CancelCommand = new RelayCommand(Cancel);
        }

        // Edit mode constructor
        public AddSurgeonViewModel(Surgeon surgeonToEdit)
        {
            _store = App.SurgeonStore;
            _originalSurgeon = surgeonToEdit;
            _isEditMode = true;

            SurgeonId = surgeonToEdit.SurgeonId;
            Name = surgeonToEdit.Name;
            Department = surgeonToEdit.Department;
            Email = surgeonToEdit.Email;
            ContactNo = surgeonToEdit.ContactNo;
            Specialization = surgeonToEdit.Specialization;
            Experience = surgeonToEdit.Experience;
            Availability = surgeonToEdit.Availability;

            EnsureOptionExists(DepartmentOptions, Department);
            EnsureOptionExists(AvailabilityOptions, Availability);

            SaveCommand = new RelayCommand(Save);
            CancelCommand = new RelayCommand(Cancel);
        }

        private string GenerateSurgeonId()
        {
            int nextNumber = _store.Surgeons.Count + 1;

            while (_store.Surgeons.Any(s => s.SurgeonId == $"SURG{nextNumber:000}"))
            {
                nextNumber++;
            }

            return $"SURG{nextNumber:000}";
        }

        private void Save()
        {
            bool isValid = ValidateAll();

            if (!isValid)
                return;

            if (_isEditMode && _originalSurgeon != null)
            {
                _originalSurgeon.Name = Name.Trim();
                _originalSurgeon.Department = Department.Trim();
                _originalSurgeon.Email = Email.Trim();
                _originalSurgeon.ContactNo = ContactNo.Trim();
                _originalSurgeon.Specialization = Specialization.Trim();
                _originalSurgeon.Experience = Experience.Trim();
                _originalSurgeon.Availability = string.IsNullOrWhiteSpace(Availability)
                    ? "Available"
                    : Availability.Trim();
            }
            else
            {
                var surgeon = new Surgeon
                {
                    SurgeonId = SurgeonId,
                    Name = Name.Trim(),
                    Department = Department.Trim(),
                    Email = Email.Trim(),
                    ContactNo = ContactNo.Trim(),
                    Specialization = Specialization.Trim(),
                    Experience = Experience.Trim(),
                    Availability = string.IsNullOrWhiteSpace(Availability)
                        ? "Available"
                        : Availability.Trim()
                };

                _store.Surgeons.Add(surgeon);
            }

            CloseAction?.Invoke();
        }

        private bool ValidateAll()
        {
            ValidateName();
            ValidateDepartment();
            ValidateSpecialization();
            ValidateExperience();
            ValidateEmail();
            ValidateContactNo();

            return string.IsNullOrWhiteSpace(NameError)
                && string.IsNullOrWhiteSpace(DepartmentError)
                && string.IsNullOrWhiteSpace(SpecializationError)
                && string.IsNullOrWhiteSpace(ExperienceError)
                && string.IsNullOrWhiteSpace(EmailError)
                && string.IsNullOrWhiteSpace(ContactNoError);
        }

        private void ValidateName()
        {
            if (string.IsNullOrWhiteSpace(Name))
            {
                NameError = "Surgeon Name is required.";
                return;
            }

            if (Name.Trim().Length <= 1)
            {
                NameError = "Surgeon Name should be greater than a single character.";
                return;
            }

            if (Name.Trim().Length > 50)
            {
                NameError = "Surgeon Name should not exceed 50 characters.";
                return;
            }

            NameError = string.Empty;
        }

        private void ValidateDepartment()
        {
            if (string.IsNullOrWhiteSpace(Department))
            {
                DepartmentError = "Department is required.";
                return;
            }

            if (!DepartmentOptions.Contains(Department))
            {
                DepartmentError = "Department must be selected from the predefined list.";
                return;
            }

            DepartmentError = string.Empty;
        }

        private void ValidateSpecialization()
        {
            if (string.IsNullOrWhiteSpace(Specialization))
            {
                SpecializationError = "Specialization is required.";
                return;
            }

            SpecializationError = string.Empty;
        }

        private void ValidateExperience()
        {
            if (string.IsNullOrWhiteSpace(Experience))
            {
                ExperienceError = "Experience is required.";
                return;
            }

            ExperienceError = string.Empty;
        }

        private void ValidateEmail()
        {
            if (string.IsNullOrWhiteSpace(Email))
            {
                EmailError = "Email is required.";
                return;
            }

            if (!Regex.IsMatch(
                    Email.Trim(),
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase))
            {
                EmailError = "Email must contain a valid format with @ and domain.";
                return;
            }

            EmailError = string.Empty;
        }

        private void ValidateContactNo()
        {
            if (string.IsNullOrWhiteSpace(ContactNo))
            {
                ContactNoError = "Phone Number is required.";
                return;
            }

            if (!Regex.IsMatch(ContactNo.Trim(), @"^\d{10}$"))
            {
                ContactNoError = "Phone Number must be numeric and exactly 10 digits.";
                return;
            }

            ContactNoError = string.Empty;
        }

        private static void EnsureOptionExists(ObservableCollection<string> list, string value)
        {
            if (!string.IsNullOrWhiteSpace(value) && !list.Contains(value))
            {
                list.Insert(0, value);
            }
        }

        private void Cancel()
        {
            CloseAction?.Invoke();
        }

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

using System;
using System.Windows;
using System.Windows.Media;

namespace HealthHubApplication.ViewModels.Home
{
    public static class PieGeometryHelper
    {
        public const double ChartSize = 300;

        private const double CenterX = ChartSize / 2;
        private const double CenterY = ChartSize / 2;

        private const double OuterRadius = 140;
        private const double InnerRadius = 90;

        public static Geometry CreateSlice(double startAngle, double sweepAngle)
        {
            if (sweepAngle <= 0)
            {
                return Geometry.Empty;
            }

            if (sweepAngle >= 359.99)
            {
                return CreateFullDonut();
            }

            double startRadians = startAngle * Math.PI / 180;
            double endRadians = (startAngle + sweepAngle) * Math.PI / 180;

            Point outerStart = new Point(
                CenterX + OuterRadius * Math.Cos(startRadians),
                CenterY + OuterRadius * Math.Sin(startRadians));

            Point outerEnd = new Point(
                CenterX + OuterRadius * Math.Cos(endRadians),
                CenterY + OuterRadius * Math.Sin(endRadians));

            Point innerStart = new Point(
                CenterX + InnerRadius * Math.Cos(startRadians),
                CenterY + InnerRadius * Math.Sin(startRadians));

            Point innerEnd = new Point(
                CenterX + InnerRadius * Math.Cos(endRadians),
                CenterY + InnerRadius * Math.Sin(endRadians));

            bool largeArc = sweepAngle > 180;

            PathFigure figure = new PathFigure
            {
                StartPoint = outerStart,
                IsClosed = true
            };

            figure.Segments.Add(
                new ArcSegment(
                    outerEnd,
                    new Size(OuterRadius, OuterRadius),
                    0,
                    largeArc,
                    SweepDirection.Clockwise,
                    true));

            figure.Segments.Add(
                new LineSegment(
                    innerEnd,
                    true));

            figure.Segments.Add(
                new ArcSegment(
                    innerStart,
                    new Size(InnerRadius, InnerRadius),
                    0,
                    largeArc,
                    SweepDirection.Counterclockwise,
                    true));

            PathGeometry geometry = new PathGeometry();
            geometry.Figures.Add(figure);

            return geometry;
        }

        private static Geometry CreateFullDonut()
        {
            GeometryGroup group = new GeometryGroup
            {
                FillRule = FillRule.EvenOdd
            };

            group.Children.Add(
                new EllipseGeometry(
                    new Point(CenterX, CenterY),
                    OuterRadius,
                    OuterRadius));

            group.Children.Add(
                new EllipseGeometry(
                    new Point(CenterX, CenterY),
                    InnerRadius,
                    InnerRadius));

            return group;
        }
    }
}

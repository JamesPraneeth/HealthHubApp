using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using HealthHub.App.Services;
using HealthHub.Domain.Entities;
using Microsoft.Win32;

namespace HealthHubApplication.ViewModels.OT
{
    /// <summary>
    /// OTViewModel rewritten to store PatientId / SurgeonId as foreign keys
    /// in ICUAdmission, OPDAppointment and OTScheduledSurgery rather than
    /// duplicating name strings. Display names are resolved by RoomStore on
    /// load / save, and re-resolved here after each booking.
    /// The UI dropdowns now expose:
    ///   DoctorList  → ObservableCollection&lt;Surgeon&gt;  (bind to SurgeonId, display Name)
    ///   PatientList → ObservableCollection&lt;Patient&gt;  (bind to PatientId, display Name)
    /// so the user still sees names but the persisted value is the ID.
    /// </summary>
    public class OTViewModel : System.ComponentModel.INotifyPropertyChanged
    {
        private readonly RoomStore   _roomStore;
        private readonly PatientStore _patientStore;
        private readonly SurgeonStore _surgeonStore;

        private string _selectedRoomType = string.Empty;
        private string _selectedRoomName = string.Empty;
        private string _selectedOT       = string.Empty;
        private string _selectedProcedure = string.Empty;
        private DateTime? _selectedDate;
        private string _selectedStartHour   = string.Empty;
        private string _selectedStartMinute = string.Empty;
        private string _selectedEndHour     = string.Empty;
        private string _selectedEndMinute   = string.Empty;
        private string _surgeryDocument     = string.Empty;
        private string _scheduleStatus      = "Please select room type.";
        private bool   _isSurgeryActive;
        private bool   _isRefreshingScheduledSurgeries;

        // FK selections (store IDs, not names)
        private string _selectedSurgeonId = string.Empty;
        private string _selectedPatientId = string.Empty;
        private string _icuPatientId      = string.Empty;
        private string _opdPatientId      = string.Empty;
        private string _opdSurgeonId      = string.Empty;

        private DateTime? _icuStartDate;
        private DateTime? _icuEndDate;
        private DateTime? _opdDate;
        private string    _opdTime   = string.Empty;
        private string    _opdReason = string.Empty;

        private HospitalRoom?       _selectedRoom;
        private OTScheduledSurgery? _selectedScheduledSurgery;

        private readonly DispatcherTimer _timer;
        private readonly ObservableCollection<OTScheduledSurgery> _allScheduledSurgeries = new();

        // ── Collections ───────────────────────────────────────────────────
        public ObservableCollection<string> RoomTypes { get; } = new() { "OT", "OPD", "ICU" };
        public ObservableCollection<string> RoomNames { get; } = new();

        /// Exposed to XAML: bind DisplayMemberPath=Name, SelectedValuePath=SurgeonId
        public ObservableCollection<Surgeon> DoctorList { get; } = new();
        /// Exposed to XAML: bind DisplayMemberPath=Name, SelectedValuePath=PatientId
        public ObservableCollection<Patient> PatientList { get; } = new();

        public ObservableCollection<string>           ProcedureList { get; } = new();
        public ObservableCollection<string>           HourOptions   { get; } = new();
        public ObservableCollection<string>           MinuteOptions { get; } = new();
        public ObservableCollection<HospitalRoom>     RoomList      => _roomStore.Rooms;
        public ObservableCollection<OTScheduledSurgery> VisibleScheduledSurgeries { get; } = new();
        public ObservableCollection<SurgicalLog>      VisibleSurgeryLogs { get; } = new();
        public ObservableCollection<ICUAdmission>     VisibleICUPatients { get; } = new();
        public ObservableCollection<OPDAppointment>   VisibleOPDPatients { get; } = new();

        // ── Commands ──────────────────────────────────────────────────────
        public ICommand ScheduleSurgeryCommand { get; }
        public ICommand EndSurgeryCommand      { get; }
        public ICommand AddICUPatientCommand   { get; }
        public ICommand AddOPDPatientCommand   { get; }

        public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;

        public OTViewModel()
        {
            _roomStore    = App.RoomStore;
            _patientStore = App.PatientStore;
            _surgeonStore = App.SurgeonStore;

            LoadRoomConfiguration();
            RefreshDoctorList();
            RefreshPatientList();
            LoadProcedures();
            LoadTimeOptions();

            _patientStore.Patients.CollectionChanged += (s, e) => RefreshPatientList();
            _surgeonStore.Surgeons.CollectionChanged += (s, e) => RefreshDoctorList();

            ScheduleSurgeryCommand = new RelayCommand(ScheduleSurgery);
            EndSurgeryCommand      = new RelayCommand(EndSurgery);
            AddICUPatientCommand   = new RelayCommand(AddICUPatient);
            AddOPDPatientCommand   = new RelayCommand(AddOPDPatient);

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        // ── Properties ────────────────────────────────────────────────────
        public string SelectedRoomType
        {
            get => _selectedRoomType;
            set
            {
                if (_selectedRoomType == value) return;
                _selectedRoomType = value; OnPropertyChanged(nameof(SelectedRoomType));
                SelectedRoomName = string.Empty; SelectedRoom = null;
                LoadRoomsByType(); ClearVisibleData();
                ScheduleStatus = string.IsNullOrWhiteSpace(value) ? "Please select room type." : $"Selected {value}.";
                NotifyVisibility();
                OnPropertyChanged(nameof(IsRoomSelectionVisible));
            }
        }

        public bool IsRoomSelectionVisible => SelectedRoomType != "OPD";

        public string SelectedRoomName
        {
            get => _selectedRoomName;
            set { if (_selectedRoomName == value) return; _selectedRoomName = value; OnPropertyChanged(nameof(SelectedRoomName)); SetSelectedRoomFromTypeAndName(); }
        }

        public HospitalRoom? SelectedRoom
        {
            get => _selectedRoom;
            set
            {
                if (_selectedRoom == value) return;
                _selectedRoom = value; OnPropertyChanged(nameof(SelectedRoom));
                SelectedOT = _selectedRoom?.RoomName ?? string.Empty;
                SelectedScheduledSurgery = null; SurgeryDocument = string.Empty; IsSurgeryActive = false;
                ClearICUInputs(); ClearOPDInputs();
                RefreshRoomData();
                ScheduleStatus = _selectedRoom == null ? "Please select room." : $"Selected {_selectedRoom.DisplayName}.";
                NotifyVisibility();
            }
        }

        public string SelectedOT
        {
            get => _selectedOT;
            set { if (_selectedOT == value) return; _selectedOT = value; OnPropertyChanged(nameof(SelectedOT)); RefreshVisibleScheduledSurgeries(); RefreshVisibleLogs(); }
        }

        // Doctor selected as SurgeonId
        public string SelectedSurgeonId
        {
            get => _selectedSurgeonId;
            set { if (_selectedSurgeonId == value) return; _selectedSurgeonId = value; OnPropertyChanged(nameof(SelectedSurgeonId)); }
        }

        // Patient selected as PatientId
        public string SelectedPatientId
        {
            get => _selectedPatientId;
            set { if (_selectedPatientId == value) return; _selectedPatientId = value; OnPropertyChanged(nameof(SelectedPatientId)); }
        }

        public string SelectedProcedure
        {
            get => _selectedProcedure;
            set { if (_selectedProcedure == value) return; _selectedProcedure = value; OnPropertyChanged(nameof(SelectedProcedure)); }
        }

        public DateTime? SelectedDate
        {
            get => _selectedDate;
            set { if (_selectedDate == value) return; _selectedDate = value; OnPropertyChanged(nameof(SelectedDate)); }
        }

        public string SelectedStartHour { get => _selectedStartHour; set { _selectedStartHour = value; OnPropertyChanged(nameof(SelectedStartHour)); } }
        public string SelectedStartMinute { get => _selectedStartMinute; set { _selectedStartMinute = value; OnPropertyChanged(nameof(SelectedStartMinute)); } }
        public string SelectedEndHour { get => _selectedEndHour; set { _selectedEndHour = value; OnPropertyChanged(nameof(SelectedEndHour)); } }
        public string SelectedEndMinute { get => _selectedEndMinute; set { _selectedEndMinute = value; OnPropertyChanged(nameof(SelectedEndMinute)); } }
        public string SurgeryDocument { get => _surgeryDocument; set { _surgeryDocument = value; OnPropertyChanged(nameof(SurgeryDocument)); } }
        public string ScheduleStatus { get => _scheduleStatus; set { _scheduleStatus = value; OnPropertyChanged(nameof(ScheduleStatus)); } }
        public bool IsSurgeryActive { get => _isSurgeryActive; set { _isSurgeryActive = value; OnPropertyChanged(nameof(IsSurgeryActive)); } }

        public OTScheduledSurgery? SelectedScheduledSurgery
        {
            get => _selectedScheduledSurgery;
            set
            {
                if (_isRefreshingScheduledSurgeries && value == null) return;
                if (_selectedScheduledSurgery == value) return;
                _selectedScheduledSurgery = value; OnPropertyChanged(nameof(SelectedScheduledSurgery));
                SurgeryDocument = string.Empty; UpdateSurgeryActiveState();
            }
        }

        // ICU inputs (PatientId)
        public string ICUPatientId { get => _icuPatientId; set { _icuPatientId = value; OnPropertyChanged(nameof(ICUPatientId)); } }
        public DateTime? ICUStartDate { get => _icuStartDate; set { _icuStartDate = value; OnPropertyChanged(nameof(ICUStartDate)); } }
        public DateTime? ICUEndDate   { get => _icuEndDate;   set { _icuEndDate   = value; OnPropertyChanged(nameof(ICUEndDate)); } }

        // OPD inputs (PatientId + SurgeonId)
        public string OPDPatientId { get => _opdPatientId; set { _opdPatientId = value; OnPropertyChanged(nameof(OPDPatientId)); } }
        public string OPDSurgeonId { get => _opdSurgeonId; set { _opdSurgeonId = value; OnPropertyChanged(nameof(OPDSurgeonId)); } }
        public DateTime? OPDDate { get => _opdDate; set { _opdDate = value; OnPropertyChanged(nameof(OPDDate)); } }
        public string OPDTime   { get => _opdTime;   set { _opdTime   = value; OnPropertyChanged(nameof(OPDTime)); } }
        public string OPDReason { get => _opdReason; set { _opdReason = value; OnPropertyChanged(nameof(OPDReason)); } }

        // Visibility
        public Visibility OTMenuVisibility    => SelectedRoom?.RoomType == "OT"  ? Visibility.Visible : Visibility.Collapsed;
        public Visibility ICUMenuVisibility   => SelectedRoom?.RoomType == "ICU" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility OPDMenuVisibility   => SelectedRoom?.RoomType == "OPD" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility OTSurgeryGridVisibility  => SelectedRoom?.RoomType == "OT"  ? Visibility.Visible : Visibility.Collapsed;
        public Visibility ICUPatientGridVisibility => SelectedRoom?.RoomType == "ICU" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility OPDPatientGridVisibility => SelectedRoom?.RoomType == "OPD" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility SurgeryDocumentationVisibility => SelectedRoom?.RoomType == "OT" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility SurgeryLogsVisibility          => SelectedRoom?.RoomType == "OT" ? Visibility.Visible : Visibility.Collapsed;

        // ── Private helpers ───────────────────────────────────────────────
        private void RefreshDoctorList()
        {
            DoctorList.Clear();
            foreach (var s in _surgeonStore.Surgeons.Where(s => !string.IsNullOrWhiteSpace(s.Name)).OrderBy(s => s.Name))
                DoctorList.Add(s);
        }

        private void RefreshPatientList()
        {
            PatientList.Clear();
            foreach (var p in _patientStore.Patients.Where(p => !string.IsNullOrWhiteSpace(p.Name)).OrderBy(p => p.Name))
                PatientList.Add(p);
        }

        private void LoadRoomConfiguration()
        {
            _allScheduledSurgeries.Clear();
            if (RoomList.Count == 0) EnsureDefaultRooms();
            EnsureDefaultRooms();
            foreach (var room in RoomList.Where(r => r.RoomType == "OT"))
                foreach (var s in room.OTSurgeries)
                { s.OTName = room.RoomName; _allScheduledSurgeries.Add(s); }
        }

        private void EnsureDefaultRooms()
        {
            EnsureRoom("OT",  "OT-1",  1);  EnsureRoom("OT",  "OT-2",  1);  EnsureRoom("OT",  "OT-3",  1);
            EnsureRoom("OT",  "OT-4",  1);  EnsureRoom("OT",  "OT-5",  1);
            EnsureRoom("OPD", "OPD-1", 30);
            EnsureRoom("ICU", "ICU-1", 10); EnsureRoom("ICU", "ICU-2", 10); EnsureRoom("ICU", "ICU-3", 10);
        }

        private void EnsureRoom(string type, string name, int cap)
        {
            if (!RoomList.Any(r => r.RoomType == type && r.RoomName == name))
                RoomList.Add(new HospitalRoom { RoomType = type, RoomName = name, MaxCapacity = cap });
        }

        private void LoadRoomsByType()
        {
            RoomNames.Clear();
            foreach (var name in RoomList.Where(r => r.RoomType == SelectedRoomType).Select(r => r.RoomName).OrderBy(n => n))
                RoomNames.Add(name);
        }

        private void SetSelectedRoomFromTypeAndName()
        {
            if (string.IsNullOrWhiteSpace(SelectedRoomType) || string.IsNullOrWhiteSpace(SelectedRoomName)) { SelectedRoom = null; return; }
            var room = RoomList.FirstOrDefault(r => r.RoomType == SelectedRoomType && r.RoomName == SelectedRoomName);
            if (room == null) { room = new HospitalRoom { RoomType = SelectedRoomType, RoomName = SelectedRoomName }; RoomList.Add(room); }
            SelectedRoom = room;
        }

        private void LoadProcedures()
        {
            ProcedureList.Clear();
            foreach (var p in new[] { "Appendectomy", "Coronary Artery Bypass Grafting", "Knee Replacement", "Hip Replacement", "Cataract Surgery", "Cesarean Section", "Gallbladder Removal", "Hernia Repair", "Tonsillectomy", "Angioplasty", "Spinal Fusion", "Laparoscopic Surgery" })
                ProcedureList.Add(p);
        }

        private void LoadTimeOptions()
        {
            HourOptions.Clear(); MinuteOptions.Clear();
            for (int h = 0; h < 24; h++) HourOptions.Add($"{h:00}");
            for (int m = 0; m < 60; m++) MinuteOptions.Add($"{m:00}");
        }

        private void RefreshRoomData()
        {
            ClearVisibleData();
            if (SelectedRoom == null) return;
            if (SelectedRoom.RoomType == "OT") { RefreshVisibleScheduledSurgeries(); RefreshVisibleLogs(); }
            else if (SelectedRoom.RoomType == "ICU") { foreach (var p in SelectedRoom.ICUPatients) VisibleICUPatients.Add(p); }
            else if (SelectedRoom.RoomType == "OPD") { foreach (var p in SelectedRoom.OPDPatients) VisibleOPDPatients.Add(p); }
        }

        private void ClearVisibleData()
        {
            VisibleScheduledSurgeries.Clear(); VisibleSurgeryLogs.Clear();
            VisibleICUPatients.Clear(); VisibleOPDPatients.Clear();
        }

        private void SaveRooms() => _roomStore.SaveRooms();

        private void AddICUPatient()
        {
            if (SelectedRoom?.RoomType != "ICU") { MessageBox.Show("Please select an ICU room."); return; }
            if (SelectedRoom.AvailableICUBeds <= 0) { MessageBox.Show($"ICU full. Max capacity {SelectedRoom.MaxCapacity}."); return; }
            if (string.IsNullOrWhiteSpace(ICUPatientId)) { MessageBox.Show("Please select a patient."); return; }
            if (!ICUStartDate.HasValue) { MessageBox.Show("Please select start date."); return; }
            if (!ICUEndDate.HasValue)   { MessageBox.Show("Please select end date."); return; }
            if (ICUEndDate.Value.Date < ICUStartDate.Value.Date) { MessageBox.Show("End date must be on or after start date."); return; }

            var admission = new ICUAdmission
            {
                PatientId = ICUPatientId,
                StartDate = ICUStartDate.Value.Date,
                EndDate   = ICUEndDate.Value.Date
            };
            // Resolve display name immediately
            _roomStore.ResolveRoomNames(SelectedRoom);
            SelectedRoom.ICUPatients.Add(admission);
            _roomStore.ResolveRoomNames(SelectedRoom); // resolve name for the new entry
            VisibleICUPatients.Add(admission);
            SaveRooms();
            ClearICUInputs();
            ScheduleStatus = "ICU patient added successfully.";
            StatusService.Publish($"ICU Room Booked: {SelectedRoom.RoomName} for {admission.PatientName} from {admission.StartDate:dd MMM yyyy} to {admission.EndDate:dd MMM yyyy}.");
        }

        private void AddOPDPatient()
        {
            if (SelectedRoom?.RoomType != "OPD") { MessageBox.Show("Please select an OPD room."); return; }
            if (SelectedRoom.AvailableOPDSlots <= 0) { MessageBox.Show($"OPD full. Max capacity {SelectedRoom.MaxCapacity}."); return; }
            if (string.IsNullOrWhiteSpace(OPDPatientId))  { MessageBox.Show("Please select a patient."); return; }
            if (string.IsNullOrWhiteSpace(OPDSurgeonId))  { MessageBox.Show("Please select a physician."); return; }
            if (!OPDDate.HasValue)                         { MessageBox.Show("Please select date."); return; }
            if (string.IsNullOrWhiteSpace(OPDTime))        { MessageBox.Show("Please enter time."); return; }
            if (string.IsNullOrWhiteSpace(OPDReason))      { MessageBox.Show("Please enter reason."); return; }

            var appt = new OPDAppointment
            {
                PatientId = OPDPatientId,
                SurgeonId = OPDSurgeonId,
                Date   = OPDDate.Value.Date,
                Time   = OPDTime,
                Reason = OPDReason
            };
            SelectedRoom.OPDPatients.Add(appt);
            _roomStore.ResolveRoomNames(SelectedRoom);
            VisibleOPDPatients.Add(appt);
            SaveRooms();
            ClearOPDInputs();
            ScheduleStatus = "OPD patient added successfully.";
            StatusService.Publish($"OPD Booked: {SelectedRoom.RoomName} for {appt.PatientName} with {appt.PhysicianName} on {appt.Date:dd MMM yyyy} at {appt.Time}.");
        }

        private void ScheduleSurgery()
        {
            if (SelectedRoom?.RoomType != "OT")             { MessageBox.Show("Please select an OT room."); return; }
            if (string.IsNullOrWhiteSpace(SelectedSurgeonId)) { MessageBox.Show("Please select a primary surgeon."); return; }
            if (string.IsNullOrWhiteSpace(SelectedPatientId)) { MessageBox.Show("Please select a patient."); return; }
            if (string.IsNullOrWhiteSpace(SelectedProcedure)) { MessageBox.Show("Please select a procedure."); return; }
            if (!SelectedDate.HasValue)                        { MessageBox.Show("Please select surgery date."); return; }
            if (string.IsNullOrWhiteSpace(SelectedStartHour) || string.IsNullOrWhiteSpace(SelectedStartMinute)) { MessageBox.Show("Please select start time."); return; }
            if (string.IsNullOrWhiteSpace(SelectedEndHour)   || string.IsNullOrWhiteSpace(SelectedEndMinute))   { MessageBox.Show("Please select end time."); return; }

            var start = BuildDateTime(SelectedDate.Value, SelectedStartHour, SelectedStartMinute);
            var end   = BuildDateTime(SelectedDate.Value, SelectedEndHour,   SelectedEndMinute);
            if (end <= start) { MessageBox.Show("End time must be greater than start time."); return; }

            bool overlaps = _allScheduledSurgeries.Any(s => s.OTName == SelectedOT && !s.IsCompleted && start < s.EndDateTime && end > s.StartDateTime);
            if (overlaps) { MessageBox.Show("This OT already has a surgery scheduled during the selected time."); return; }

            var surgery = new OTScheduledSurgery
            {
                OTName        = SelectedOT,
                SurgeryDate   = SelectedDate.Value.Date,
                StartDateTime = start,
                EndDateTime   = end,
                SurgeonId     = SelectedSurgeonId,
                PatientId     = SelectedPatientId,
                ProcedureName = SelectedProcedure,
                IsCompleted   = false
            };

            _allScheduledSurgeries.Add(surgery);
            SelectedRoom.OTSurgeries.Add(surgery);
            _roomStore.ResolveRoomNames(SelectedRoom); // resolve names on the new entry
            SaveRooms();
            RefreshVisibleScheduledSurgeries();
            SelectedScheduledSurgery = surgery;
            ScheduleStatus = "Surgery scheduled successfully.";
            StatusService.Publish($"OT Booked: {surgery.OTName} for {surgery.PatientName} with {surgery.PrimarySurgeonName} on {surgery.StartDateTime:dd MMM yyyy, hh:mm tt}.");
        }

        private void EndSurgery() => CompleteSelectedSurgery();

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (SelectedRoom?.RoomType != "OT") return;
            RefreshVisibleScheduledSurgeries();
            var surgery = SelectedScheduledSurgery;
            if (surgery == null) { IsSurgeryActive = false; return; }
            UpdateSurgeryActiveState();
            if (!surgery.IsCompleted && DateTime.Now > surgery.EndDateTime) CompleteSelectedSurgery();
        }

        private void UpdateSurgeryActiveState()
        {
            if (SelectedRoom?.RoomType != "OT") { IsSurgeryActive = false; return; }
            if (SelectedScheduledSurgery == null) { IsSurgeryActive = false; ScheduleStatus = $"Selected {SelectedOT}. Please schedule surgery."; return; }
            if (SelectedScheduledSurgery.IsCompleted) { IsSurgeryActive = false; ScheduleStatus = "Selected surgery is already completed."; return; }
            var now = DateTime.Now;
            if (now < SelectedScheduledSurgery.StartDateTime) { IsSurgeryActive = false; ScheduleStatus = $"Surgery scheduled for {SelectedScheduledSurgery.StartDateTime:dd/MM/yyyy HH:mm}. Documentation enabled at start time."; return; }
            if (now >= SelectedScheduledSurgery.StartDateTime && now <= SelectedScheduledSurgery.EndDateTime) { IsSurgeryActive = true; ScheduleStatus = "Surgery is active. Documentation is enabled."; return; }
            IsSurgeryActive = false; ScheduleStatus = "Surgery time completed. Documentation is disabled.";
        }

        private void CompleteSelectedSurgery()
        {
            var surgery = SelectedScheduledSurgery;
            if (surgery == null) { MessageBox.Show("Please select a scheduled surgery."); return; }
            if (surgery.IsCompleted) return;
            if (DateTime.Now < surgery.StartDateTime) { MessageBox.Show("Surgery has not started yet."); return; }

            TimeSpan duration = surgery.EndDateTime - surgery.StartDateTime;

            var dlg = new SaveFileDialog
            {
                Title = "Save Surgery Document",
                FileName = $"{surgery.OTName}_{surgery.PatientName}_{surgery.ProcedureName}_SurgeryDocument",
                DefaultExt = ".txt",
                Filter = "Text File (*.txt)|*.txt"
            };

            if (dlg.ShowDialog() == true)
            {
                string doc = string.IsNullOrWhiteSpace(SurgeryDocument) ? "(No documentation entered.)" : SurgeryDocument;
                string content =
$@"Surgery Documentation
----------------------
OT: {surgery.OTName}
Date: {surgery.SurgeryDate:dd/MM/yyyy}
Start Time: {surgery.StartDateTime:HH:mm}
End Time: {surgery.EndDateTime:HH:mm}
Duration: {duration.Hours}h {duration.Minutes}m
Primary Surgeon: {surgery.PrimarySurgeonName}
Patient: {surgery.PatientName}
Procedure: {surgery.ProcedureName}

Documentation:
{doc}";
                File.WriteAllText(dlg.FileName, content);

                surgery.IsCompleted = true;
                SaveRooms();

                _roomStore.AddSurgicalLog(new SurgicalLog
                {
                    OTName        = surgery.OTName,
                    SurgeryDate   = surgery.SurgeryDate,
                    Duration      = $"{duration.Hours}h {duration.Minutes}m",
                    SurgeonId     = surgery.SurgeonId,
                    PatientId     = surgery.PatientId,
                    ProcedureName = surgery.ProcedureName,
                    DocumentName  = Path.GetFileName(dlg.FileName)
                });

                SurgeryDocument = string.Empty; IsSurgeryActive = false; SelectedScheduledSurgery = null;
                RefreshVisibleScheduledSurgeries(); RefreshVisibleLogs();
                ScheduleStatus = "Surgery completed and document saved.";
                StatusService.Publish($"OT Released: {surgery.OTName} surgery for {surgery.PatientName} completed.");
                MessageBox.Show("Surgery document saved successfully.");
            }
        }

        private void RefreshVisibleScheduledSurgeries()
        {
            if (SelectedRoom?.RoomType != "OT") return;
            var prev = SelectedScheduledSurgery;
            _isRefreshingScheduledSurgeries = true;
            VisibleScheduledSurgeries.Clear();
            foreach (var s in _allScheduledSurgeries.Where(s => s.OTName == SelectedOT).OrderBy(s => s.StartDateTime))
                VisibleScheduledSurgeries.Add(s);
            _isRefreshingScheduledSurgeries = false;
            if (prev != null && VisibleScheduledSurgeries.Contains(prev)) SelectedScheduledSurgery = prev;
        }

        private void RefreshVisibleLogs()
        {
            if (SelectedRoom?.RoomType != "OT") return;
            VisibleSurgeryLogs.Clear();
            foreach (var l in _roomStore.SurgicalLogs.Where(l => l.OTName == SelectedOT).OrderByDescending(l => l.SurgeryDate))
                VisibleSurgeryLogs.Add(l);
        }

        private void ClearICUInputs() { ICUPatientId = string.Empty; ICUStartDate = null; ICUEndDate = null; }
        private void ClearOPDInputs() { OPDPatientId = string.Empty; OPDSurgeonId = string.Empty; OPDDate = null; OPDTime = string.Empty; OPDReason = string.Empty; }
        private void NotifyVisibility() { foreach (var n in new[] { nameof(OTMenuVisibility), nameof(ICUMenuVisibility), nameof(OPDMenuVisibility), nameof(OTSurgeryGridVisibility), nameof(ICUPatientGridVisibility), nameof(OPDPatientGridVisibility), nameof(SurgeryDocumentationVisibility), nameof(SurgeryLogsVisibility) }) OnPropertyChanged(n); }
        private DateTime BuildDateTime(DateTime date, string h, string m) => date.Date.AddHours(int.Parse(h)).AddMinutes(int.Parse(m));
        private void OnPropertyChanged(string p) => PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(p));
    }
}

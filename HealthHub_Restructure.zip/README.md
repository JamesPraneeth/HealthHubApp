# HealthHub Restructuring — Placement Guide

This package contains the XAML view files pulled out of your old
`PatientInformationSystem` project, split into individual files and organized
to match the folders in your new solution.

## What's in this zip

```
HealthHub.App.Views/
    Views/
        About/AboutView.xaml
        AddPatient/AddPatientView.xaml
        AddPatient/AddPatientWindow.xaml
        AddSurgeon/AddSurgeonView.xaml
        Header/HeaderView.xaml
        Home/HomeView.xaml
        Login/LoginView.xaml
        Login/RegisterView.xaml
        Navigation/SideNavView.xaml
        OT/OTView.xaml
        PatientDetails/EditPatientWindow.xaml
        PatientDetails/PatientDetailsView.xaml
        SearchBar/SearchBarView.xaml
        SurgeonDetails/SurgeonDetailsView.xaml
        SurgeonSearchBar/SurgeonSearchBarView.xaml
HealthHub/
    App.xaml
    MainWindow.xaml
    Resources/ThemeResources.xaml
```

## Where each folder goes in your solution

| This package's path | Copy into your solution at |
|---|---|
| `HealthHub.App.Views/Views/*` | `HealthHub.App.Views/Views/*` (your Views class-library project) |
| `HealthHub/App.xaml` | `HealthHub/App.xaml` (your WPF executable project) — **see warning below** |
| `HealthHub/MainWindow.xaml` | `HealthHub/MainWindow.xaml` (your WPF executable project) — **see warning below** |
| `HealthHub/Resources/ThemeResources.xaml` | `HealthHub/Resources/ThemeResources.xaml` |

⚠️ **Don't blindly overwrite yet.** Your current tree already shows
`App.xaml.cs` and `MainWindow.xaml.cs` existing in `HealthHub/` — meaning
you've already started on these. Diff the incoming `App.xaml` /
`MainWindow.xaml` against what you have before replacing them, so you don't
lose work.

⚠️ **Project-folder mismatch to double-check.** In the structure you sent,
`HealthHub.App.Views.csproj` physically sits *inside* the `HealthHub/`
folder, alongside `App.xaml`/`MainWindow.xaml`. Normally each `.csproj`
lives in its own project folder. Before copying files in, confirm which of
these is true for your actual solution:
- `HealthHub.App.Views.csproj` really is meant to live in a **separate**
  `HealthHub.App.Views/` folder (the layout this guide assumes), or
- Everything (exe + views) is intentionally one physical folder, in which
  case put the `Views/` subfolder from this package straight into your
  existing `HealthHub/Views/` instead of a separate project.

## Namespace changes you'll need to make

All files still say `PatientInformationSystem.*` — they were **not**
rewritten, since I don't have the matching ViewModels/code-behind and
didn't want to break the class ↔ code-behind pairing blindly. When you wire
these in, update:

- `x:Class="PatientInformationSystem.<Sub>.<Name>"` → `x:Class="HealthHub.App.Views.<Sub>.<Name>"` in every file
- The matching `.xaml.cs` code-behind's `namespace` declaration, to match
- Cross-references between views, since a few files pull in other views by
  `clr-namespace`:
  - `MainWindow.xaml` → `xmlns:header="clr-namespace:PatientInformationSystem.Header"` and `xmlns:nav="clr-namespace:PatientInformationSystem.Navigation"`
  - `AddPatientWindow.xaml` → `xmlns:add="clr-namespace:PatientInformationSystem.AddPatient"`
  - `HomeView.xaml` → `xmlns:infra="clr-namespace:PatientInformationSystem.Infrastructure"` (for `StatusToTimeConverter` — see below)

  Since Views now live in a **different assembly** (`HealthHub.App.Views`)
  from `MainWindow.xaml` (in `HealthHub`), these clr-namespace declarations
  need an assembly qualifier added, e.g.:
  ```xaml
  xmlns:header="clr-namespace:HealthHub.App.Views.Header;assembly=HealthHub.App.Views"
  ```
- `SideNavView.xaml` loads an image via
  `pack://application:,,,/PatientInformationSystem;component/Resources/Images/stethoscope.png`
  — update `PatientInformationSystem` to whatever assembly the image
  actually ships in once you decide where `Resources/Images` lives.

## Still missing (needed before this will compile/run)

I only had the raw `.xaml` markup to work with — none of this was included
in what you gave me, so the app won't build without it:

- **ViewModels** for every view (`LoginViewModel`, `HomeViewModel`,
  `OTViewModel`, `PatientDetailsViewModel`, `SurgeonDetailsViewModel`, etc.)
  → these belong in `HealthHub/ViewModels/`
- **Code-behind** (`.xaml.cs`) for each view/window above
  (`LoginView.xaml.cs`, `OTView.xaml.cs`, etc.)
- **`StatusToTimeConverter`** (and any other converters referenced) →
  belongs in `HealthHub/Converters/`
- Confirm `HealthHub.Domain.Entities` / `HealthHub.Domain.Repositories`
  (which you say are already added) are referenced by
  `HealthHub.App.Services` and `HealthHub` so the Views' bindings can
  actually resolve at runtime.

Once you've placed these files and have the ViewModels/code-behind ready,
send them over and I can do the actual namespace rewrite + reference
wiring end-to-end.

using System;
using System.Xml.Serialization;

namespace HealthHub.Domain.Entities
{
    public class OTScheduledSurgery
    {
        public string OTName { get; set; } = string.Empty;
        public DateTime SurgeryDate { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }

        public string PrimarySurgeonName { get; set; } = string.Empty;

        [XmlIgnore]
        public string DoctorName
        {
            get => PrimarySurgeonName;
            set => PrimarySurgeonName = value;
        }

        public string PatientName { get; set; } = string.Empty;
        public string ProcedureName { get; set; } = string.Empty;
        public bool IsCompleted { get; set; }

        [XmlIgnore]
        public string TimeRange => $"{StartDateTime:HH:mm} - {EndDateTime:HH:mm}";

        [XmlIgnore]
        public string Status
        {
            get
            {
                if (IsCompleted)
                    return "Completed";

                var now = DateTime.Now;

                if (now < StartDateTime)
                    return "Scheduled";

                if (now >= StartDateTime && now <= EndDateTime)
                    return "In Progress";

                return "Time Completed";
            }
        }
    }
}

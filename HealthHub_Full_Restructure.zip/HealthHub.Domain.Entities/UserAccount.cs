namespace HealthHub.Domain.Entities
{
    // NEW entity. The old app kept registered users in an in-memory
    // Dictionary (Infrastructure/UserStore.cs) that was wiped every time the
    // app restarted (only the hardcoded "user123" demo account ever came
    // back). Since we're moving every entity to its own XML file, this gives
    // users an actual persisted account instead of losing accounts on
    // restart. See README for details - this is a deliberate behavior
    // change, flagged there.
    public class UserAccount
    {
        public string UserId { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}

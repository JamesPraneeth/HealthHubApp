using System;

namespace HealthHub.Domain.Entities
{
    public class ICUPatientInfo
    {
        public string PatientName { get; set; } = string.Empty;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}

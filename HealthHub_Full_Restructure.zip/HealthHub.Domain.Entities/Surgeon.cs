using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HealthHub.Domain.Entities
{
    public class Surgeon : INotifyPropertyChanged
    {
        private string _surgeonId = string.Empty;
        private string _name = string.Empty;
        private string _department = string.Empty;
        private string _email = string.Empty;
        private string _contactNo = string.Empty;
        private string _specialization = string.Empty;
        private string _experience = string.Empty;
        private string _availability = string.Empty;
        private bool _isSelected;

        public string SurgeonId
        {
            get => _surgeonId;
            set { _surgeonId = value; OnPropertyChanged(); }
        }

        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public string Department { get => _department; set { _department = value; OnPropertyChanged(); } }
        public string Email { get => _email; set { _email = value; OnPropertyChanged(); } }

        public string ContactNo
        {
            get => _contactNo;
            set
            {
                _contactNo = value;
                OnPropertyChanged();
            }
        }

        public string Specialization { get => _specialization; set { _specialization = value; OnPropertyChanged(); } }
        public string Experience { get => _experience; set { _experience = value; OnPropertyChanged(); } }
        public string Availability { get => _availability; set { _availability = value; OnPropertyChanged(); } }
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public Surgeon Clone() => new Surgeon
        {
            SurgeonId = this.SurgeonId,
            Name = this.Name,
            Department = this.Department,
            Email = this.Email,
            ContactNo = this.ContactNo,
            Specialization = this.Specialization,
            Experience = this.Experience,
            Availability = this.Availability,
            IsSelected = this.IsSelected
        };

        public void CopyFrom(Surgeon other)
        {
            SurgeonId = other.SurgeonId;
            Name = other.Name;
            Department = other.Department;
            Email = other.Email;
            ContactNo = other.ContactNo;
            Specialization = other.Specialization;
            Experience = other.Experience;
            Availability = other.Availability;
            IsSelected = other.IsSelected;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? propName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
    }
}

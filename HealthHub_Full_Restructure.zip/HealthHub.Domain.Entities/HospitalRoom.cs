using System.Collections.Generic;
using System.Xml.Serialization;

namespace HealthHub.Domain.Entities
{
    public class HospitalRoom
    {
        public string RoomName { get; set; } = string.Empty;
        public string RoomType { get; set; } = string.Empty;

        public int MaxCapacity { get; set; } = 0;

        [XmlArray("ICUPatients")]
        [XmlArrayItem("ICUPatientInfo")]
        public List<ICUPatientInfo> ICUPatients { get; set; } = new();

        [XmlArray("OPDPatients")]
        [XmlArrayItem("OPDPatientInfo")]
        public List<OPDPatientInfo> OPDPatients { get; set; } = new();

        [XmlArray("OTSurgeries")]
        [XmlArrayItem("OTScheduledSurgery")]
        public List<OTScheduledSurgery> OTSurgeries { get; set; } = new();

        [XmlIgnore]
        public string DisplayName => $"{RoomType} - {RoomName}";

        [XmlIgnore]
        public int AvailableOPDSlots => MaxCapacity - OPDPatients.Count;

        [XmlIgnore]
        public int AvailableICUBeds => MaxCapacity - ICUPatients.Count;
    }
}

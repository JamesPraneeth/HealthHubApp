using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HealthHub.Domain.Entities
{
    public class Patient : INotifyPropertyChanged
    {
        private string _patientId = string.Empty;
        private string _name = string.Empty;
        private DateTime _dob;
        private string _gender = "I Prefer Not To Say";
        private string _email = string.Empty;
        private string _phoneNo = string.Empty;
        private string _address = string.Empty;
        private bool _isSelected;

        public string PatientId
        {
            get => _patientId;
            set
            {
                _patientId = value;
                OnPropertyChanged();
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }

        public DateTime DOB
        {
            get => _dob;
            set
            {
                _dob = value;
                OnPropertyChanged();
            }
        }

        public string Gender
        {
            get => _gender;
            set
            {
                _gender = value;
                OnPropertyChanged();
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged();
            }
        }

        public string PhoneNo
        {
            get => _phoneNo;
            set
            {
                _phoneNo = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(MaskedPhoneNo));
            }
        }

        public string MaskedPhoneNo
        {
            get
            {
                if (string.IsNullOrWhiteSpace(PhoneNo))
                    return string.Empty;

                var phone = PhoneNo.Trim();

                if (phone.Length <= 4)
                    return phone;

                return new string('X', phone.Length - 4) + phone[^4..];
            }
        }

        public string Address
        {
            get => _address;
            set
            {
                _address = value;
                OnPropertyChanged();
            }
        }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public Patient Clone() => new Patient
        {
            PatientId = this.PatientId,
            Name = this.Name,
            DOB = this.DOB,
            Gender = this.Gender,
            Email = this.Email,
            PhoneNo = this.PhoneNo,
            Address = this.Address,
            IsSelected = this.IsSelected
        };

        public void CopyFrom(Patient other)
        {
            PatientId = other.PatientId;
            Name = other.Name;
            DOB = other.DOB;
            Gender = other.Gender;
            Email = other.Email;
            PhoneNo = other.PhoneNo;
            Address = other.Address;
            IsSelected = other.IsSelected;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? propName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
    }
}

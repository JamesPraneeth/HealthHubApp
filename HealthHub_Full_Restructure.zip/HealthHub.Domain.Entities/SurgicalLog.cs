using System;
using System.Xml.Serialization;

namespace HealthHub.Domain.Entities
{
    // Renamed from the old "OTScheduleLog" to match the HealthHub.Domain.Entities
    // naming already used in the new solution (SurgicalLog.cs stub).
    public class SurgicalLog
    {
        public string OTName { get; set; } = string.Empty;
        public DateTime SurgeryDate { get; set; }
        public string Duration { get; set; } = string.Empty;

        public string PrimarySurgeonName { get; set; } = string.Empty;

        [XmlIgnore]
        public string DoctorName
        {
            get => PrimarySurgeonName;
            set => PrimarySurgeonName = value;
        }

        public string PatientName { get; set; } = string.Empty;
        public string ProcedureName { get; set; } = string.Empty;
        public string DocumentName { get; set; } = string.Empty;
    }
}

using System;

namespace HealthHub.Domain.Entities
{
    public class OPDPatientInfo
    {
        public string PatientName { get; set; } = string.Empty;
        public string PhysicianName { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string Time { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
    }
}

using System;
using System.Globalization;
using System.Windows.Data;

namespace HealthHub.App.Views.Converters
{
    // Moved from Infrastructure/StatusToTimeConverter.cs. Lives here
    // (HealthHub.App.Views) rather than the "Converters/" folder under
    // HealthHub, because HomeView.xaml instantiates this converter
    // directly as a local resource - putting it in HealthHub would mean
    // HealthHub.App.Views needs a reference to HealthHub, which conflicts
    // with HealthHub already referencing HealthHub.App.Views (circular).
    // See README for the full project-reference reasoning.
    public class StatusToTimeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // If the status is Available, show --:--
            if (value != null && value.ToString() == "Available")
                return "--:--";

            // Otherwise, return the original TimeRemaining value passed from the binding
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
    }
}

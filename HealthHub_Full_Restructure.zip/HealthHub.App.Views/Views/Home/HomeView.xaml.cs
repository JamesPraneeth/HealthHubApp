using System;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using HealthHub.App.Services.LiveActivity;

namespace HealthHub.App.Views.Home
{
    public partial class HomeView : UserControl
    {
        private readonly ObservableCollection<string> _recentActivities =
            new ObservableCollection<string>();

        // DataContext used to be set here directly (new HomeViewModel(App.SurgeonStore)).
        // Now wired externally by MainWindow.xaml.cs, since HomeViewModel
        // lives in HealthHub and this project can't reference it back.
        // See README.
        public HomeView()
        {
            InitializeComponent();

            RecentStatusList.ItemsSource = _recentActivities;

            StatusService.StatusChanged += OnStatusChanged;

            Unloaded += HomeView_Unloaded;
        }

        private void OnStatusChanged(string message)
        {
            Dispatcher.Invoke(() =>
            {
                LiveStatusText.Text = message;
                LiveStatusTimeText.Text = DateTime.Now.ToString("dd MMM yyyy, hh:mm tt");

                string activity = $"{DateTime.Now:hh:mm tt} - {message}";
                _recentActivities.Insert(0, activity);

                if (_recentActivities.Count > 5)
                {
                    _recentActivities.RemoveAt(_recentActivities.Count - 1);
                }
            });
        }

        private void HomeView_Unloaded(object sender, System.Windows.RoutedEventArgs e)
        {
            // MainWindow creates HomeView once and reuses it.
            // So do not unsubscribe here.
        }
    }
}

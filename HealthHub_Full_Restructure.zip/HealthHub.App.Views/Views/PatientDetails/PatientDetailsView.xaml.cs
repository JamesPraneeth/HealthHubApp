using System.Windows.Controls;

namespace HealthHub.App.Views.PatientDetails
{
    public partial class PatientDetailsView : UserControl
    {
        // DataContext used to be set here directly. Now wired externally
        // by MainWindow.xaml.cs's CreatePatientPage(). See README.
        public PatientDetailsView()
        {
            InitializeComponent();
        }

        private void PatientGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

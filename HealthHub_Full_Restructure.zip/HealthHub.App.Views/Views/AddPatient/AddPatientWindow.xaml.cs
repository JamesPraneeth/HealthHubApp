using System.Windows;
using System.Windows.Input;

namespace HealthHub.App.Views.AddPatient
{
    public partial class AddPatientWindow : Window
    {
        // DataContext used to be built right here (referencing
        // AddPatientViewModel + App.PatientStore directly). That's no
        // longer possible from this project without a circular reference
        // to HealthHub - so DataContext is now assigned by whoever
        // constructs this window (SearchBarViewModel.OpenAddPatient()).
        // See README.
        public AddPatientWindow()
        {
            InitializeComponent();
        }

        private void AddPatientScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta < 0)
            {
                AddPatientScrollViewer.LineDown();
            }
            else
            {
                AddPatientScrollViewer.LineUp();
            }

            e.Handled = true;
        }
    }
}


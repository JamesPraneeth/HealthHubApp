using System.Windows.Controls;

namespace HealthHub.App.Views.SurgeonDetails
{
    public partial class SurgeonDetailsView : UserControl
    {
        // DataContext used to be set here directly. Now wired externally
        // by MainWindow.xaml.cs's CreateSurgeonPage(). See README.
        public SurgeonDetailsView()
        {
            InitializeComponent();
        }
    }
}

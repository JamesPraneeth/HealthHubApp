using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HealthHub.App.Views.OT
{
    /// <summary>
    /// Interaction logic for OTView.xaml
    /// </summary>
    public partial class OTView : UserControl
    {
        // DataContext used to be set here directly (new OTViewModel()).
        // Now wired externally by MainWindow.xaml.cs, since OTViewModel
        // lives in HealthHub and this project can't reference it back.
        // See README.
        public OTView()
        {
            InitializeComponent();
        }
    }
}

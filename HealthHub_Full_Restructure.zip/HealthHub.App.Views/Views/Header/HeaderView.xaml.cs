using System.Windows.Controls;
using System.Windows;

namespace HealthHub.App.Views.Header
{
    public partial class HeaderView : UserControl
    {
        public HeaderView()
        {
            InitializeComponent();
        }
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Logout",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                // Was MainWindow.Instance.LoadLoginScreen() - can't
                // reference MainWindow (lives in HealthHub) from here
                // without a circular project reference. See AppShell.cs
                // and the README.
                AppShell.ShowLogin?.Invoke();
            }
        }
    }
}

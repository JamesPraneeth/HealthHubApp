using System.Windows.Controls;

namespace HealthHub.App.Views.SurgeonSearchBar
{
    public partial class SurgeonSearchBarView : UserControl
    {
        // DataContext used to be set here directly. Now wired externally
        // by MainWindow.xaml.cs's CreateSurgeonPage(). See README.
        public SurgeonSearchBarView()
        {
            InitializeComponent();
        }
    }
}

using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using HealthHub.App.Views.Localization;

namespace HealthHub.App.Views.Login
{
    public partial class LoginView : UserControl
    {
        private bool isPasswordVisible = false;

        private bool _userIdTouched = false;
        private bool _passwordTouched = false;

        // Runtime-resolved localization targets
        private TextBlock? _txtTitle;
        private TextBlock? _lblUserId;
        private TextBlock? _lblPassword;
        private TextBlock? _lblSelectLanguage;
        private ComboBox? _cmbLanguage;
        private Run? _runDontHaveAccount;
        private Run? _runRegisterHere;

        public LoginView()
        {
            InitializeComponent();
            Loaded += LoginView_Loaded;
        }

        private void LoginView_Loaded(object sender, RoutedEventArgs e)
        {
            Loaded -= LoginView_Loaded;
            ResolveLocalizedControls();
            this.Language = XmlLanguage.GetLanguage(CultureInfo.CurrentUICulture.IetfLanguageTag);
            SetSelectedLanguage();
            SetLocalizedText();
            UpdateLoginButtonState();
        }

        private void ResolveLocalizedControls()
        {
            _txtTitle         = FindName("txtTitle") as TextBlock;
            _lblUserId        = FindName("lblUserId") as TextBlock;
            _lblPassword      = FindName("lblPassword") as TextBlock;
            _lblSelectLanguage= FindName("lblSelectLanguage") as TextBlock;
            _cmbLanguage      = FindName("cmbLanguage") as ComboBox;
            _runDontHaveAccount = FindName("runDontHaveAccount") as Run;
            _runRegisterHere  = FindName("runRegisterHere") as Run;
        }

        private string GetText(string key) => LocalizationService.GetText(key);

        private void SetLocalizedText()
        {
            if (_txtTitle != null)        _txtTitle.Text        = "Welcome to HealthHub";
            if (_lblUserId != null)       _lblUserId.Text       = GetText("UserId");
            if (_lblPassword != null)     _lblPassword.Text     = GetText("Password");
            btnLogin.Content              = GetText("Login");
            if (_runDontHaveAccount != null) _runDontHaveAccount.Text = GetText("DontHaveAccount") + " ";
            if (_runRegisterHere != null) _runRegisterHere.Text = GetText("RegisterHere");
            if (_lblSelectLanguage != null) _lblSelectLanguage.Text = GetText("SelectLanguage");
            RefreshUserIdValidation();
            RefreshPasswordValidation();
        }

        private void SetSelectedLanguage()
        {
            if (_cmbLanguage == null) return;
            foreach (ComboBoxItem item in _cmbLanguage.Items)
            {
                if ((item.Tag?.ToString() ?? "") == CultureInfo.CurrentUICulture.Name)
                {
                    _cmbLanguage.SelectedItem = item;
                    return;
                }
            }
            _cmbLanguage.SelectedIndex = 0;
        }

        private string GetPassword() =>
            isPasswordVisible ? txtVisiblePassword.Text : txtPassword.Password;

        private void UpdateLoginButtonState()
        {
            btnLogin.IsEnabled =
                !string.IsNullOrWhiteSpace(txtUserId.Text) &&
                !string.IsNullOrWhiteSpace(GetPassword());
        }

        private string ValidateUserIdField()
        {
            string userId = txtUserId.Text.Trim();
            if (string.IsNullOrWhiteSpace(userId)) return GetText("UserIdRequired");
            return string.Empty;
        }

        private string ValidatePasswordField()
        {
            string password = GetPassword();
            if (string.IsNullOrWhiteSpace(password)) return GetText("PasswordRequired");
            return string.Empty;
        }

        private void RefreshUserIdValidation()
        {
            txtUserIdError.Text = _userIdTouched ? ValidateUserIdField() : string.Empty;
        }

        private void RefreshPasswordValidation()
        {
            txtPasswordError.Text = _passwordTouched ? ValidatePasswordField() : string.Empty;
        }

        private void txtUserId_GotFocus(object sender, RoutedEventArgs e)
        {
            _userIdTouched = true;
            RefreshUserIdValidation();
        }

        private void txtUserId_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshUserIdValidation();
            UpdateLoginButtonState();
            txtError.Text = string.Empty;
        }

        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
            _passwordTouched = true;
            RefreshPasswordValidation();
        }

        private void txtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (!isPasswordVisible) txtVisiblePassword.Text = txtPassword.Password;
            RefreshPasswordValidation();
            UpdateLoginButtonState();
            txtError.Text = string.Empty;
        }

        private void txtVisiblePassword_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (isPasswordVisible) txtPassword.Password = txtVisiblePassword.Text;
            RefreshPasswordValidation();
            UpdateLoginButtonState();
            txtError.Text = string.Empty;
        }

        private void TogglePassword(object sender, RoutedEventArgs e)
        {
            if (!isPasswordVisible)
            {
                txtVisiblePassword.Text       = txtPassword.Password;
                txtVisiblePassword.Visibility = Visibility.Visible;
                txtPassword.Visibility        = Visibility.Collapsed;
                isPasswordVisible             = true;
            }
            else
            {
                txtPassword.Password        = txtVisiblePassword.Text;
                txtPassword.Visibility      = Visibility.Visible;
                txtVisiblePassword.Visibility = Visibility.Collapsed;
                isPasswordVisible           = false;
            }
            RefreshPasswordValidation();
            UpdateLoginButtonState();
        }

        private void Language_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_cmbLanguage?.SelectedItem is not ComboBoxItem item || item.Tag == null)
                return;

            string cultureName = item.Tag.ToString()!;
            LocalizationService.SetCulture(cultureName);
            this.Language = XmlLanguage.GetLanguage(CultureInfo.CurrentUICulture.IetfLanguageTag);
            SetLocalizedText();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            _userIdTouched  = true;
            _passwordTouched = true;
            RefreshUserIdValidation();
            RefreshPasswordValidation();

            if (!string.IsNullOrEmpty(txtUserIdError.Text) ||
                !string.IsNullOrEmpty(txtPasswordError.Text))
                return;

            string userId   = txtUserId.Text.Trim();
            string password = GetPassword();

            // Was UserStore.ValidateUser() — now routes through AppShell
            // to keep this project free of a reference to HealthHub.
            // MainWindow wires AppShell.ValidateUser at startup. See README.
            if (AppShell.ValidateUser != null && AppShell.ValidateUser(userId, password))
            {
                txtError.Text = string.Empty;
                AppShell.ShowApplication?.Invoke();
            }
            else
            {
                txtError.Text = GetText("InvalidCredentials");
            }
        }

        private void RegisterLink_Click(object sender, RoutedEventArgs e)
        {
            AppShell.Navigate?.Invoke(new RegisterView());
        }
    }
}

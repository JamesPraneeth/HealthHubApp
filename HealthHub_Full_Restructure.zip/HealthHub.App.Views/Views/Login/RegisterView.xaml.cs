using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace HealthHub.App.Views.Login
{
    public partial class RegisterView : UserControl
    {
        private bool isPasswordVisible = false;
        private bool isConfirmPasswordVisible = false;

        private bool _userIdTouched = false;
        private bool _passwordTouched = false;
        private bool _confirmPasswordTouched = false;

        public RegisterView()
        {
            InitializeComponent();
        }

        private string GetPassword() =>
            isPasswordVisible ? txtVisiblePassword.Text : txtPassword.Password;

        private string GetConfirmPassword() =>
            isConfirmPasswordVisible ? txtVisibleConfirmPassword.Text : txtConfirmPassword.Password;

        private bool ValidateUserId(string userId, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(userId))           { error = "User ID is required."; return false; }
            if (userId.Contains(" "))                         { error = "User ID should not contain spaces."; return false; }
            if (userId.Length < 4)                            { error = "User ID should have minimum 4 characters."; return false; }
            if (Regex.IsMatch(userId, @"[!@#%^&*()]"))        { error = "User ID should not contain special symbols."; return false; }
            if (!Regex.IsMatch(userId, @"\d"))                { error = "User ID must contain at least one number."; return false; }
            return true;
        }

        private bool ValidatePassword(string password, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(password))          { error = "Password is required."; return false; }
            if (password.Contains(" "))                        { error = "Password should not contain spaces."; return false; }
            if (password.Length < 8 || password.Length > 16)  { error = "Password must be 8 to 16 characters."; return false; }
            if (!Regex.IsMatch(password, @"[!@#%^&*]"))       { error = "Password must contain at least one special symbol."; return false; }
            if (!Regex.IsMatch(password, @"\d"))               { error = "Password must contain at least one number."; return false; }
            if (!Regex.IsMatch(password, @"[A-Z]"))            { error = "Password must contain at least one uppercase letter."; return false; }
            return true;
        }

        private string ValidateConfirmPassword()
        {
            if (string.IsNullOrWhiteSpace(GetConfirmPassword())) return "Confirm Password is required.";
            if (GetPassword() != GetConfirmPassword())            return "Password and Confirm Password do not match.";
            return string.Empty;
        }

        private void RefreshUserIdValidation()
        {
            if (!_userIdTouched) { txtUserIdError.Text = string.Empty; return; }
            ValidateUserId(txtUserId.Text.Trim(), out string error);
            txtUserIdError.Text = error;
        }

        private void RefreshPasswordValidation()
        {
            if (!_passwordTouched) { txtPasswordError.Text = string.Empty; return; }
            ValidatePassword(GetPassword(), out string error);
            txtPasswordError.Text = error;
        }

        private void RefreshConfirmPasswordValidation()
        {
            txtConfirmPasswordError.Text = _confirmPasswordTouched ? ValidateConfirmPassword() : string.Empty;
        }

        private void txtUserId_GotFocus(object sender, RoutedEventArgs e) { _userIdTouched = true; RefreshUserIdValidation(); }
        private void txtUserId_TextChanged(object sender, TextChangedEventArgs e) => RefreshUserIdValidation();

        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
            _passwordTouched = true; RefreshPasswordValidation();
            if (_confirmPasswordTouched) RefreshConfirmPasswordValidation();
        }

        private void txtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            RefreshPasswordValidation();
            if (_confirmPasswordTouched) RefreshConfirmPasswordValidation();
        }

        private void txtVisiblePassword_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshPasswordValidation();
            if (_confirmPasswordTouched) RefreshConfirmPasswordValidation();
        }

        private void txtConfirmPassword_GotFocus(object sender, RoutedEventArgs e) { _confirmPasswordTouched = true; RefreshConfirmPasswordValidation(); }
        private void txtConfirmPassword_PasswordChanged(object sender, RoutedEventArgs e) => RefreshConfirmPasswordValidation();
        private void txtVisibleConfirmPassword_TextChanged(object sender, TextChangedEventArgs e) => RefreshConfirmPasswordValidation();

        private void TogglePassword(object sender, RoutedEventArgs e)
        {
            if (!isPasswordVisible)
            {
                txtVisiblePassword.Text       = txtPassword.Password;
                txtVisiblePassword.Visibility = Visibility.Visible;
                txtPassword.Visibility        = Visibility.Collapsed;
                isPasswordVisible             = true;
            }
            else
            {
                txtPassword.Password          = txtVisiblePassword.Text;
                txtPassword.Visibility        = Visibility.Visible;
                txtVisiblePassword.Visibility = Visibility.Collapsed;
                isPasswordVisible             = false;
            }
            RefreshPasswordValidation();
            if (_confirmPasswordTouched) RefreshConfirmPasswordValidation();
        }

        private void ToggleConfirmPassword(object sender, RoutedEventArgs e)
        {
            if (!isConfirmPasswordVisible)
            {
                txtVisibleConfirmPassword.Text       = txtConfirmPassword.Password;
                txtVisibleConfirmPassword.Visibility = Visibility.Visible;
                txtConfirmPassword.Visibility        = Visibility.Collapsed;
                isConfirmPasswordVisible             = true;
            }
            else
            {
                txtConfirmPassword.Password          = txtVisibleConfirmPassword.Text;
                txtConfirmPassword.Visibility        = Visibility.Visible;
                txtVisibleConfirmPassword.Visibility = Visibility.Collapsed;
                isConfirmPasswordVisible             = false;
            }
            RefreshConfirmPasswordValidation();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            _userIdTouched = _passwordTouched = _confirmPasswordTouched = true;
            RefreshUserIdValidation();
            RefreshPasswordValidation();
            RefreshConfirmPasswordValidation();

            if (!string.IsNullOrEmpty(txtUserIdError.Text) ||
                !string.IsNullOrEmpty(txtPasswordError.Text) ||
                !string.IsNullOrEmpty(txtConfirmPasswordError.Text))
                return;

            string userId   = txtUserId.Text.Trim();
            string password = GetPassword();

            // Was UserStore.RegisterUser() — now routes through AppShell.
            // MainWindow wires AppShell.RegisterUser at startup. See README.
            bool result = AppShell.RegisterUser != null && AppShell.RegisterUser(userId, password);

            if (result)
                AppShell.Navigate?.Invoke(new LoginView());
            else
                txtUserIdError.Text = "User ID already exists.";
        }

        private void LoginLink_Click(object sender, RoutedEventArgs e) =>
            AppShell.Navigate?.Invoke(new LoginView());
    }
}

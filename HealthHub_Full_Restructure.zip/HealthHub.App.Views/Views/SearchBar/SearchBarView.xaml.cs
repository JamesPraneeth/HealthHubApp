using System.Windows.Controls;

namespace HealthHub.App.Views.SearchBar
{
    public partial class SearchBarView : UserControl
    {
        // DataContext used to be set here directly. Now wired externally
        // by MainWindow.xaml.cs's CreatePatientPage(). See README.
        public SearchBarView()
        {
            InitializeComponent();
        }
    }
}

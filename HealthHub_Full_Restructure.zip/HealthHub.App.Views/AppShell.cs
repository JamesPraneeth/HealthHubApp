using System;
using System.Windows.Controls;

namespace HealthHub.App.Views
{
    // NEW. The old code had several Views (HeaderView, LoginView,
    // RegisterView) calling "MainWindow.Instance.SomeMethod()" directly
    // for top-level navigation (show the login screen, show the app shell,
    // swap the current UserControl). MainWindow lives in the HealthHub
    // (exe) project; HealthHub already references HealthHub.App.Views for
    // its Views, so a View reaching back into HealthHub to call
    // MainWindow directly would require a circular project reference.
    //
    // AppShell is a small static indirection: HealthHub's MainWindow wires
    // these delegates up once at startup, and Views call through AppShell
    // instead of referencing MainWindow directly. Runtime behavior is
    // identical - only the compile-time direction of the dependency changed.
    public static class AppShell
    {
        // Navigation delegates
        public static Action? ShowLogin { get; set; }
        public static Action? ShowApplication { get; set; }
        public static Action<UserControl>? Navigate { get; set; }

        // Auth delegates (replaces static UserStore calls in Login/Register views)
        public static Func<string, string, bool>? ValidateUser { get; set; }
        public static Func<string, string, bool>? RegisterUser { get; set; }
    }
}

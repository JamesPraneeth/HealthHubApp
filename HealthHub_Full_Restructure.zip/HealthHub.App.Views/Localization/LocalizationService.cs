using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Threading;

namespace HealthHub.App.Views.Localization
{
    // Moved from Infrastructure/LocalizationService.cs. Lives here
    // (HealthHub.App.Views) rather than the "Localization/" folder under
    // HealthHub, because LoginView.xaml.cs calls this directly from
    // code-behind - same circular-dependency reasoning as
    // StatusToTimeConverter (see that file's comment, and the README).
    //
    // NOTE: the resource lookup string below ("HealthHub.App.Views.Properties.Resources")
    // assumes the old Properties/Resources.resx + its generated
    // Resources.Designer.cs move into this project too, since that's what
    // actually holds the translated strings. Update the resource base name
    // here if you place Resources.resx somewhere else.
    public static class LocalizationService
    {
        private static readonly ResourceManager _resourceManager =
            new ResourceManager("HealthHub.App.Views.Properties.Resources", Assembly.GetExecutingAssembly());

        public static string GetText(string key)
        {
            return _resourceManager.GetString(key, CultureInfo.CurrentUICulture) ?? key;
        }

        public static void SetCulture(string cultureName)
        {
            var culture = new CultureInfo(cultureName);

            Thread.CurrentThread.CurrentCulture = culture;
            Thread.CurrentThread.CurrentUICulture = culture;

            CultureInfo.DefaultThreadCurrentCulture = culture;
            CultureInfo.DefaultThreadCurrentUICulture = culture;
        }
    }
}

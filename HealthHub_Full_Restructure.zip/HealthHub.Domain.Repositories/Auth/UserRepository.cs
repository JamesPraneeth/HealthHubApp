using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.Domain.Repositories.Auth
{
    // NEW. Persists to Data/Users.xml. Replaces the old
    // Infrastructure/UserStore.cs, which kept registered users in a
    // plain in-memory Dictionary that reset on every app restart.
    //
    // Note: like the old UserStore, passwords are stored in plain text.
    // That was already true before (in-memory), so this isn't a new
    // weakness, but now that it's written to disk it's worth hashing
    // passwords before persisting if this ever handles real data.
    public class UserRepository : XmlRepository<UserAccount>
    {
        public UserRepository() : base("Users.xml", "Users")
        {
        }
    }
}

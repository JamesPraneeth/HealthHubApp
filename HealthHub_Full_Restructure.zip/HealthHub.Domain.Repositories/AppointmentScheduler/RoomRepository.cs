using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.Domain.Repositories.AppointmentScheduler
{
    // Persists to Data/Rooms.xml. Each HospitalRoom carries its own nested
    // ICU/OPD/OT sub-lists (same shape as before), so one file covers
    // OT + ICU + OPD scheduling data.
    //
    // Replaces the old Infrastructure/XmlRoomStorage.cs wrapper and the
    // HospitalRoomConfiguration wrapper class, both of which only existed
    // to route through the single shared HospitalDatabase.xml.
    public class RoomRepository : XmlRepository<HospitalRoom>
    {
        public RoomRepository() : base("Rooms.xml", "Rooms")
        {
        }
    }
}

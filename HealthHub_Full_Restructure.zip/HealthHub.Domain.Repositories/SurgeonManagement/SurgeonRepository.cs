using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.Domain.Repositories.SurgeonManagement
{
    // Persists to Data/Surgeons.xml (was part of the shared HospitalDatabase.xml).
    //
    // NOTE: your tree also shows a "SurgeonRepository.cs" sitting directly in
    // HealthHub.Domain.Entities. That looks like a leftover/duplicate from
    // mid-refactor - this is the one that should actually be used (a
    // repository doesn't belong in the Entities project). Worth deleting
    // the one in Domain.Entities once you confirm it's not referenced
    // anywhere.
    public class SurgeonRepository : XmlRepository<Surgeon>
    {
        public SurgeonRepository() : base("Surgeons.xml", "Surgeons")
        {
        }
    }
}

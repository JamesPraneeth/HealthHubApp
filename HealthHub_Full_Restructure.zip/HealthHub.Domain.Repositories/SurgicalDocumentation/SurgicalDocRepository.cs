using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.Domain.Repositories.SurgicalDocumentation
{
    // Persists to Data/SurgicalLogs.xml.
    //
    // NOTE: in the old app, completed-surgery log entries (OTScheduleLog)
    // were only ever kept in an in-memory list inside OTViewModel - they
    // were never written to HospitalDatabase.xml, so the "Surgery Logs"
    // list was silently wiped every time the app restarted. Giving this
    // its own repository/XML file fixes that gap as part of moving every
    // entity to its own store. Flagged in the README as a behavior change.
    public class SurgicalDocRepository : XmlRepository<SurgicalLog>
    {
        public SurgicalDocRepository() : base("SurgicalLogs.xml", "SurgicalLogs")
        {
        }
    }
}

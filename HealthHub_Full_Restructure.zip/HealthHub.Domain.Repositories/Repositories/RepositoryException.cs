using System;

namespace HealthHub.Domain.Repositories.Repositories
{
    // The old XmlDatabaseManager.Load()/Save() called MessageBox.Show(...)
    // directly from inside the data-access code. That meant the data layer
    // had a hard dependency on WPF (PresentationFramework), which is a
    // separation-of-concerns problem for a plain class library.
    //
    // XmlRepository<T> now throws this instead, and the Services layer
    // (which already lives in a project that talks to the UI) is
    // responsible for catching it and showing the same message box the
    // old code did. End-user behavior is unchanged - only *where* the
    // MessageBox call happens has moved.
    public class RepositoryException : Exception
    {
        public RepositoryException(string message) : base(message) { }

        public RepositoryException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}

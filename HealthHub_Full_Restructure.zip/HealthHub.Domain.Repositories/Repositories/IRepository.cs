using System.Collections.Generic;

namespace HealthHub.Domain.Repositories.Repositories
{
    // Generic contract every entity repository implements. Deliberately
    // small: "give me everything" / "persist everything" is all the
    // Services layer needs - the Services layer (and the ObservableCollections
    // it exposes to the ViewModels) is what decides when a save happens.
    public interface IRepository<T>
    {
        List<T> GetAll();

        void SaveAll(List<T> items);
    }
}

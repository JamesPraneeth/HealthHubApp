using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace HealthHub.Domain.Repositories.Repositories
{
    // Generic base class for "one XML file per entity". Replaces the old
    // single-file XmlDatabaseManager (which serialized one big
    // HospitalDatabase object containing every entity together).
    //
    // Each concrete repository just supplies a file name and the XML root
    // element name; List<T> is serialized/deserialized directly (no wrapper
    // class needed), and each item element defaults to the type name
    // (e.g. <Patients><Patient>...</Patient></Patients>), matching the
    // element names the old HospitalDatabase.xml already used.
    public abstract class XmlRepository<T> : IRepository<T> where T : class
    {
        private readonly string _filePath;
        private readonly XmlSerializer _serializer;

        protected XmlRepository(string fileName, string rootElementName)
        {
            _filePath = Path.Combine(GetDataDirectory(), fileName);
            _serializer = new XmlSerializer(typeof(List<T>), new XmlRootAttribute(rootElementName));
        }

        // All entity XML files live side-by-side in a "Data" folder next to
        // the HealthHub project, instead of one HospitalDatabase.xml sitting
        // in the project root. Mirrors where the old file was written
        // (three levels up from bin\Debug\<tfm>\).
        private static string GetDataDirectory()
        {
            string dir = Path.GetFullPath(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\Data"));

            Directory.CreateDirectory(dir);
            return dir;
        }

        public List<T> GetAll()
        {
            if (!File.Exists(_filePath))
                return new List<T>();

            try
            {
                using FileStream stream = new FileStream(_filePath, FileMode.Open, FileAccess.Read);
                return (List<T>?)_serializer.Deserialize(stream) ?? new List<T>();
            }
            catch (Exception ex)
            {
                throw new RepositoryException(
                    $"CRITICAL ERROR: Failed to read {Path.GetFileName(_filePath)}.\n\n" +
                    "The file has been corrupted or has invalid XML syntax. The app will start " +
                    "with empty data to prevent crashing, but PLEASE CHECK YOUR XML FILE.\n\n" +
                    $"Error details: {ex.Message}",
                    ex);
            }
        }

        public void SaveAll(List<T> items)
        {
            try
            {
                using FileStream stream = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                _serializer.Serialize(stream, items);
            }
            catch (Exception ex)
            {
                throw new RepositoryException(
                    $"Failed to save {Path.GetFileName(_filePath)}: {ex.Message}", ex);
            }
        }
    }
}

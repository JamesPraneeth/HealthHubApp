using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.Domain.Repositories.PatientManagement
{
    // Persists to Data/Patients.xml (was part of the shared HospitalDatabase.xml).
    public class PatientRepository : XmlRepository<Patient>
    {
        public PatientRepository() : base("Patients.xml", "Patients")
        {
        }
    }
}

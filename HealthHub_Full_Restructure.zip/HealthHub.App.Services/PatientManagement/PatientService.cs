using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.PatientManagement;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.App.Services.PatientManagement
{
    // Renamed from the old Infrastructure/PatientStore.cs. Same public
    // shape (ObservableCollection<Patient> Patients, search/filter state,
    // ClearFilters()) so every ViewModel that consumed PatientStore only
    // needs its using/type name updated - not its calling code.
    //
    // Internally, this now reads/writes through PatientRepository (one
    // Patients.xml file) instead of the old shared XmlDatabaseManager
    // blob.
    public class PatientService : INotifyPropertyChanged
    {
        private readonly PatientRepository _repository;

        public ObservableCollection<Patient> Patients { get; } = new ObservableCollection<Patient>();

        // Raised when a load/save to disk fails. The WPF layer (composition
        // root in App.xaml.cs) subscribes to this and shows the same
        // MessageBox the old XmlDatabaseManager used to show directly -
        // this project has no WPF/PresentationFramework reference, so it
        // can't show one itself.
        public event Action<string>? PersistenceError;

        private string _searchText = string.Empty;
        private string _selectedSearchBy = "Name";
        private string _selectedFilterBy = "None";
        private string _selectedFilterValue = "All";

        public PatientService(PatientRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            List<Patient> initial;
            try
            {
                initial = _repository.GetAll();
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
                initial = new List<Patient>();
            }

            foreach (var p in initial)
            {
                p.PropertyChanged += Item_PropertyChanged;
                Patients.Add(p);
            }

            Patients.CollectionChanged += Patients_CollectionChanged;
        }

        private void Patients_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null)
                foreach (Patient p in e.OldItems) p.PropertyChanged -= Item_PropertyChanged;

            if (e.NewItems != null)
                foreach (Patient p in e.NewItems) p.PropertyChanged += Item_PropertyChanged;

            SyncAndSave();
        }

        private void Item_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(Patient.IsSelected)) SyncAndSave();
        }

        private void SyncAndSave()
        {
            try
            {
                _repository.SaveAll(new List<Patient>(Patients));
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }
        }

        public string SearchText
        {
            get => _searchText;
            set => SetProperty(ref _searchText, value);
        }

        public string SelectedSearchBy
        {
            get => _selectedSearchBy;
            set => SetProperty(ref _selectedSearchBy, value);
        }

        public string SelectedFilterBy
        {
            get => _selectedFilterBy;
            set => SetProperty(ref _selectedFilterBy, value);
        }

        public string SelectedFilterValue
        {
            get => _selectedFilterValue;
            set => SetProperty(ref _selectedFilterValue, value);
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = "")
        {
            if (!Equals(field, value))
            {
                field = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public void ClearFilters()
        {
            SearchText = string.Empty;
            SelectedSearchBy = "Name";
            SelectedFilterBy = "None";
            SelectedFilterValue = "All";
        }
    }
}

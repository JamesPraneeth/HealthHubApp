using System;
using System.Collections.Generic;
using System.Linq;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Auth;
using HealthHub.Domain.Repositories.Repositories;

namespace HealthHub.App.Services.Auth
{
    // Replaces the old static Infrastructure/UserStore.cs. Same two
    // operations (RegisterUser / ValidateUser) so LoginView.xaml.cs and
    // RegisterView.xaml.cs barely change - just call this via an instance
    // (App.AuthService) instead of the static UserStore class.
    //
    // Behavior change: the old UserStore was an in-memory-only Dictionary,
    // so every registered account (other than the hardcoded demo user)
    // was lost on restart. This now persists to Data/Users.xml like every
    // other entity. Flagged in the README.
    public class AuthService
    {
        private readonly UserRepository _repository;
        private readonly List<UserAccount> _users;

        public event Action<string>? PersistenceError;

        public AuthService(UserRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            try
            {
                _users = _repository.GetAll();
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
                _users = new List<UserAccount>();
            }
        }

        public bool RegisterUser(string userId, string password)
        {
            if (_users.Any(u => u.UserId == userId))
                return false;

            _users.Add(new UserAccount { UserId = userId, Password = password });
            Save();
            return true;
        }

        public bool ValidateUser(string userId, string password)
        {
            return _users.Any(u => u.UserId == userId && u.Password == password);
        }

        public IReadOnlyList<UserAccount> GetAllUsers() => _users;

        private void Save()
        {
            try
            {
                _repository.SaveAll(_users);
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }
        }
    }
}

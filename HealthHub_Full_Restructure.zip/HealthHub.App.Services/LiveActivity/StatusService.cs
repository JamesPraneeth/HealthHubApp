using System;

namespace HealthHub.App.Services.LiveActivity
{
    // Moved from Infrastructure/StatusService.cs. This is a cross-cutting
    // pub/sub bus used by several ViewModels (OT, Home, PatientDetails) to
    // announce "something just happened" - it's an application-level
    // concern, not raw data-access, so it belongs in App.Services rather
    // than sitting in the same Infrastructure grab-bag the old XML/DB
    // plumbing lived in. No behavior change - same static Publish/StatusChanged.
    public static class StatusService
    {
        public static event Action<string>? StatusChanged;

        public static void Publish(string message)
        {
            StatusChanged?.Invoke(message);
        }
    }
}

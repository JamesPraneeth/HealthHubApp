using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.AppointmentScheduler;
using HealthHub.Domain.Repositories.Repositories;
using HealthHub.Domain.Repositories.SurgicalDocumentation;

namespace HealthHub.App.Services.AppointmentScheduler
{
    // Replaces Infrastructure/XmlRoomStorage.cs and the
    // HospitalRoomConfiguration wrapper class it used to route through.
    //
    // IMPORTANT: this is registered as a single shared instance in the
    // composition root (App.xaml.cs), and both OTViewModel and
    // HomeViewModel are given a reference to the *same* instance. That
    // matters: in the old code, OTViewModel's RoomList and the Rooms that
    // HomeViewModel read via XmlDatabaseManager.Database.RoomConfiguration
    // were literally the same in-memory HospitalRoom objects, which is
    // exactly why the Home dashboard updated live as bookings happened in
    // OTViewModel without needing to reload from disk. Rooms here
    // preserves that by being the one shared collection both ViewModels
    // read from.
    //
    // Also adds real persistence for completed-surgery logs
    // (SurgicalLogs.xml), which the old app never saved to disk at all -
    // see SurgicalDocRepository for details. Flagged in the README.
    public class RoomSchedulingService
    {
        private readonly RoomRepository _roomRepository;
        private readonly SurgicalDocRepository _logRepository;

        public ObservableCollection<HospitalRoom> Rooms { get; } = new ObservableCollection<HospitalRoom>();
        public ObservableCollection<SurgicalLog> SurgicalLogs { get; } = new ObservableCollection<SurgicalLog>();

        public event Action<string>? PersistenceError;

        public RoomSchedulingService(RoomRepository roomRepository, SurgicalDocRepository logRepository)
        {
            _roomRepository = roomRepository ?? throw new ArgumentNullException(nameof(roomRepository));
            _logRepository = logRepository ?? throw new ArgumentNullException(nameof(logRepository));

            try
            {
                foreach (var room in _roomRepository.GetAll())
                {
                    room.ICUPatients ??= new List<ICUPatientInfo>();
                    room.OPDPatients ??= new List<OPDPatientInfo>();
                    room.OTSurgeries ??= new List<OTScheduledSurgery>();
                    Rooms.Add(room);
                }
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }

            try
            {
                foreach (var log in _logRepository.GetAll())
                    SurgicalLogs.Add(log);
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }
        }

        // Called explicitly after a booking/ICU/OPD/surgery-completion
        // change, mirroring the old SaveHospitalRoomConfiguration() call
        // sites in OTViewModel. Not auto-saved on every property change,
        // same as before - the nested ICU/OPD/OT sub-lists aren't
        // observable, so there's nothing to hook automatically anyway.
        public void SaveRooms()
        {
            try
            {
                _roomRepository.SaveAll(new List<HospitalRoom>(Rooms));
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }
        }

        public void AddSurgicalLog(SurgicalLog log)
        {
            SurgicalLogs.Add(log);

            try
            {
                _logRepository.SaveAll(new List<SurgicalLog>(SurgicalLogs));
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }
        }
    }
}

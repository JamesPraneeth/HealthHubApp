using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Repositories;
using HealthHub.Domain.Repositories.SurgeonManagement;

namespace HealthHub.App.Services.SurgeonManagement
{
    // Renamed from the old Infrastructure/SurgeonStore.cs. Same public
    // shape as before (ObservableCollection<Surgeon> Surgeons, search/filter
    // state, ClearFilters()) - only the persistence underneath changed.
    public class SurgeonService : INotifyPropertyChanged
    {
        private readonly SurgeonRepository _repository;

        public ObservableCollection<Surgeon> Surgeons { get; } = new ObservableCollection<Surgeon>();

        public event Action<string>? PersistenceError;

        private string _searchText = string.Empty;
        private string _selectedSearchBy = "Name";
        private string _selectedFilterBy = "None";
        private string _selectedFilterValue = "All";

        public SurgeonService(SurgeonRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            List<Surgeon> initial;
            try
            {
                initial = _repository.GetAll();
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
                initial = new List<Surgeon>();
            }

            foreach (var s in initial)
            {
                s.PropertyChanged += Item_PropertyChanged;
                Surgeons.Add(s);
            }

            Surgeons.CollectionChanged += Surgeons_CollectionChanged;
        }

        private void Surgeons_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null)
                foreach (Surgeon s in e.OldItems) s.PropertyChanged -= Item_PropertyChanged;

            if (e.NewItems != null)
                foreach (Surgeon s in e.NewItems) s.PropertyChanged += Item_PropertyChanged;

            SyncAndSave();
        }

        private void Item_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(Surgeon.IsSelected)) SyncAndSave();
        }

        private void SyncAndSave()
        {
            try
            {
                _repository.SaveAll(new List<Surgeon>(Surgeons));
            }
            catch (RepositoryException ex)
            {
                PersistenceError?.Invoke(ex.Message);
            }
        }

        public string SearchText
        {
            get => _searchText;
            set => SetProperty(ref _searchText, value);
        }

        public string SelectedSearchBy
        {
            get => _selectedSearchBy;
            set => SetProperty(ref _selectedSearchBy, value);
        }

        public string SelectedFilterBy
        {
            get => _selectedFilterBy;
            set => SetProperty(ref _selectedFilterBy, value);
        }

        public string SelectedFilterValue
        {
            get => _selectedFilterValue;
            set => SetProperty(ref _selectedFilterValue, value);
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = "")
        {
            if (!Equals(field, value))
            {
                field = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public void ClearFilters()
        {
            SearchText = string.Empty;
            SelectedSearchBy = "Name";
            SelectedFilterBy = "None";
            SelectedFilterValue = "All";
        }
    }
}

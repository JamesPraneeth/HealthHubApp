# HealthHub — Restructuring Guide

## What This Package Contains

Every C# file that changed is here, organized into the exact folder under its project. Drop
the contents of each top-level folder into the matching project folder in Visual Studio. The
`.xaml` files for views that were **not** changed structurally are not included again —
those are in the first zip (`HealthHub_Restructure.zip`). Only the ones that needed a
namespace or using-directive fix (`AddPatientWindow.xaml`, `HomeView.xaml`) are included
here.

---

## File → Project Map

### HealthHub.Domain.Entities  *(class library, no WPF reference)*
| File | Notes |
|---|---|
| `Patient.cs` | Moved from `Models/Patient.cs`. Namespace: `HealthHub.Domain.Entities` |
| `Surgeon.cs` | Moved from `Models/Surgeon.cs`. Namespace: `HealthHub.Domain.Entities` |
| `HospitalRoom.cs` | Extracted from `HospitalRoomConfiguration.cs` |
| `ICUPatientInfo.cs` | Extracted from `HospitalRoomConfiguration.cs` |
| `OPDPatientInfo.cs` | Extracted from `HospitalRoomConfiguration.cs` |
| `OTScheduledSurgery.cs` | Moved from `OperationTheatre/OTScheduledSurgery.cs` |
| `SurgicalLog.cs` | Renamed from `OTScheduleLog.cs` |
| `UserAccount.cs` | **New entity.** See "Behavior Changes" below |

> ⚠️ Delete the stray `SurgeonRepository.cs` that the old tree shows sitting directly
> inside `HealthHub.Domain.Entities/`. A repository does not belong in the Entities
> project — the correct one is in `HealthHub.Domain.Repositories/SurgeonManagement/`.

---

### HealthHub.Domain.Repositories  *(class library, no WPF reference)*
| Folder / File | Notes |
|---|---|
| `Repositories/IRepository.cs` | Generic `GetAll / SaveAll` interface |
| `Repositories/XmlRepository.cs` | Generic base class; serializes `List<T>` to one XML file each |
| `Repositories/RepositoryException.cs` | Replaces MessageBox calls inside old `XmlDatabaseManager` |
| `PatientManagement/PatientRepository.cs` | Writes `Data/Patients.xml` |
| `SurgeonManagement/SurgeonRepository.cs` | Writes `Data/Surgeons.xml` |
| `AppointmentScheduler/RoomRepository.cs` | Writes `Data/Rooms.xml` |
| `SurgicalDocumentation/SurgicalDocRepository.cs` | Writes `Data/SurgicalLogs.xml` |
| `Auth/UserRepository.cs` | **New.** Writes `Data/Users.xml`. See "Behavior Changes" |

**Data directory:** `XmlRepository<T>` writes to `<ExeFolder>/../../../Data/` (three
levels up from `bin\Debug\net10.0-windows\`, landing in the solution root alongside the
projects). This mirrors where the old `HospitalDatabase.xml` was written. If you prefer a
different path, change `GetDataDirectory()` in `XmlRepository.cs`.

---

### HealthHub.App.Services  *(class library, no WPF reference)*
| Folder / File | Replaces |
|---|---|
| `PatientManagement/PatientService.cs` | `Infrastructure/PatientStore.cs` |
| `SurgeonManagement/SurgeonService.cs` | `Infrastructure/SurgeonStore.cs` |
| `AppointmentScheduler/RoomSchedulingService.cs` | `Infrastructure/XmlRoomStorage.cs` + `HospitalRoomConfiguration` wrapper |
| `Auth/AuthService.cs` | `Infrastructure/UserStore.cs` |
| `LiveActivity/StatusService.cs` | `Infrastructure/StatusService.cs` |

The old `XmlDatabaseManager.cs`, `HospitalDatabase.cs`, `XmlRoomStorage.cs`, and
`LiveStatusStore.cs` are **replaced entirely** and should be deleted from the solution.

**PersistenceError event:** `XmlDatabaseManager` used to call `MessageBox.Show()`
directly from inside the data layer (a WPF call inside a data class). The new repositories
throw `RepositoryException` instead. The Services catch that and raise a `PersistenceError`
event. `App.xaml.cs` subscribes to all four events and shows the MessageBox from there,
keeping the data layer free of any WPF dependency.

---

### HealthHub.App.Views  *(class library, references WPF)*
| File | Notes |
|---|---|
| `AppShell.cs` | **New.** Static delegates replacing `MainWindow.Instance.*` calls |
| `Converters/StatusToTimeConverter.cs` | Moved from `Infrastructure/`. Namespace: `HealthHub.App.Views.Converters` |
| `Localization/LocalizationService.cs` | Moved from `Infrastructure/`. Namespace: `HealthHub.App.Views.Localization` |
| `Views/About/AboutView.xaml.cs` | Namespace updated |
| `Views/AddPatient/AddPatientView.xaml.cs` | Namespace updated |
| `Views/AddPatient/AddPatientWindow.xaml` | `x:Class` + `xmlns:add` updated |
| `Views/AddPatient/AddPatientWindow.xaml.cs` | DataContext removed (now wired externally) |
| `Views/AddSurgeon/AddSurgeonView.xaml.cs` | Namespace updated |
| `Views/Header/HeaderView.xaml.cs` | `MainWindow.Instance.LoadLoginScreen()` → `AppShell.ShowLogin()` |
| `Views/Home/HomeView.xaml` | Converter xmlns updated to `HealthHub.App.Views.Converters` |
| `Views/Home/HomeView.xaml.cs` | DataContext removed; `PatientInformationSystem.Infrastructure.StatusService` → `HealthHub.App.Services.LiveActivity.StatusService` |
| `Views/Login/LoginView.xaml.cs` | Auth + navigation via `AppShell` |
| `Views/Login/RegisterView.xaml.cs` | Auth + navigation via `AppShell` |
| `Views/Navigation/SideNavView.xaml.cs` | Namespace updated |
| `Views/OT/OTView.xaml.cs` | DataContext removed (now wired externally) |
| `Views/PatientDetails/EditPatientWindow.xaml.cs` | Namespace updated |
| `Views/PatientDetails/PatientDetailsView.xaml.cs` | DataContext removed (now wired externally) |
| `Views/SearchBar/SearchBarView.xaml.cs` | DataContext removed (now wired externally) |
| `Views/SurgeonDetails/SurgeonDetailsView.xaml.cs` | DataContext removed (now wired externally) |
| `Views/SurgeonSearchBar/SurgeonSearchBarView.xaml.cs` | DataContext removed (now wired externally) |

**Why DataContext was removed from views:** `HealthHub.App.Views` is a class library that
cannot reference `HealthHub` (the exe) without creating a circular project dependency —
`HealthHub` already references `HealthHub.App.Views`. Any ViewModel that lives in
`HealthHub` therefore can't be instantiated inside a View. DataContext assignment for all
affected views has been moved to `MainWindow.xaml.cs`.

**Why `LocalizationManager.cs` is not included:** The old codebase had two nearly
identical localization classes (`LocalizationManager.cs` with namespace
`SimpleLoginApp.Infrastructure` and `LocalizationService.cs` with namespace
`PatientInformationSystem.Infrastructure`). Only `LocalizationService` was actually used
anywhere. `LocalizationManager` can be deleted.

---

### HealthHub  *(WPF exe)*
| File | Notes |
|---|---|
| `App.xaml` | `x:Class` updated to `HealthHub.App` |
| `App.xaml.cs` | **Composition root.** Replaces `App.PatientStore/SurgeonStore` with `PatientService/SurgeonService/RoomSchedulingService/AuthService`. Wires PersistenceError events |
| `MainWindow.xaml` | `x:Class` updated; `xmlns:header` and `xmlns:nav` updated to use `assembly=HealthHub.App.Views` qualifier |
| `MainWindow.xaml.cs` | Wires AppShell delegates; moves DataContext assignment for all externalized views here |
| `Infrastructure/RelayCommand.cs` | Moved from `Infrastructure/RelayCommand.cs`. Stays in `HealthHub` because it implements `System.Windows.Input.ICommand` (WPF) |
| `ViewModels/AddPatient/AddPatientViewModel.cs` | `PatientStore` → `PatientService`; `RelayCommand` namespace updated |
| `ViewModels/AddSurgeon/AddSurgeonViewModel.cs` | `App.SurgeonStore` → `App.SurgeonService` |
| `ViewModels/Header/HeaderViewModel.cs` | Namespace updated (stub) |
| `ViewModels/Home/HomeViewModel.cs` | `XmlDatabaseManager.Database.RoomConfiguration` → `RoomSchedulingService.Rooms`; constructor now takes `SurgeonService + RoomSchedulingService` |
| `ViewModels/Home/PieGeometryHelper.cs` | Namespace updated |
| `ViewModels/Home/PieSliceViewModel.cs` | Namespace updated |
| `ViewModels/Navigation/SideNavViewModel.cs` | Namespace updated |
| `ViewModels/OT/OTViewModel.cs` | `XmlRoomStorage.Load/Save` → `RoomSchedulingService.Rooms / SaveRooms()`; `App.SurgeonStore` → `App.SurgeonService`; `OTScheduleLog` → `SurgicalLog` |
| `ViewModels/PatientDetails/EditPatientViewModel.cs` | Namespace updated |
| `ViewModels/PatientDetails/PatientDetailsViewModel.cs` | `PatientStore` → `PatientService`; `StatusService` namespace updated |
| `ViewModels/SearchBar/SearchBarViewModel.cs` | `PatientStore` → `PatientService`; `App.PatientStore` → `App.PatientService`; DataContext wiring for `AddPatientWindow` moved here |
| `ViewModels/SurgeonDetails/SurgeonDetailsViewModel.cs` | `SurgeonStore` → `SurgeonService` |
| `ViewModels/SurgeonSearchBar/SurgeonSearchBarViewModel.cs` | `App.SurgeonStore` → `App.SurgeonService` |

---

### Data/  *(seed XML files — place alongside the solution or wherever XmlRepository points)*
| File | Notes |
|---|---|
| `Patients.xml` | Empty seed. App populates on first use |
| `Surgeons.xml` | Empty seed |
| `Rooms.xml` | Empty seed. App creates default rooms on first run |
| `SurgicalLogs.xml` | Empty seed |
| `Users.xml` | Empty seed. `App.xaml.cs` registers the demo user (user123 / User@123) on first run |

Place these in `<SolutionRoot>/Data/`. If you have an existing `HospitalDatabase.xml` with
live data, see "Migrating existing data" below.

---

## Project References (what references what)

```
HealthHub (exe / WPF)
  └── HealthHub.App.Views
  └── HealthHub.App.Services
  └── HealthHub.Domain.Entities
  └── HealthHub.Domain.Repositories

HealthHub.App.Views (class library / WPF)
  └── HealthHub.App.Services
  └── HealthHub.Domain.Entities

HealthHub.App.Services (class library / no WPF)
  └── HealthHub.Domain.Entities
  └── HealthHub.Domain.Repositories

HealthHub.Domain.Repositories (class library / no WPF)
  └── HealthHub.Domain.Entities

HealthHub.Domain.Entities (class library / no WPF)
  (no project references)
```

No circular dependencies. `HealthHub.Domain.Repositories` and `HealthHub.App.Services`
have zero WPF references — they target `net10.0` (not `net10.0-windows`), so remove
`<UseWPF>true</UseWPF>` and change the TFM in their `.csproj` files if they currently
have it.

---

## Behavior Changes (intentional, flagged here)

### 1. Registered user accounts now persist across restarts
The old `UserStore` was an in-memory `Dictionary` that reset every time the app started.
Only the hardcoded demo account (`user123 / User@123`) came back because `App.xaml.cs`
called `UserStore.RegisterUser()` in the constructor. Any account a user registered during
a session was silently lost on restart.

`AuthService` backed by `UserRepository` now persists all accounts to `Data/Users.xml`.
The demo account is still registered via `App.xaml.cs` on every start, but
`AuthService.RegisterUser` is now a no-op when the userId already exists, so the file
stays clean. **Net result: users registered during one session will still exist in the
next.**

### 2. Completed surgery logs now persist across restarts
The old `OTViewModel` kept completed-surgery logs (`OTScheduleLog`) in a private
`ObservableCollection<OTScheduleLog> _allLogs` that was never written to
`HospitalDatabase.xml`. The logs disappeared on every restart. `SurgicalDocRepository`
backed by `Data/SurgicalLogs.xml` now persists them.

### 3. One XML file per entity instead of one shared XML
The old app read and wrote everything through a single `HospitalDatabase.xml`.
The new layout is:
```
Data/Patients.xml
Data/Surgeons.xml
Data/Rooms.xml
Data/SurgicalLogs.xml
Data/Users.xml
```
The shape of the data inside each file is identical to how it appeared inside the old
combined file (same element names, same attributes, same nesting for ICU/OPD/OT
sub-lists). If you have an existing `HospitalDatabase.xml` with live data, see the
migration note below.

---

## Migrating Existing Data from HospitalDatabase.xml

The old XML had this shape:
```xml
<HospitalDatabase>
  <Patients>
    <Patient>...</Patient>
  </Patients>
  <Surgeons>
    <Surgeon>...</Surgeon>
  </Surgeons>
  <RoomConfiguration>
    <Rooms>
      <HospitalRoom>...</HospitalRoom>
    </Rooms>
  </RoomConfiguration>
</HospitalDatabase>
```

To migrate:
1. Copy the `<Patients>...</Patients>` block into `Data/Patients.xml` as the root element.
2. Copy the `<Surgeons>...</Surgeons>` block into `Data/Surgeons.xml` as the root element.
3. Copy the inner `<Rooms>...</Rooms>` block (the one containing `<HospitalRoom>` items)
   from inside `<RoomConfiguration>` into `Data/Rooms.xml` as the root element.
4. `Data/SurgicalLogs.xml` and `Data/Users.xml` start empty — the app builds them fresh.

---

## XAML Files Still Needing x:Class and Namespace Updates

The following XAML files from the first zip (`HealthHub_Restructure.zip`) still carry the
old `PatientInformationSystem.*` x:Class and clr-namespace values. Update them to match
their new namespace. The pattern is consistent: replace
`PatientInformationSystem.<SubNamespace>.<ClassName>` with
`HealthHub.App.Views.<SubNamespace>.<ClassName>`.

Files needing this update (everything except `HomeView.xaml` and `AddPatientWindow.xaml`,
which are included in this zip already updated):

- `AboutView.xaml`
- `AddPatientView.xaml`
- `AddSurgeonView.xaml`
- `HeaderView.xaml`
- `LoginView.xaml`
- `RegisterView.xaml`
- `SideNavView.xaml`
- `OTView.xaml`
- `EditPatientWindow.xaml`
- `PatientDetailsView.xaml`
- `SearchBarView.xaml`
- `SurgeonDetailsView.xaml`
- `SurgeonSearchBarView.xaml`

For any that use `xmlns:*="clr-namespace:PatientInformationSystem.*"`, add
`;assembly=HealthHub.App.Views` when the referenced type lives in the Views project, or
use the fully qualified `HealthHub.*` namespace if it lives elsewhere.

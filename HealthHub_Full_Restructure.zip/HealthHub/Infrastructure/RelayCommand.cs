using System;
using System.Windows.Input;

namespace HealthHub.Infrastructure
{
    // Moved from Infrastructure/RelayCommand.cs. This implements
    // System.Windows.Input.ICommand, which lives in WPF's
    // PresentationCore/WindowsBase assemblies - so unlike the data-access
    // and service classes, this has to stay in the HealthHub (WPF exe)
    // project rather than HealthHub.App.Services, since Services
    // deliberately has no WPF reference.
    public class RelayCommand : ICommand
    {
        private readonly Action? _execute;
        private readonly Action<object?>? _executeWithParam;
        private readonly Func<bool>? _canExecute;
        private readonly Func<object?, bool>? _canExecuteWithParam;

        public event EventHandler? CanExecuteChanged;

        // Parameterless
        public RelayCommand(Action execute, Func<bool>? canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        // With parameter
        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _executeWithParam = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecuteWithParam = canExecute;
        }

        public bool CanExecute(object? parameter)
        {
            if (_canExecute != null) return _canExecute();
            if (_canExecuteWithParam != null) return _canExecuteWithParam(parameter);
            return true;
        }

        public void Execute(object? parameter)
        {
            if (_execute != null) _execute();
            else _executeWithParam?.Invoke(parameter);
        }

        public void RaiseCanExecuteChanged()
            => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}

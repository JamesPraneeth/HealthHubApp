using System.Windows;
using HealthHub.App.Services.AppointmentScheduler;
using HealthHub.App.Services.Auth;
using HealthHub.App.Services.PatientManagement;
using HealthHub.App.Services.SurgeonManagement;
using HealthHub.Domain.Repositories.AppointmentScheduler;
using HealthHub.Domain.Repositories.Auth;
using HealthHub.Domain.Repositories.PatientManagement;
using HealthHub.Domain.Repositories.SurgeonManagement;
using HealthHub.Domain.Repositories.SurgicalDocumentation;

namespace HealthHub
{
    public partial class App : Application
    {
        // Composition root: this is the one place that knows about
        // repositories at all. Everything downstream (ViewModels) only
        // ever sees the Services, exactly like they only ever saw
        // PatientStore/SurgeonStore before.
        public static PatientService PatientService { get; private set; } = null!;
        public static SurgeonService SurgeonService { get; private set; } = null!;
        public static RoomSchedulingService RoomSchedulingService { get; private set; } = null!;
        public static AuthService AuthService { get; private set; } = null!;

        public App()
        {
            var patientRepository = new PatientRepository();
            var surgeonRepository = new SurgeonRepository();
            var roomRepository = new RoomRepository();
            var surgicalDocRepository = new SurgicalDocRepository();
            var userRepository = new UserRepository();

            PatientService = new PatientService(patientRepository);
            SurgeonService = new SurgeonService(surgeonRepository);
            RoomSchedulingService = new RoomSchedulingService(roomRepository, surgicalDocRepository);
            AuthService = new AuthService(userRepository);

            // The Services/Repositories projects deliberately have no WPF
            // reference, so they can't show a MessageBox themselves (the
            // old XmlDatabaseManager did, directly from the data layer,
            // which was the separation-of-concerns problem this refactor
            // fixes). They raise PersistenceError instead; this is where
            // that surfaces to the user, same as before.
            PatientService.PersistenceError += ShowPersistenceError;
            SurgeonService.PersistenceError += ShowPersistenceError;
            RoomSchedulingService.PersistenceError += ShowPersistenceError;
            AuthService.PersistenceError += ShowPersistenceError;

            DemoUser();
        }

        private static void ShowPersistenceError(string message)
        {
            MessageBox.Show(message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        public void DemoUser()
        {
            // Same demo account as before. Now that users persist to
            // Data/Users.xml, this only actually registers on the very
            // first run - RegisterUser just returns false (a no-op) on
            // every run after that once "user123" already exists.
            AuthService.RegisterUser("user123", "User@123");
        }
    }
}

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using HealthHub.App.Services.PatientManagement;
using HealthHub.App.Views.AddPatient;
using HealthHub.Infrastructure;
using HealthHub.ViewModels.AddPatient;

namespace HealthHub.ViewModels.SearchBar
{
    public class SearchBarViewModel : INotifyPropertyChanged
    {
        private readonly PatientService _store;

        public ObservableCollection<string> SearchByOptions { get; } =
            new ObservableCollection<string>
            {
                "Name",
                "Email ID"
            };

        public ObservableCollection<string> FilterByOptions { get; } =
            new ObservableCollection<string>
            {
                "None",
                "Gender"
            };

        public ObservableCollection<string> FilterValueOptions { get; private set; } =
            new ObservableCollection<string> { "All" };

        public event PropertyChangedEventHandler? PropertyChanged;

        public string SelectedSearchBy
        {
            get => _store.SelectedSearchBy;
            set
            {
                if (_store.SelectedSearchBy != value)
                {
                    _store.SelectedSearchBy = value;
                    OnPropertyChanged();
                }
            }
        }

        public string SearchText
        {
            get => _store.SearchText;
            set
            {
                if (_store.SearchText != value)
                {
                    _store.SearchText = value;
                    OnPropertyChanged();
                }
            }
        }

        public string SelectedFilterBy
        {
            get => _store.SelectedFilterBy;
            set
            {
                if (_store.SelectedFilterBy != value)
                {
                    _store.SelectedFilterBy = value;
                    UpdateFilterValues();
                    _store.SelectedFilterValue = "All";

                    OnPropertyChanged();
                    OnPropertyChanged(nameof(SelectedFilterValue));
                }
            }
        }

        public string SelectedFilterValue
        {
            get => _store.SelectedFilterValue;
            set
            {
                if (_store.SelectedFilterValue != value)
                {
                    _store.SelectedFilterValue = value;
                    OnPropertyChanged();
                }
            }
        }

        public ICommand OpenAddPatientCommand { get; }
        public ICommand ClearFilterCommand { get; }

        public SearchBarViewModel()
        {
            _store = App.PatientService;

            OpenAddPatientCommand = new RelayCommand(OpenAddPatient);
            ClearFilterCommand = new RelayCommand(ClearFilter);

            UpdateFilterValues();
        }

        private void OpenAddPatient()
        {
            var win = new AddPatientWindow
            {
                Owner = Application.Current.MainWindow,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            // AddPatientWindow used to build its own AddPatientViewModel
            // internally. That's no longer possible now that Views and
            // ViewModels live in separate projects (a View can't reference
            // the ViewModels project without creating a circular project
            // reference) - so the ViewModel is built and wired up here
            // instead, exactly like EditPatientWindow/AddSurgeonView
            // already did in the old code. See README.
            var viewModel = new AddPatientViewModel(_store.Patients, win.Close);
            win.DataContext = viewModel;

            win.ShowDialog();
        }

        private void ClearFilter()
        {
            _store.ClearFilters();

            UpdateFilterValues();

            OnPropertyChanged(nameof(SearchText));
            OnPropertyChanged(nameof(SelectedSearchBy));
            OnPropertyChanged(nameof(SelectedFilterBy));
            OnPropertyChanged(nameof(SelectedFilterValue));
            OnPropertyChanged(nameof(FilterValueOptions));
        }

        private void UpdateFilterValues()
        {
            FilterValueOptions.Clear();
            FilterValueOptions.Add("All");

            if (SelectedFilterBy == "Gender")
            {
                FilterValueOptions.Add("Male");
                FilterValueOptions.Add("Female");
                FilterValueOptions.Add("I Prefer Not To Say");
            }

            OnPropertyChanged(nameof(FilterValueOptions));
        }

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}

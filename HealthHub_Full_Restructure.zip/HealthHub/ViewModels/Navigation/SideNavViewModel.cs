using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using HealthHub.Infrastructure;

namespace HealthHub.ViewModels.Navigation
{
    public class SideNavViewModel : INotifyPropertyChanged
    {
        private double _navWidth = 95;
        private Visibility _textVisibility = Visibility.Collapsed;
        private bool _isExpanded;

        public double NavWidth
        {
            get => _navWidth;
            set
            {
                if (_navWidth != value)
                {
                    _navWidth = value;
                    OnPropertyChanged(nameof(NavWidth));
                }
            }
        }

        public Visibility TextVisibility
        {
            get => _textVisibility;
            set
            {
                if (_textVisibility != value)
                {
                    _textVisibility = value;
                    OnPropertyChanged(nameof(TextVisibility));
                }
            }
        }

        public ICommand ToggleCommand { get; }
        public ICommand NavigateHomeCommand { get; }
        public ICommand NavigatePatientCommand { get; }
        public ICommand NavigateSurgeonCommand { get; }
        public ICommand NavigateAboutCommand { get; }
        public ICommand NavigateOTCommand { get; }

        public Action? ShowHome { get; set; }
        public Action? ShowPatient { get; set; }
        public Action? ShowSurgeon { get; set; }
        public Action? ShowAbout { get; set; }
        public Action? ShowOT { get; set; }

        public SideNavViewModel()
        {
            ToggleCommand = new RelayCommand(ToggleNav);

            NavigateHomeCommand = new RelayCommand(NavigateHome);
            NavigatePatientCommand = new RelayCommand(NavigatePatient);
            NavigateSurgeonCommand = new RelayCommand(NavigateSurgeon);
            NavigateAboutCommand = new RelayCommand(NavigateAbout);
            NavigateOTCommand = new RelayCommand(NavigateOT);
        }

        private void ToggleNav()
        {
            _isExpanded = !_isExpanded;

            // Use 240 if you want compact expanded nav.
            // Use 300 if your text is getting cut.
            NavWidth = _isExpanded ? 300 : 95;

            TextVisibility = _isExpanded
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void NavigateHome()
        {
            ShowHome?.Invoke();
        }

        private void NavigatePatient()
        {
            ShowPatient?.Invoke();
        }

        private void NavigateSurgeon()
        {
            ShowSurgeon?.Invoke();
        }

        private void NavigateAbout()
        {
            ShowAbout?.Invoke();
        }

        private void NavigateOT()
        {
            ShowOT?.Invoke();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

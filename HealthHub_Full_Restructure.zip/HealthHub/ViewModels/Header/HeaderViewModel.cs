namespace HealthHub.ViewModels.Header
{
    class HeaderViewModel
    {
    }
}

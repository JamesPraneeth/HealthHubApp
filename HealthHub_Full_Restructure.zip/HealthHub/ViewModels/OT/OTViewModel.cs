using Microsoft.Win32;
using HealthHub.App.Services.AppointmentScheduler;
using HealthHub.App.Services.LiveActivity;
using HealthHub.Domain.Entities;
using HealthHub.Infrastructure;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace HealthHub.ViewModels.OT
{
    public class OTViewModel : System.ComponentModel.INotifyPropertyChanged
    {
        private readonly RoomSchedulingService _roomSchedulingService;

        private string _selectedRoomType = string.Empty;
        private string _selectedRoomName = string.Empty;

        private string _selectedOT = string.Empty;
        private string _selectedDoctor = string.Empty;
        private string _selectedPatient = string.Empty;
        private string _selectedProcedure = string.Empty;
        private DateTime? _selectedDate;

        private string _selectedStartHour = string.Empty;
        private string _selectedStartMinute = string.Empty;
        private string _selectedEndHour = string.Empty;
        private string _selectedEndMinute = string.Empty;

        private string _surgeryDocument = string.Empty;
        private string _scheduleStatus = "Please select room type.";

        private bool _isSurgeryActive;
        private bool _isRefreshingScheduledSurgeries;

        private HospitalRoom? _selectedRoom;
        private OTScheduledSurgery? _selectedScheduledSurgery;

        private string _icuPatientName = string.Empty;
        private DateTime? _icuStartDate;
        private DateTime? _icuEndDate;

        private string _opdPatientName = string.Empty;
        private string _opdPhysicianName = string.Empty;
        private DateTime? _opdDate;
        private string _opdTime = string.Empty;
        private string _opdReason = string.Empty;

        private readonly DispatcherTimer _timer;

        private readonly ObservableCollection<OTScheduledSurgery> _allScheduledSurgeries = new();

        public ObservableCollection<string> RoomTypes { get; } = new()
        {
            "OT",
            "OPD",
            "ICU"
        };

        public ObservableCollection<string> RoomNames { get; } = new();

        // Aliases the shared RoomSchedulingService.Rooms collection rather
        // than keeping its own copy. This preserves the old behavior where
        // OTViewModel and HomeViewModel both read/wrote the exact same
        // in-memory HospitalRoom objects (see RoomSchedulingService for
        // why that matters).
        public ObservableCollection<HospitalRoom> RoomList => _roomSchedulingService.Rooms;

        public ObservableCollection<string> DoctorList { get; } = new();
        public ObservableCollection<string> PatientList { get; } = new();
        public ObservableCollection<string> ProcedureList { get; } = new();

        public ObservableCollection<string> HourOptions { get; } = new();
        public ObservableCollection<string> MinuteOptions { get; } = new();

        public ObservableCollection<OTScheduledSurgery> VisibleScheduledSurgeries { get; } = new();
        public ObservableCollection<SurgicalLog> VisibleSurgeryLogs { get; } = new();

        public ObservableCollection<ICUPatientInfo> VisibleICUPatients { get; } = new();
        public ObservableCollection<OPDPatientInfo> VisibleOPDPatients { get; } = new();

        public ICommand ScheduleSurgeryCommand { get; }
        public ICommand EndSurgeryCommand { get; }
        public ICommand AddICUPatientCommand { get; }
        public ICommand AddOPDPatientCommand { get; }

        public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;

        public OTViewModel()
        {
            _roomSchedulingService = App.RoomSchedulingService;

            LoadHospitalRoomConfiguration();
            LoadDoctors();
            LoadPatients();
            LoadProcedures();
            LoadTimeOptions();

            App.PatientService.Patients.CollectionChanged += (s, e) =>
            {
                LoadPatients();
            };

            App.SurgeonService.Surgeons.CollectionChanged += (s, e) =>
            {
                LoadDoctors();
            };

            ScheduleSurgeryCommand = new RelayCommand(ScheduleSurgery);
            EndSurgeryCommand = new RelayCommand(EndSurgery);
            AddICUPatientCommand = new RelayCommand(AddICUPatient);
            AddOPDPatientCommand = new RelayCommand(AddOPDPatient);

            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(10)
            };

            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        public string SelectedRoomType
        {
            get => _selectedRoomType;
            set
            {
                if (_selectedRoomType != value)
                {
                    _selectedRoomType = value;
                    OnPropertyChanged(nameof(SelectedRoomType));

                    // Reset
                    SelectedRoomName = string.Empty;
                    SelectedRoom = null;

                    LoadRoomsByType();
                    ClearVisibleData();

                    // LOGIC CHANGE: If OPD, automatically select the only available OPD room
                    if (_selectedRoomType == "OPD")
                    {
                        SelectedRoomName = "OPD-1"; // Forces the selection
                    }

                    ScheduleStatus = string.IsNullOrWhiteSpace(_selectedRoomType)
                        ? "Please select room type."
                        : $"Selected {_selectedRoomType}.";

                    NotifyVisibilityProperties();
                    OnPropertyChanged(nameof(IsRoomSelectionVisible)); // Notify UI to hide dropdown
                }
            }
        }
        public bool IsRoomSelectionVisible => SelectedRoomType != "OPD";
        public string SelectedRoomName
        {
            get => _selectedRoomName;
            set
            {
                if (_selectedRoomName != value)
                {
                    _selectedRoomName = value;
                    OnPropertyChanged(nameof(SelectedRoomName));

                    SetSelectedRoomFromTypeAndName();
                }
            }
        }

        public HospitalRoom? SelectedRoom
        {
            get => _selectedRoom;
            set
            {
                if (_selectedRoom != value)
                {
                    _selectedRoom = value;
                    OnPropertyChanged(nameof(SelectedRoom));

                    SelectedOT = _selectedRoom?.RoomName ?? string.Empty;

                    SelectedScheduledSurgery = null;
                    SurgeryDocument = string.Empty;
                    IsSurgeryActive = false;

                    ClearICUInputs();
                    ClearOPDInputs();

                    RefreshRoomBasedData();

                    ScheduleStatus = _selectedRoom == null
                        ? "Please select room."
                        : $"Selected {_selectedRoom.DisplayName}.";

                    NotifyVisibilityProperties();
                }
            }
        }

        public string SelectedOT
        {
            get => _selectedOT;
            set
            {
                if (_selectedOT != value)
                {
                    _selectedOT = value;
                    OnPropertyChanged(nameof(SelectedOT));

                    RefreshVisibleScheduledSurgeries();
                    RefreshVisibleLogs();
                }
            }
        }

        public string SelectedDoctor
        {
            get => _selectedDoctor;
            set
            {
                if (_selectedDoctor != value)
                {
                    _selectedDoctor = value;
                    OnPropertyChanged(nameof(SelectedDoctor));
                }
            }
        }

        public string SelectedPatient
        {
            get => _selectedPatient;
            set
            {
                if (_selectedPatient != value)
                {
                    _selectedPatient = value;
                    OnPropertyChanged(nameof(SelectedPatient));
                }
            }
        }

        public string SelectedProcedure
        {
            get => _selectedProcedure;
            set
            {
                if (_selectedProcedure != value)
                {
                    _selectedProcedure = value;
                    OnPropertyChanged(nameof(SelectedProcedure));
                }
            }
        }

        public DateTime? SelectedDate
        {
            get => _selectedDate;
            set
            {
                if (_selectedDate != value)
                {
                    _selectedDate = value;
                    OnPropertyChanged(nameof(SelectedDate));
                }
            }
        }

        public string SelectedStartHour
        {
            get => _selectedStartHour;
            set
            {
                if (_selectedStartHour != value)
                {
                    _selectedStartHour = value;
                    OnPropertyChanged(nameof(SelectedStartHour));
                }
            }
        }

        public string SelectedStartMinute
        {
            get => _selectedStartMinute;
            set
            {
                if (_selectedStartMinute != value)
                {
                    _selectedStartMinute = value;
                    OnPropertyChanged(nameof(SelectedStartMinute));
                }
            }
        }

        public string SelectedEndHour
        {
            get => _selectedEndHour;
            set
            {
                if (_selectedEndHour != value)
                {
                    _selectedEndHour = value;
                    OnPropertyChanged(nameof(SelectedEndHour));
                }
            }
        }

        public string SelectedEndMinute
        {
            get => _selectedEndMinute;
            set
            {
                if (_selectedEndMinute != value)
                {
                    _selectedEndMinute = value;
                    OnPropertyChanged(nameof(SelectedEndMinute));
                }
            }
        }

        public string SurgeryDocument
        {
            get => _surgeryDocument;
            set
            {
                if (_surgeryDocument != value)
                {
                    _surgeryDocument = value;
                    OnPropertyChanged(nameof(SurgeryDocument));
                }
            }
        }

        public string ScheduleStatus
        {
            get => _scheduleStatus;
            set
            {
                if (_scheduleStatus != value)
                {
                    _scheduleStatus = value;
                    OnPropertyChanged(nameof(ScheduleStatus));
                }
            }
        }

        public bool IsSurgeryActive
        {
            get => _isSurgeryActive;
            set
            {
                if (_isSurgeryActive != value)
                {
                    _isSurgeryActive = value;
                    OnPropertyChanged(nameof(IsSurgeryActive));
                }
            }
        }

        public OTScheduledSurgery? SelectedScheduledSurgery
        {
            get => _selectedScheduledSurgery;
            set
            {
                if (_isRefreshingScheduledSurgeries && value == null)
                    return;

                if (_selectedScheduledSurgery != value)
                {
                    _selectedScheduledSurgery = value;
                    OnPropertyChanged(nameof(SelectedScheduledSurgery));

                    SurgeryDocument = string.Empty;
                    UpdateSurgeryActiveState();
                }
            }
        }

        public string ICUPatientName
        {
            get => _icuPatientName;
            set
            {
                if (_icuPatientName != value)
                {
                    _icuPatientName = value;
                    OnPropertyChanged(nameof(ICUPatientName));
                }
            }
        }

        public DateTime? ICUStartDate
        {
            get => _icuStartDate;
            set
            {
                if (_icuStartDate != value)
                {
                    _icuStartDate = value;
                    OnPropertyChanged(nameof(ICUStartDate));
                }
            }
        }

        public DateTime? ICUEndDate
        {
            get => _icuEndDate;
            set
            {
                if (_icuEndDate != value)
                {
                    _icuEndDate = value;
                    OnPropertyChanged(nameof(ICUEndDate));
                }
            }
        }

        public string OPDPatientName
        {
            get => _opdPatientName;
            set
            {
                if (_opdPatientName != value)
                {
                    _opdPatientName = value;
                    OnPropertyChanged(nameof(OPDPatientName));
                }
            }
        }

        public string OPDPhysicianName
        {
            get => _opdPhysicianName;
            set
            {
                if (_opdPhysicianName != value)
                {
                    _opdPhysicianName = value;
                    OnPropertyChanged(nameof(OPDPhysicianName));
                }
            }
        }

        public DateTime? OPDDate
        {
            get => _opdDate;
            set
            {
                if (_opdDate != value)
                {
                    _opdDate = value;
                    OnPropertyChanged(nameof(OPDDate));
                }
            }
        }

        public string OPDTime
        {
            get => _opdTime;
            set
            {
                if (_opdTime != value)
                {
                    _opdTime = value;
                    OnPropertyChanged(nameof(OPDTime));
                }
            }
        }

        public string OPDReason
        {
            get => _opdReason;
            set
            {
                if (_opdReason != value)
                {
                    _opdReason = value;
                    OnPropertyChanged(nameof(OPDReason));
                }
            }
        }

        public Visibility OTMenuVisibility =>
            SelectedRoom?.RoomType == "OT" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility ICUMenuVisibility =>
            SelectedRoom?.RoomType == "ICU" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility OPDMenuVisibility =>
            SelectedRoom?.RoomType == "OPD" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility OTSurgeryGridVisibility =>
            SelectedRoom?.RoomType == "OT" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility ICUPatientGridVisibility =>
            SelectedRoom?.RoomType == "ICU" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility OPDPatientGridVisibility =>
            SelectedRoom?.RoomType == "OPD" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility SurgeryDocumentationVisibility =>
            SelectedRoom?.RoomType == "OT" ? Visibility.Visible : Visibility.Collapsed;

        public Visibility SurgeryLogsVisibility =>
            SelectedRoom?.RoomType == "OT" ? Visibility.Visible : Visibility.Collapsed;

        private void LoadRoomsByType()
        {
            RoomNames.Clear();

            if (string.IsNullOrWhiteSpace(SelectedRoomType))
                return;

            // Dynamically filter the actual RoomList based on the SelectedRoomType
            var matchingRooms = RoomList
                .Where(r => string.Equals(r.RoomType, SelectedRoomType, StringComparison.OrdinalIgnoreCase))
                .Select(r => r.RoomName)
                .OrderBy(name => name); // Keeps them in alphabetical order (e.g., ICU-1, ICU-2)

            foreach (var roomName in matchingRooms)
            {
                RoomNames.Add(roomName);
            }

            OnPropertyChanged(nameof(RoomNames));
        }

        private void SetSelectedRoomFromTypeAndName()
        {
            if (string.IsNullOrWhiteSpace(SelectedRoomType) ||
                string.IsNullOrWhiteSpace(SelectedRoomName))
            {
                SelectedRoom = null;
                return;
            }

            var room = RoomList.FirstOrDefault(r =>
                string.Equals(r.RoomType, SelectedRoomType, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(r.RoomName, SelectedRoomName, StringComparison.OrdinalIgnoreCase));

            if (room == null)
            {
                room = new HospitalRoom
                {
                    RoomType = SelectedRoomType,
                    RoomName = SelectedRoomName
                };

                RoomList.Add(room);
            }

            SelectedRoom = room;
        }

        // Was LoadHospitalRoomConfiguration() reading via XmlRoomStorage.Load("").
        // RoomList *is* RoomSchedulingService.Rooms, already loaded from
        // Data/Rooms.xml when the service was constructed at app startup -
        // so this just indexes what's already there and makes sure the
        // default rooms exist, instead of loading from disk itself.
        private void LoadHospitalRoomConfiguration()
        {
            _allScheduledSurgeries.Clear();

            try
            {
                if (RoomList.Count > 0)
                {
                    foreach (var room in RoomList)
                    {
                        room.ICUPatients ??= new();
                        room.OPDPatients ??= new();
                        room.OTSurgeries ??= new();

                        if (string.Equals(room.RoomType, "OT", StringComparison.OrdinalIgnoreCase))
                        {
                            foreach (var surgery in room.OTSurgeries)
                            {
                                surgery.OTName = room.RoomName;
                                _allScheduledSurgeries.Add(surgery);
                            }
                        }
                    }
                }
                else
                {
                    // If the database is truly empty, generate defaults
                    EnsureDefaultRooms();
                    SaveHospitalRoomConfiguration();
                }

                // Ensures any missing rooms are added without wiping existing data
                EnsureDefaultRooms();
                OnPropertyChanged(nameof(RoomList));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load room configuration: {ex.Message}");
                EnsureDefaultRooms();
                SaveHospitalRoomConfiguration();
            }
        }

        private void SaveHospitalRoomConfiguration()
        {
            _roomSchedulingService.SaveRooms();
        }

        private void EnsureDefaultRooms()
        {
            EnsureRoomExists("OT", "OT-1", 1);
            EnsureRoomExists("OT", "OT-2", 1);
            EnsureRoomExists("OT", "OT-3", 1);
            EnsureRoomExists("OT", "OT-4", 1);
            EnsureRoomExists("OT", "OT-5", 1);

            EnsureRoomExists("OPD", "OPD-1", 30);

            EnsureRoomExists("ICU", "ICU-1", 10);
            EnsureRoomExists("ICU", "ICU-2", 10);
            EnsureRoomExists("ICU", "ICU-3", 10);
        }


        private void EnsureRoomExists(string roomType, string roomName, int maxCapacity)
        {
            bool exists = System.Linq.Enumerable.Any(RoomList, r =>
                string.Equals(r.RoomType, roomType, System.StringComparison.OrdinalIgnoreCase) &&
                string.Equals(r.RoomName, roomName, System.StringComparison.OrdinalIgnoreCase));

            if (!exists)
            {
                RoomList.Add(new HospitalRoom
                {
                    RoomType = roomType,
                    RoomName = roomName,
                    MaxCapacity = maxCapacity
                });
            }
        }


        private void RefreshRoomBasedData()
        {
            ClearVisibleData();

            if (SelectedRoom == null)
                return;

            if (SelectedRoom.RoomType == "OT")
            {
                RefreshVisibleScheduledSurgeries();
                RefreshVisibleLogs();
            }
            else if (SelectedRoom.RoomType == "ICU")
            {
                foreach (var patient in SelectedRoom.ICUPatients)
                {
                    VisibleICUPatients.Add(patient);
                }

                OnPropertyChanged(nameof(VisibleICUPatients));
            }
            else if (SelectedRoom.RoomType == "OPD")
            {
                foreach (var patient in SelectedRoom.OPDPatients)
                {
                    VisibleOPDPatients.Add(patient);
                }

                OnPropertyChanged(nameof(VisibleOPDPatients));
            }
        }

        private void ClearVisibleData()
        {
            VisibleScheduledSurgeries.Clear();
            VisibleSurgeryLogs.Clear();
            VisibleICUPatients.Clear();
            VisibleOPDPatients.Clear();

            OnPropertyChanged(nameof(VisibleScheduledSurgeries));
            OnPropertyChanged(nameof(VisibleSurgeryLogs));
            OnPropertyChanged(nameof(VisibleICUPatients));
            OnPropertyChanged(nameof(VisibleOPDPatients));
        }

        private void AddICUPatient()
        {
            if (SelectedRoom == null || SelectedRoom.RoomType != "ICU")
            {
                System.Windows.MessageBox.Show("Please select an ICU room.");
                return;
            }

            if (SelectedRoom.AvailableICUBeds <= 0)
            {
                System.Windows.MessageBox.Show($"This ICU is full. Maximum capacity of {SelectedRoom.MaxCapacity} beds reached.");
                return;
            }

            if (string.IsNullOrWhiteSpace(ICUPatientName))
            {
                System.Windows.MessageBox.Show("Please select patient name.");
                return;
            }

            if (!ICUStartDate.HasValue)
            {
                System.Windows.MessageBox.Show("Please select start date.");
                return;
            }

            if (!ICUEndDate.HasValue)
            {
                System.Windows.MessageBox.Show("Please select end date.");
                return;
            }

            if (ICUEndDate.Value.Date < ICUStartDate.Value.Date)
            {
                System.Windows.MessageBox.Show("End date should be greater than or equal to start date.");
                return;
            }

            var patient = new ICUPatientInfo
            {
                PatientName = ICUPatientName,
                StartDate = ICUStartDate.Value.Date,
                EndDate = ICUEndDate.Value.Date
            };

            SelectedRoom.ICUPatients.Add(patient);
            VisibleICUPatients.Add(patient);

            SaveHospitalRoomConfiguration();
            ClearICUInputs();

            ScheduleStatus = "ICU patient added successfully.";
            StatusService.Publish(
                $"ICU Room Booked: {SelectedRoom.RoomName} for {patient.PatientName} from {patient.StartDate:dd MMM yyyy} to {patient.EndDate:dd MMM yyyy}.");
        }

        private void AddOPDPatient()
        {
            if (SelectedRoom == null || SelectedRoom.RoomType != "OPD")
            {
                System.Windows.MessageBox.Show("Please select an OPD room.");
                return;
            }

            if (SelectedRoom.AvailableOPDSlots <= 0)
            {
                System.Windows.MessageBox.Show($"OPD appointments are full for today. Maximum capacity of {SelectedRoom.MaxCapacity} reached.");
                return;
            }

            if (string.IsNullOrWhiteSpace(OPDPatientName))
            {
                System.Windows.MessageBox.Show("Please select patient name.");
                return;
            }

            if (string.IsNullOrWhiteSpace(OPDPhysicianName))
            {
                System.Windows.MessageBox.Show("Please select physician name.");
                return;
            }

            if (!OPDDate.HasValue)
            {
                System.Windows.MessageBox.Show("Please select date.");
                return;
            }

            if (string.IsNullOrWhiteSpace(OPDTime))
            {
                System.Windows.MessageBox.Show("Please enter time.");
                return;
            }

            if (string.IsNullOrWhiteSpace(OPDReason))
            {
                System.Windows.MessageBox.Show("Please enter reason.");
                return;
            }

            var patient = new OPDPatientInfo
            {
                PatientName = OPDPatientName,
                PhysicianName = OPDPhysicianName,
                Date = OPDDate.Value.Date,
                Time = OPDTime,
                Reason = OPDReason
            };

            SelectedRoom.OPDPatients.Add(patient);
            VisibleOPDPatients.Add(patient);

            SaveHospitalRoomConfiguration();
            ClearOPDInputs();

            ScheduleStatus = "OPD patient added successfully.";
            StatusService.Publish(
                $"OPD Room Booked: {SelectedRoom.RoomName} for {patient.PatientName} with {patient.PhysicianName} on {patient.Date:dd MMM yyyy} at {patient.Time}.");
        }

        private void ClearICUInputs()
        {
            ICUPatientName = string.Empty;
            ICUStartDate = null;
            ICUEndDate = null;
        }

        private void ClearOPDInputs()
        {
            OPDPatientName = string.Empty;
            OPDPhysicianName = string.Empty;
            OPDDate = null;
            OPDTime = string.Empty;
            OPDReason = string.Empty;
        }

        private void LoadDoctors()
        {
            DoctorList.Clear();

            foreach (var surgeonName in App.SurgeonService.Surgeons
                         .Where(s => !string.IsNullOrWhiteSpace(s.Name))
                         .Select(s => s.Name.Trim())
                         .Distinct()
                         .OrderBy(name => name))
            {
                DoctorList.Add(surgeonName);
            }
        }

        private void LoadPatients()
        {
            PatientList.Clear();

            foreach (var patientName in App.PatientService.Patients
                         .Where(p => !string.IsNullOrWhiteSpace(p.Name))
                         .Select(p => p.Name.Trim())
                         .Distinct()
                         .OrderBy(name => name))
            {
                PatientList.Add(patientName);
            }
        }

        private void LoadProcedures()
        {
            ProcedureList.Clear();

            ProcedureList.Add("Appendectomy");
            ProcedureList.Add("Coronary Artery Bypass Grafting");
            ProcedureList.Add("Knee Replacement");
            ProcedureList.Add("Hip Replacement");
            ProcedureList.Add("Cataract Surgery");
            ProcedureList.Add("Cesarean Section");
            ProcedureList.Add("Gallbladder Removal");
            ProcedureList.Add("Hernia Repair");
            ProcedureList.Add("Tonsillectomy");
            ProcedureList.Add("Angioplasty");
            ProcedureList.Add("Spinal Fusion");
            ProcedureList.Add("Laparoscopic Surgery");
        }

        private void LoadTimeOptions()
        {
            HourOptions.Clear();
            MinuteOptions.Clear();

            for (int hour = 0; hour < 24; hour++)
            {
                HourOptions.Add($"{hour:00}");
            }

            for (int minute = 0; minute < 60; minute++)
            {
                MinuteOptions.Add($"{minute:00}");
            }
        }

        private void ScheduleSurgery()
        {
            if (SelectedRoom == null || SelectedRoom.RoomType != "OT")
            {
                MessageBox.Show("Please select an OT room.");
                return;
            }

            if (string.IsNullOrWhiteSpace(SelectedDoctor))
            {
                MessageBox.Show("Please select a primary surgeon.");
                return;
            }

            if (string.IsNullOrWhiteSpace(SelectedPatient))
            {
                MessageBox.Show("Please select a patient.");
                return;
            }

            if (string.IsNullOrWhiteSpace(SelectedProcedure))
            {
                MessageBox.Show("Please select a procedure.");
                return;
            }

            if (!SelectedDate.HasValue)
            {
                MessageBox.Show("Please select surgery date.");
                return;
            }

            if (string.IsNullOrWhiteSpace(SelectedStartHour) ||
                string.IsNullOrWhiteSpace(SelectedStartMinute))
            {
                MessageBox.Show("Please select start hour and minute.");
                return;
            }

            if (string.IsNullOrWhiteSpace(SelectedEndHour) ||
                string.IsNullOrWhiteSpace(SelectedEndMinute))
            {
                MessageBox.Show("Please select end hour and minute.");
                return;
            }

            DateTime startDateTime = BuildDateTime(SelectedDate.Value, SelectedStartHour, SelectedStartMinute);
            DateTime endDateTime = BuildDateTime(SelectedDate.Value, SelectedEndHour, SelectedEndMinute);

            if (endDateTime <= startDateTime)
            {
                MessageBox.Show("End time must be greater than start time.");
                return;
            }

            bool overlaps = _allScheduledSurgeries.Any(s =>
                s.OTName == SelectedOT &&
                !s.IsCompleted &&
                startDateTime < s.EndDateTime &&
                endDateTime > s.StartDateTime);

            if (overlaps)
            {
                MessageBox.Show("This OT already has a surgery scheduled during the selected time.");
                return;
            }

            var surgery = new OTScheduledSurgery
            {
                OTName = SelectedOT,
                SurgeryDate = SelectedDate.Value.Date,
                StartDateTime = startDateTime,
                EndDateTime = endDateTime,
                PrimarySurgeonName = SelectedDoctor,
                PatientName = SelectedPatient,
                ProcedureName = SelectedProcedure,
                IsCompleted = false
            };

            _allScheduledSurgeries.Add(surgery);
            SelectedRoom.OTSurgeries.Add(surgery);

            SaveHospitalRoomConfiguration();

            RefreshVisibleScheduledSurgeries();

            SelectedScheduledSurgery = surgery;

            ScheduleStatus = "Surgery scheduled successfully. Select the scheduled row to document during surgery time.";

            StatusService.Publish(
                $"OT Booked: {surgery.OTName} for {surgery.PatientName} with {surgery.PrimarySurgeonName} on {surgery.StartDateTime:dd MMM yyyy, hh:mm tt}.");

            KeepSchedulerInputsForNextSchedule();
        }

        private void EndSurgery()
        {
            CompleteSelectedSurgery();
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (SelectedRoom?.RoomType != "OT")
                return;

            RefreshVisibleScheduledSurgeries();

            var surgery = SelectedScheduledSurgery;

            if (surgery == null)
            {
                IsSurgeryActive = false;
                return;
            }

            UpdateSurgeryActiveState();

            if (!surgery.IsCompleted && DateTime.Now > surgery.EndDateTime)
            {
                CompleteSelectedSurgery();
            }
        }

        private void UpdateSurgeryActiveState()
        {
            if (SelectedRoom?.RoomType != "OT")
            {
                IsSurgeryActive = false;
                return;
            }

            if (SelectedScheduledSurgery == null)
            {
                IsSurgeryActive = false;
                ScheduleStatus = string.IsNullOrWhiteSpace(SelectedOT)
                    ? "Please select an OT."
                    : $"Selected {SelectedOT}. Please schedule surgery.";
                return;
            }

            if (SelectedScheduledSurgery.IsCompleted)
            {
                IsSurgeryActive = false;
                ScheduleStatus = "Selected surgery is already completed.";
                return;
            }

            DateTime now = DateTime.Now;

            if (now < SelectedScheduledSurgery.StartDateTime)
            {
                IsSurgeryActive = false;
                ScheduleStatus =
                    $"Surgery scheduled for {SelectedScheduledSurgery.StartDateTime:dd/MM/yyyy HH:mm}. Documentation will be enabled at start time.";
                return;
            }

            if (now >= SelectedScheduledSurgery.StartDateTime &&
                now <= SelectedScheduledSurgery.EndDateTime)
            {
                IsSurgeryActive = true;
                ScheduleStatus = "Surgery is active. Documentation is enabled.";
                return;
            }

            IsSurgeryActive = false;
            ScheduleStatus = "Surgery time is completed. Documentation is disabled.";
        }

        private void CompleteSelectedSurgery()
        {
            var surgery = SelectedScheduledSurgery;

            if (surgery == null)
            {
                MessageBox.Show("Please select a scheduled surgery.");
                return;
            }

            if (surgery.IsCompleted)
                return;

            if (DateTime.Now < surgery.StartDateTime)
            {
                MessageBox.Show("Surgery has not started yet.");
                return;
            }

            TimeSpan duration = surgery.EndDateTime - surgery.StartDateTime;

            var saveDialog = new SaveFileDialog
            {
                Title = "Save Surgery Document",
                FileName = $"{surgery.OTName}_{surgery.PatientName}_{surgery.ProcedureName}_SurgeryDocument",
                DefaultExt = ".txt",
                Filter = "Text File (*.txt)|*.txt"
            };

            if (saveDialog.ShowDialog() == true)
            {
                string documentation = string.IsNullOrWhiteSpace(SurgeryDocument)
                    ? "(No documentation entered.)"
                    : SurgeryDocument;

                string fileContent =
$@"Surgery Documentation
----------------------
OT: {surgery.OTName}
Date: {surgery.SurgeryDate:dd/MM/yyyy}
Start Time: {surgery.StartDateTime:HH:mm}
End Time: {surgery.EndDateTime:HH:mm}
Duration: {duration.Hours}h {duration.Minutes}m
Primary Surgeon: {surgery.PrimarySurgeonName}
Patient: {surgery.PatientName}
Procedure: {surgery.ProcedureName}

Documentation:
{documentation}";

                File.WriteAllText(saveDialog.FileName, fileContent);

                surgery.IsCompleted = true;

                SaveHospitalRoomConfiguration();

                // NEW: this now actually persists to Data/SurgicalLogs.xml
                // via the service (see SurgicalDocRepository) - the old
                // code only kept this in an in-memory list, so completed
                // surgery logs used to disappear on every app restart.
                _roomSchedulingService.AddSurgicalLog(new SurgicalLog
                {
                    OTName = surgery.OTName,
                    SurgeryDate = surgery.SurgeryDate,
                    Duration = $"{duration.Hours}h {duration.Minutes}m",
                    PrimarySurgeonName = surgery.PrimarySurgeonName,
                    PatientName = surgery.PatientName,
                    ProcedureName = surgery.ProcedureName,
                    DocumentName = Path.GetFileName(saveDialog.FileName)
                });

                SurgeryDocument = string.Empty;
                IsSurgeryActive = false;
                SelectedScheduledSurgery = null;

                RefreshVisibleScheduledSurgeries();
                RefreshVisibleLogs();

                ScheduleStatus = "Surgery completed and document saved.";

                StatusService.Publish(
                    $"OT Released: {surgery.OTName} surgery for {surgery.PatientName} has been completed.");

                MessageBox.Show("Surgery document saved successfully.");
            }
        }

        private DateTime BuildDateTime(DateTime date, string hourText, string minuteText)
        {
            int hour = int.Parse(hourText);
            int minute = int.Parse(minuteText);

            return date.Date.AddHours(hour).AddMinutes(minute);
        }

        private void RefreshVisibleScheduledSurgeries()
        {
            if (SelectedRoom?.RoomType != "OT")
                return;

            var previouslySelectedSurgery = SelectedScheduledSurgery;

            _isRefreshingScheduledSurgeries = true;

            VisibleScheduledSurgeries.Clear();

            foreach (var surgery in _allScheduledSurgeries
                         .Where(s => string.Equals(s.OTName, SelectedOT, StringComparison.OrdinalIgnoreCase))
                         .OrderBy(s => s.StartDateTime))
            {
                VisibleScheduledSurgeries.Add(surgery);
            }

            _isRefreshingScheduledSurgeries = false;

            if (previouslySelectedSurgery != null &&
                VisibleScheduledSurgeries.Contains(previouslySelectedSurgery))
            {
                SelectedScheduledSurgery = previouslySelectedSurgery;
            }

            OnPropertyChanged(nameof(VisibleScheduledSurgeries));
        }

        private void RefreshVisibleLogs()
        {
            if (SelectedRoom?.RoomType != "OT")
                return;

            VisibleSurgeryLogs.Clear();

            foreach (var log in _roomSchedulingService.SurgicalLogs
                         .Where(l => string.Equals(l.OTName, SelectedOT, StringComparison.OrdinalIgnoreCase))
                         .OrderByDescending(l => l.SurgeryDate))
            {
                VisibleSurgeryLogs.Add(log);
            }

            OnPropertyChanged(nameof(VisibleSurgeryLogs));
        }

        private void KeepSchedulerInputsForNextSchedule()
        {
            OnPropertyChanged(nameof(SelectedDoctor));
            OnPropertyChanged(nameof(SelectedPatient));
            OnPropertyChanged(nameof(SelectedProcedure));
            OnPropertyChanged(nameof(SelectedDate));
            OnPropertyChanged(nameof(SelectedStartHour));
            OnPropertyChanged(nameof(SelectedStartMinute));
            OnPropertyChanged(nameof(SelectedEndHour));
            OnPropertyChanged(nameof(SelectedEndMinute));
        }

        private void NotifyVisibilityProperties()
        {
            OnPropertyChanged(nameof(OTMenuVisibility));
            OnPropertyChanged(nameof(ICUMenuVisibility));
            OnPropertyChanged(nameof(OPDMenuVisibility));
            OnPropertyChanged(nameof(OTSurgeryGridVisibility));
            OnPropertyChanged(nameof(ICUPatientGridVisibility));
            OnPropertyChanged(nameof(OPDPatientGridVisibility));
            OnPropertyChanged(nameof(SurgeryDocumentationVisibility));
            OnPropertyChanged(nameof(SurgeryLogsVisibility));
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(
                this,
                new System.ComponentModel.PropertyChangedEventArgs(propertyName));
        }
    }
}

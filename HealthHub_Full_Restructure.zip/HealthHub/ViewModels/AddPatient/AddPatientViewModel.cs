using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Input;
using HealthHub.Domain.Entities;
using HealthHub.Infrastructure;

namespace HealthHub.ViewModels.AddPatient
{
    public class AddPatientViewModel : INotifyPropertyChanged
    {
        private readonly ObservableCollection<Patient> _patients;
        private readonly Action _closeWindow;

        private string _patientName = string.Empty;
        private DateTime? _dob;
        private string _gender = "I Prefer Not To Say";
        private string _email = string.Empty;
        private string _phoneNo = string.Empty;
        private string _address = string.Empty;

        private string _patientNameError = string.Empty;
        private string _dobError = string.Empty;
        private string _genderError = string.Empty;
        private string _emailError = string.Empty;
        private string _phoneNoError = string.Empty;
        private string _addressError = string.Empty;

        public event PropertyChangedEventHandler? PropertyChanged;

        public ObservableCollection<string> GenderOptions { get; }

        public ICommand AddPatientCommand { get; }
        public ICommand CancelCommand { get; }

        public AddPatientViewModel(ObservableCollection<Patient> patients, Action closeWindow)
        {
            _patients = patients ?? throw new ArgumentNullException(nameof(patients));
            _closeWindow = closeWindow ?? throw new ArgumentNullException(nameof(closeWindow));

            GenderOptions = new ObservableCollection<string>
            {
                "Male",
                "Female",
                "I Prefer Not To Say"
            };

            AddPatientCommand = new RelayCommand(AddPatient);
            CancelCommand = new RelayCommand(Cancel);
        }

        public string PatientName
        {
            get => _patientName;
            set
            {
                SetProperty(ref _patientName, value);
                ValidatePatientName();
            }
        }

        public DateTime? DOB
        {
            get => _dob;
            set
            {
                SetProperty(ref _dob, value);
                ValidateDOB();
            }
        }

        public string Gender
        {
            get => _gender;
            set
            {
                SetProperty(ref _gender, value);
                ValidateGender();
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                SetProperty(ref _email, value);
                ValidateEmail();
            }
        }

        public string PhoneNo
        {
            get => _phoneNo;
            set
            {
                SetProperty(ref _phoneNo, value);
                ValidatePhone();
            }
        }

        public string Address
        {
            get => _address;
            set
            {
                SetProperty(ref _address, value);
                ValidateAddress();
            }
        }

        public string PatientNameError
        {
            get => _patientNameError;
            private set => SetProperty(ref _patientNameError, value);
        }

        public string DOBError
        {
            get => _dobError;
            private set => SetProperty(ref _dobError, value);
        }

        public string GenderError
        {
            get => _genderError;
            private set => SetProperty(ref _genderError, value);
        }

        public string EmailError
        {
            get => _emailError;
            private set => SetProperty(ref _emailError, value);
        }

        public string PhoneNoError
        {
            get => _phoneNoError;
            private set => SetProperty(ref _phoneNoError, value);
        }

        public string AddressError
        {
            get => _addressError;
            private set => SetProperty(ref _addressError, value);
        }

        private void AddPatient()
        {
            ValidateAll();

            if (HasAnyError())
                return;

            var newPatient = new Patient
            {
                PatientId = GenerateNextPatientId(),
                Name = PatientName.Trim(),
                DOB = DOB!.Value,
                Gender = Gender,
                Email = Email.Trim(),
                PhoneNo = PhoneNo.Trim(),
                Address = Address.Trim()
            };

            _patients.Add(newPatient);
            _closeWindow();
        }

        private string GenerateNextPatientId()
        {
            int maxId = _patients
                .Where(p => !string.IsNullOrWhiteSpace(p.PatientId) &&
                            p.PatientId.StartsWith("P", StringComparison.OrdinalIgnoreCase))
                .Select(p =>
                {
                    string numericPart = p.PatientId.Substring(1);
                    return int.TryParse(numericPart, out int id) ? id : 0;
                })
                .DefaultIfEmpty(0)
                .Max();

            return $"P{maxId + 1}";
        }

        private void Cancel()
        {
            ClearForm();
            _closeWindow();
        }

        private void ClearForm()
        {
            PatientName = string.Empty;
            DOB = null;
            Gender = "I Prefer Not To Say";
            Email = string.Empty;
            PhoneNo = string.Empty;
            Address = string.Empty;

            ClearErrors();
        }

        private void ValidateAll()
        {
            ValidatePatientName();
            ValidateDOB();
            ValidateGender();
            ValidateEmail();
            ValidatePhone();
            ValidateAddress();
        }

        private bool HasAnyError()
        {
            return !string.IsNullOrWhiteSpace(PatientNameError)
                || !string.IsNullOrWhiteSpace(DOBError)
                || !string.IsNullOrWhiteSpace(GenderError)
                || !string.IsNullOrWhiteSpace(EmailError)
                || !string.IsNullOrWhiteSpace(PhoneNoError)
                || !string.IsNullOrWhiteSpace(AddressError);
        }

        private void ClearErrors()
        {
            PatientNameError = string.Empty;
            DOBError = string.Empty;
            GenderError = string.Empty;
            EmailError = string.Empty;
            PhoneNoError = string.Empty;
            AddressError = string.Empty;
        }

        private void ValidatePatientName()
        {
            if (string.IsNullOrWhiteSpace(PatientName))
            {
                PatientNameError = "Patient Name is required.";
                return;
            }

            if (PatientName.Trim().Length > 20)
            {
                PatientNameError = "Patient Name cannot be more than 20 characters.";
                return;
            }

            PatientNameError = string.Empty;
        }

        private void ValidateDOB()
        {
            if (!DOB.HasValue)
            {
                DOBError = "Date of Birth is required.";
                return;
            }

            if (DOB.Value.Date > DateTime.Today)
            {
                DOBError = "Date of Birth cannot be greater than today's date.";
                return;
            }

            DOBError = string.Empty;
        }

        private void ValidateGender()
        {
            GenderError = string.Empty;
        }

        private void ValidateEmail()
        {
            if (string.IsNullOrWhiteSpace(Email))
            {
                EmailError = "Email is required.";
                return;
            }

            var email = Email.Trim();
            bool ok = Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$");

            EmailError = ok
                ? string.Empty
                : "Email must contain '@' and a valid domain (example: name@domain.com).";
        }

        private void ValidatePhone()
        {
            if (string.IsNullOrWhiteSpace(PhoneNo))
            {
                PhoneNoError = "Phone Number is required.";
                return;
            }

            var phone = PhoneNo.Trim();
            bool ok = Regex.IsMatch(phone, @"^\d{10}$|^\+\d{1,3}\d{9,10}$");

            PhoneNoError = ok
                ? string.Empty
                : "Enter a valid phone number (10 digits or +<countrycode><number>).";
        }

        private void ValidateAddress()
        {
            if (string.IsNullOrWhiteSpace(Address))
            {
                AddressError = "Address is required.";
                return;
            }

            if (Address.Trim().Length > 200)
            {
                AddressError = "Address cannot be more than 200 characters.";
                return;
            }

            AddressError = string.Empty;
        }

        protected void SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = "")
        {
            if (!Equals(field, value))
            {
                field = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}

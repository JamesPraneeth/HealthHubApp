using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using HealthHub.App.Services.SurgeonManagement;
using HealthHub.App.Views.AddSurgeon;
using HealthHub.Domain.Entities;
using HealthHub.Infrastructure;
using HealthHub.ViewModels.AddSurgeon;

namespace HealthHub.ViewModels.SurgeonSearchBar
{
    public class SurgeonSearchBarViewModel : INotifyPropertyChanged
    {
        private readonly SurgeonService _store;

        public ObservableCollection<string> SearchByOptions { get; } =
            new ObservableCollection<string>
            {
                "Name",
                "Surgeon ID",
                "Specialization"
            };

        public ObservableCollection<string> FilterByOptions { get; } =
            new ObservableCollection<string>
            {
                "None",
                "Availability",
                "Department"
            };

        public ObservableCollection<string> FilterValueOptions { get; private set; } =
            new ObservableCollection<string> { "All" };

        public ICommand OpenAddSurgeonCommand { get; }
        public ICommand ClearFilterCommand { get; }

        public event PropertyChangedEventHandler? PropertyChanged;

        public int TotalSurgeons => _store.Surgeons.Count;

        public int AvailableSurgeons =>
            _store.Surgeons.Count(s => s.Availability == "Available");

        public int BusySurgeons =>
            _store.Surgeons.Count(s => s.Availability == "Busy");

        public int OnLeaveSurgeons =>
            _store.Surgeons.Count(s => s.Availability == "On Leave");

        public string SelectedSearchBy
        {
            get => _store.SelectedSearchBy;
            set
            {
                if (_store.SelectedSearchBy != value)
                {
                    _store.SelectedSearchBy = value;
                    OnPropertyChanged();
                }
            }
        }

        public string SearchText
        {
            get => _store.SearchText;
            set
            {
                if (_store.SearchText != value)
                {
                    _store.SearchText = value;
                    OnPropertyChanged();
                }
            }
        }

        public string SelectedFilterBy
        {
            get => _store.SelectedFilterBy;
            set
            {
                if (_store.SelectedFilterBy != value)
                {
                    _store.SelectedFilterBy = value;

                    UpdateFilterValues();

                    _store.SelectedFilterValue = "All";

                    OnPropertyChanged();
                    OnPropertyChanged(nameof(SelectedFilterValue));
                }
            }
        }

        public string SelectedFilterValue
        {
            get => _store.SelectedFilterValue;
            set
            {
                if (_store.SelectedFilterValue != value)
                {
                    _store.SelectedFilterValue = value;
                    OnPropertyChanged();
                }
            }
        }

        public SurgeonSearchBarViewModel()
        {
            _store = App.SurgeonService;

            OpenAddSurgeonCommand = new RelayCommand(OpenAddSurgeon);
            ClearFilterCommand = new RelayCommand(ClearFilter);

            _store.Surgeons.CollectionChanged += Surgeons_CollectionChanged;

            foreach (var surgeon in _store.Surgeons)
            {
                surgeon.PropertyChanged += Surgeon_PropertyChanged;
            }

            UpdateFilterValues();
            RefreshSummaryCounts();
        }

        private void Surgeons_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null)
            {
                foreach (Surgeon surgeon in e.OldItems)
                {
                    surgeon.PropertyChanged -= Surgeon_PropertyChanged;
                }
            }

            if (e.NewItems != null)
            {
                foreach (Surgeon surgeon in e.NewItems)
                {
                    surgeon.PropertyChanged += Surgeon_PropertyChanged;
                }
            }

            UpdateFilterValues();
            RefreshSummaryCounts();
        }

        private void Surgeon_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Surgeon.Availability) ||
                e.PropertyName == nameof(Surgeon.Department))
            {
                UpdateFilterValues();
                RefreshSummaryCounts();
            }
        }

        private void OpenAddSurgeon()
        {
            var viewModel = new AddSurgeonViewModel();

            var view = new AddSurgeonView
            {
                DataContext = viewModel
            };

            var window = new Window
            {
                Title = "Add Surgeon",
                Content = view,
                Width = 520,
                Height = 560,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                ResizeMode = ResizeMode.NoResize,
                Owner = Application.Current.MainWindow
            };

            viewModel.CloseAction = () => window.Close();

            window.ShowDialog();

            UpdateFilterValues();
            RefreshSummaryCounts();
        }

        private void ClearFilter()
        {
            _store.ClearFilters();

            UpdateFilterValues();

            OnPropertyChanged(nameof(SearchText));
            OnPropertyChanged(nameof(SelectedSearchBy));
            OnPropertyChanged(nameof(SelectedFilterBy));
            OnPropertyChanged(nameof(SelectedFilterValue));
            OnPropertyChanged(nameof(FilterValueOptions));
        }

        private void UpdateFilterValues()
        {
            FilterValueOptions.Clear();
            FilterValueOptions.Add("All");

            if (SelectedFilterBy == "Availability")
            {
                var availabilityOptions = _store.Surgeons
                    .Select(s => s.Availability)
                    .Where(a => !string.IsNullOrWhiteSpace(a))
                    .Distinct()
                    .OrderBy(a => a);

                foreach (var availability in availabilityOptions)
                {
                    FilterValueOptions.Add(availability);
                }
            }
            else if (SelectedFilterBy == "Department")
            {
                var departmentOptions = _store.Surgeons
                    .Select(s => s.Department)
                    .Where(d => !string.IsNullOrWhiteSpace(d))
                    .Distinct()
                    .OrderBy(d => d);

                foreach (var department in departmentOptions)
                {
                    FilterValueOptions.Add(department);
                }
            }

            OnPropertyChanged(nameof(FilterValueOptions));
        }

        private void RefreshSummaryCounts()
        {
            OnPropertyChanged(nameof(TotalSurgeons));
            OnPropertyChanged(nameof(AvailableSurgeons));
            OnPropertyChanged(nameof(BusySurgeons));
            OnPropertyChanged(nameof(OnLeaveSurgeons));
        }

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}

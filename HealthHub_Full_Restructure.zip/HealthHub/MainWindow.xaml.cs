using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HealthHub.App.Views.About;
using HealthHub.App.Views.Home;
using HealthHub.App.Views.Login;
using HealthHub.App.Views.Navigation;
using HealthHub.App.Views.OT;
using HealthHub.App.Views.PatientDetails;
using HealthHub.App.Views.SearchBar;
using HealthHub.App.Views.SurgeonDetails;
using HealthHub.App.Views.SurgeonSearchBar;
using HealthHub.ViewModels.Home;
using HealthHub.ViewModels.Navigation;
using HealthHub.ViewModels.OT;
using HealthHub.ViewModels.PatientDetails;
using HealthHub.ViewModels.SearchBar;
using HealthHub.ViewModels.SurgeonDetails;
using HealthHub.ViewModels.SurgeonSearchBar;

namespace HealthHub
{
    public partial class MainWindow : Window
    {
        public static MainWindow Instance { get; private set; } = null!;

        private SideNavViewModel? _navVM;

        private HomeView? _homeView;
        private AboutView? _aboutView;
        private OTView? _otView;

        private Grid? _patientPage;
        private Grid? _surgeonPage;
        

        private bool _appLoaded;

        public MainWindow()
        {
            InitializeComponent();

            Instance = this;

            // Wire AppShell delegates so Views can navigate without
            // directly referencing MainWindow (which would be a circular
            // project reference). See AppShell.cs for explanation.
            HealthHub.App.Views.AppShell.ShowLogin = LoadLoginScreen;
            HealthHub.App.Views.AppShell.ShowApplication = LoadApplicationAfterLogin;
            HealthHub.App.Views.AppShell.Navigate = Navigate;
            HealthHub.App.Views.AppShell.ValidateUser = (uid, pw) => App.AuthService.ValidateUser(uid, pw);
            HealthHub.App.Views.AppShell.RegisterUser = (uid, pw) => App.AuthService.RegisterUser(uid, pw);

            LoadLoginScreen();
        }

        public void LoadLoginScreen()
        {
            ShowLoginShell();

            MainContent.Content = new LoginView();
        }

        public void Navigate(UserControl view)
        {
            MainContent.Content = view;
        }

        private void ShowLoginShell()
        {
            Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E6F91"));
            RootLayout.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E6F91"));

            HeaderControl.Visibility = Visibility.Collapsed;
            SideNav.Visibility = Visibility.Collapsed;

            RootLayout.RowDefinitions[0].Height = new GridLength(0);
            RootLayout.ColumnDefinitions[0].Width = new GridLength(0);

            Grid.SetRow(MainContent, 0);
            Grid.SetColumn(MainContent, 0);
            Grid.SetRowSpan(MainContent, 2);
            Grid.SetColumnSpan(MainContent, 2);
        }

        private void ShowApplicationShell()
        {
            Background = Brushes.White;
            RootLayout.Background = Brushes.White;

            HeaderControl.Visibility = Visibility.Visible;
            SideNav.Visibility = Visibility.Visible;

            RootLayout.RowDefinitions[0].Height = new GridLength(90);
            RootLayout.ColumnDefinitions[0].Width = GridLength.Auto;

            Grid.SetRow(MainContent, 1);
            Grid.SetColumn(MainContent, 1);
            Grid.SetRowSpan(MainContent, 1);
            Grid.SetColumnSpan(MainContent, 1);
        }

        public void LoadApplicationAfterLogin()
        {
            if (!_appLoaded)
            {
                _navVM = new SideNavViewModel();

                // Use same ViewModel instance for Header and SideNav
                HeaderControl.DataContext = _navVM;
                SideNav.DataContext = _navVM;

                // NOTE: these Views used to build their own ViewModel
                // internally (DataContext = new XyzViewModel(...) inside
                // the View's own constructor). That's no longer possible
                // now that Views (HealthHub.App.Views) and ViewModels
                // (HealthHub) live in separate projects - a View can't
                // reference the ViewModels project without creating a
                // circular project reference. So construction + DataContext
                // wiring for these happens here instead. See README.
                _homeView = new HomeView
                {
                    DataContext = new HomeViewModel(App.SurgeonService, App.RoomSchedulingService)
                };

                _aboutView = new AboutView();

                _otView = new OTView
                {
                    DataContext = new OTViewModel()
                };

                CreatePatientPage();
                CreateSurgeonPage();

                _navVM.ShowHome = () =>
                {
                    MainContent.Content = _homeView;
                };

                _navVM.ShowPatient = () =>
                {
                    MainContent.Content = _patientPage;
                };

                _navVM.ShowSurgeon = () =>
                {
                    MainContent.Content = _surgeonPage;
                };

                _navVM.ShowAbout = () =>
                {
                    MainContent.Content = _aboutView;
                };

                _navVM.ShowOT = () =>
                {
                    MainContent.Content = _otView;
                };

                _appLoaded = true;
            }

            ShowApplicationShell();

            // Default page after login
            MainContent.Content = _homeView;
        }

        private void CreatePatientPage()
        {
            _patientPage = new Grid();

            _patientPage.RowDefinitions.Add(new RowDefinition
            {
                Height = GridLength.Auto
            });

            _patientPage.RowDefinitions.Add(new RowDefinition
            {
                Height = new GridLength(1, GridUnitType.Star)
            });

            var searchBar = new SearchBarView
            {
                DataContext = new SearchBarViewModel()
            };

            var patientDetails = new PatientDetailsView
            {
                DataContext = new PatientDetailsViewModel(App.PatientService)
            };

            Grid.SetRow(searchBar, 0);
            Grid.SetRow(patientDetails, 1);

            _patientPage.Children.Add(searchBar);
            _patientPage.Children.Add(patientDetails);
        }

        private void CreateSurgeonPage()
        {
            _surgeonPage = new Grid();

            _surgeonPage.RowDefinitions.Add(new RowDefinition
            {
                Height = GridLength.Auto
            });

            _surgeonPage.RowDefinitions.Add(new RowDefinition
            {
                Height = new GridLength(1, GridUnitType.Star)
            });

            var surgeonSearch = new SurgeonSearchBarView
            {
                DataContext = new SurgeonSearchBarViewModel()
            };

            var surgeonDetails = new SurgeonDetailsView
            {
                DataContext = new SurgeonDetailsViewModel(App.SurgeonService)
            };

            Grid.SetRow(surgeonSearch, 0);
            Grid.SetRow(surgeonDetails, 1);

            _surgeonPage.Children.Add(surgeonSearch);
            _surgeonPage.Children.Add(surgeonDetails);
        }
    }
}

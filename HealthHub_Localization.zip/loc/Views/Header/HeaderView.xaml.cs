using System.Windows;
using System.Windows.Controls;
using HealthHub.App.Views.Localization;

namespace HealthHub.App.Views.Header
{
    public partial class HeaderView : UserControl
    {
        public HeaderView() { InitializeComponent(); }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show(
                LocalizationService.GetText("LogoutConfirm"),
                LocalizationService.GetText("Logout"),
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
                AppShell.ShowLogin?.Invoke();
        }
    }
}

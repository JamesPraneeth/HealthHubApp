using HealthHub.App.Services.Implementations;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;
using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Windows.Media;
using System.Windows.Threading;

namespace HealthHub.App.Views.ViewModels.Home
{
    public class HomeViewModel : INotifyPropertyChanged
    {
        private readonly ISurgeonMgmtService _surgeonService;
        private readonly IAppointmentBookingService _roomSchedulingService;
        private readonly DispatcherTimer _roomStatsTimer;

        public ObservableCollection<PieSliceViewModel> PieSlices { get; } =
            new ObservableCollection<PieSliceViewModel>();

        public ObservableCollection<LiveRoomStatusItem> LiveRoomStatuses { get; } =
            new ObservableCollection<LiveRoomStatusItem>();

        public ObservableCollection<string> RecentActivities { get; } =
            new ObservableCollection<string>();


        public ObservableCollection<string> CaseChartFilters { get; } =
            new ObservableCollection<string>
            {
                "Today",
                "Current Week",
                "Previous Week",
                "Current Month",
                "All Upcoming"
            };

        public ObservableCollection<CaseChartPoint> CaseChartPoints { get; } =
            new ObservableCollection<CaseChartPoint>();

        public class ICURoomStat : System.ComponentModel.INotifyPropertyChanged
        {
            private string _roomName = string.Empty;
            private int _total;
            private int _available;

            public string RoomName
            {
                get => _roomName;
                set { _roomName = value; PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(nameof(RoomName))); }
            }
            public int Total
            {
                get => _total;
                set { _total = value; PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(nameof(Total))); }
            }
            public int Available
            {
                get => _available;
                set { _available = value; PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(nameof(Available))); }
            }

            public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
        }


        private string _selectedCaseChartFilter = "Current Week";
        public string SelectedCaseChartFilter
        {
            get => _selectedCaseChartFilter;
            set
            {
                if (_selectedCaseChartFilter != value)
                {
                    _selectedCaseChartFilter = value;
                    OnPropertyChanged(nameof(SelectedCaseChartFilter));
                    LoadCasesLineChart();
                }
            }
        }

        private System.Windows.Media.PointCollection _caseLinePoints = new System.Windows.Media.PointCollection();
        public System.Windows.Media.PointCollection CaseLinePoints
        {
            get => _caseLinePoints;
            set
            {
                _caseLinePoints = value;
                OnPropertyChanged(nameof(CaseLinePoints));
            }
        }

        private string _totalCasesBookedText = "Total cases booked: 0";
        public string TotalCasesBookedText
        {
            get => _totalCasesBookedText;
            set
            {
                if (_totalCasesBookedText != value)
                {
                    _totalCasesBookedText = value;
                    OnPropertyChanged(nameof(TotalCasesBookedText));
                }
            }
        }

        private string _latestActivityMessage = "No recent activity";
        public string LatestActivityMessage
        {
            get => _latestActivityMessage;
            set
            {
                if (_latestActivityMessage != value)
                {
                    _latestActivityMessage = value;
                    OnPropertyChanged(nameof(LatestActivityMessage));
                }
            }
        }

        private string _latestActivityTime = string.Empty;
        public string LatestActivityTime
        {
            get => _latestActivityTime;
            set
            {
                if (_latestActivityTime != value)
                {
                    _latestActivityTime = value;
                    OnPropertyChanged(nameof(LatestActivityTime));
                }
            }
        }

        public int TotalSurgeons => _surgeonService.Surgeons.Count;

        public int TotalPhysicians => _surgeonService.Surgeons.Count;

        public int AvailablePhysicians =>
            _surgeonService.Surgeons.Count(s => s.Availability == "Available");

        public ObservableCollection<ICURoomStat> ICUStats { get; } = new ObservableCollection<ICURoomStat>();

        private int _totalOPDRooms;
        public int TotalOPDRooms
        {
            get => _totalOPDRooms;
            set
            {
                if (_totalOPDRooms != value)
                {
                    _totalOPDRooms = value;
                    OnPropertyChanged(nameof(TotalOPDRooms));
                }
            }
        }

        private int _availableOPDRooms;
        public int AvailableOPDRooms
        {
            get => _availableOPDRooms;
            set
            {
                if (_availableOPDRooms != value)
                {
                    _availableOPDRooms = value;
                    OnPropertyChanged(nameof(AvailableOPDRooms));
                }
            }
        }

        private int _totalOTRooms;
        public int TotalOTRooms
        {
            get => _totalOTRooms;
            set
            {
                if (_totalOTRooms != value)
                {
                    _totalOTRooms = value;
                    OnPropertyChanged(nameof(TotalOTRooms));
                }
            }
        }

        private int _availableOTRooms;
        public int AvailableOTRooms
        {
            get => _availableOTRooms;
            set
            {
                if (_availableOTRooms != value)
                {
                    _availableOTRooms = value;
                    OnPropertyChanged(nameof(AvailableOTRooms));
                }
            }
        }

        private int _availableSurgeons;
        public int AvailableSurgeons
        {
            get => _availableSurgeons;
            set
            {
                if (_availableSurgeons != value)
                {
                    _availableSurgeons = value;
                    OnPropertyChanged(nameof(AvailableSurgeons));
                }
            }
        }

        private int _busySurgeons;
        public int BusySurgeons
        {
            get => _busySurgeons;
            set
            {
                if (_busySurgeons != value)
                {
                    _busySurgeons = value;
                    OnPropertyChanged(nameof(BusySurgeons));
                }
            }
        }

        private int _onLeaveSurgeons;
        public int OnLeaveSurgeons
        {
            get => _onLeaveSurgeons;
            set
            {
                if (_onLeaveSurgeons != value)
                {
                    _onLeaveSurgeons = value;
                    OnPropertyChanged(nameof(OnLeaveSurgeons));
                }
            }
        }

        // Case count properties for display below the Cases Booked graph
        private int _otCaseCount;
        public int OTCaseCount
        {
            get => _otCaseCount;
            set { if (_otCaseCount != value) { _otCaseCount = value; OnPropertyChanged(nameof(OTCaseCount)); } }
        }

        private int _icuCaseCount;
        public int ICUCaseCount
        {
            get => _icuCaseCount;
            set { if (_icuCaseCount != value) { _icuCaseCount = value; OnPropertyChanged(nameof(ICUCaseCount)); } }
        }

        private int _opdCaseCount;
        public int OPDCaseCount
        {
            get => _opdCaseCount;
            set { if (_opdCaseCount != value) { _opdCaseCount = value; OnPropertyChanged(nameof(OPDCaseCount)); } }
        }
        // The old HomeViewModel(ISurgeonMgmtService) reached straight into the
        // static XmlDatabaseManager.Database.RoomConfiguration for OT/ICU/OPD
        // stats; that global static is gone, so the shared room service is
        // passed in explicitly instead. Update HomeView.xaml.cs's
        // constructor call accordingly (see README).
        public HomeViewModel(ISurgeonMgmtService surgeonService, IAppointmentBookingService roomSchedulingService)
        {
            _surgeonService = surgeonService ?? throw new ArgumentNullException(nameof(surgeonService));
            _roomSchedulingService = roomSchedulingService ?? throw new ArgumentNullException(nameof(roomSchedulingService));

            foreach (var surgeon in _surgeonService.Surgeons)
            {
                surgeon.PropertyChanged += Surgeon_PropertyChanged;
            }

            _surgeonService.Surgeons.CollectionChanged += Surgeons_CollectionChanged;

            HealthHub.App.Services.Implementations.StatusService.StatusChanged += OnStatusChanged;

            RefreshChart();
            LoadRoomStatistics();
            LoadLiveStatusGrid();
            LoadCasesLineChart();

            _roomStatsTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(3)
            };

            _roomStatsTimer.Tick += (s, e) =>
            {
                LoadRoomStatistics();
                LoadLiveStatusGrid();
                LoadCasesLineChart();
            };

            _roomStatsTimer.Start();
        }

        private void OnStatusChanged(string message)
        {
            LatestActivityMessage = message;
            LatestActivityTime = DateTime.Now.ToString("dd MMM yyyy, hh:mm tt");

            string activity = $"{LatestActivityTime} - {message}";

            RecentActivities.Insert(0, activity);

            if (RecentActivities.Count > 5)
            {
                RecentActivities.RemoveAt(RecentActivities.Count - 1);
            }

            LoadRoomStatistics();
            LoadLiveStatusGrid();
            LoadCasesLineChart();
        }

        private void LoadRoomStatistics()
        {
            var rooms = _roomSchedulingService.Rooms;
            DateTime now = DateTime.Now;

            TotalOPDRooms = rooms.Where(r => r.RoomType == "OPD").Sum(r => r.MaxCapacity);
            TotalOTRooms  = rooms.Count(r => r.RoomType == "OT");

            int bookedOPD  = rooms.Where(r => r.RoomType == "OPD")
                .Sum(r => r.OPDPatients.Count(p => p.Date.Date == now.Date));
            int occupiedOT = rooms.Where(r => r.RoomType == "OT")
                .Count(r => r.OTSurgeries.Any(s => !s.IsCompleted && s.EndDateTime >= now));

            AvailableOPDRooms = Math.Max(0, TotalOPDRooms - bookedOPD);
            AvailableOTRooms  = Math.Max(0, TotalOTRooms - occupiedOT);

            // Fix ICU card flickering: update existing stats in-place, only add/remove as needed
            var icuRooms = rooms
                .Where(r => string.Equals(r.RoomType, "ICU", StringComparison.OrdinalIgnoreCase))
                .OrderBy(r => r.RoomName)
                .ToList();

            // Remove stats for rooms that no longer exist
            for (int i = ICUStats.Count - 1; i >= 0; i--)
                if (!icuRooms.Any(r => r.RoomName == ICUStats[i].RoomName))
                    ICUStats.RemoveAt(i);

            foreach (var room in icuRooms)
            {
                int occupied = room.ICUPatients.Count(p => now.Date >= p.StartDate.Date && now.Date <= p.EndDate.Date);
                int available = Math.Max(0, room.MaxCapacity - occupied);
                var existing = ICUStats.FirstOrDefault(s => s.RoomName == room.RoomName);
                if (existing != null)
                {
                    // Update in-place to avoid flicker
                    existing.Total     = room.MaxCapacity;
                    existing.Available = available;
                }
                else
                {
                    ICUStats.Add(new ICURoomStat
                    {
                        RoomName  = room.RoomName,
                        Total     = room.MaxCapacity,
                        Available = available
                    });
                }
            }

            // Update case counts (today only)
            OTCaseCount  = rooms.Where(r => r.RoomType == "OT")
                .Sum(r => r.OTSurgeries.Count(s => s.SurgeryDate.Date == now.Date));
            ICUCaseCount = rooms.Where(r => r.RoomType == "ICU")
                .Sum(r => r.ICUPatients.Count(p => now.Date >= p.StartDate.Date && now.Date <= p.EndDate.Date));
            OPDCaseCount = rooms.Where(r => r.RoomType == "OPD")
                .Sum(r => r.OPDPatients.Count(p => p.Date.Date == now.Date));
        }


        private void LoadLiveStatusGrid()
        {
            LiveRoomStatuses.Clear();
            var rooms = _roomSchedulingService.Rooms;

            var orderedRooms = rooms
                .OrderBy(r => GetRoomTypeOrder(r.RoomType))
                .ThenBy(r => r.RoomName);

            foreach (var room in orderedRooms)
            {
                LiveRoomStatuses.Add(CreateLiveStatusItem(room));
            }
        }

        private void LoadCasesLineChart()
        {
            CaseChartPoints.Clear();
            var newPoints = new System.Windows.Media.PointCollection();

            var rooms = _roomSchedulingService.Rooms;

            if (rooms.Count == 0)
            {
                TotalCasesBookedText = "Total cases booked: 0";
                return;
            }

            try
            {
                DateTime today = DateTime.Now.Date;
                DateTime startDate;
                DateTime endDate;

                switch (SelectedCaseChartFilter)
                {
                    case "Today":
                        startDate = today;
                        endDate = today;
                        break;
                    case "Previous Week":
                        int previousWeekOffset = (int)today.DayOfWeek == 0 ? 7 : (int)today.DayOfWeek;
                        DateTime currentWeekStart = today.AddDays(-previousWeekOffset + 1);
                        startDate = currentWeekStart.AddDays(-7);
                        endDate = currentWeekStart.AddDays(-1);
                        break;
                    case "Current Month":
                        startDate = new DateTime(today.Year, today.Month, 1);
                        endDate = startDate.AddMonths(1).AddDays(-1);
                        break;
                    case "All Upcoming":
                        startDate = today;
                        endDate = today.AddDays(30);
                        break;
                    case "Current Week":
                    default:
                        int currentWeekOffset = (int)today.DayOfWeek == 0 ? 7 : (int)today.DayOfWeek;
                        startDate = today.AddDays(-currentWeekOffset + 1);
                        endDate = startDate.AddDays(6);
                        break;
                }

                // Query data directly from the shared room collection
                var caseDates = rooms
                    .SelectMany(room =>
                        (room.OTSurgeries == null ? System.Linq.Enumerable.Empty<DateTime>() : room.OTSurgeries.Select(s => s.StartDateTime.Date))
                        .Concat(room.ICUPatients == null ? System.Linq.Enumerable.Empty<DateTime>() : room.ICUPatients.Select(p => p.StartDate.Date))
                        .Concat(room.OPDPatients == null ? System.Linq.Enumerable.Empty<DateTime>() : room.OPDPatients.Select(p => p.Date.Date)))
                    .Where(date => date >= startDate && date <= endDate)
                    .ToList();

                var groupedCases = System.Linq.Enumerable.Range(0, (endDate - startDate).Days + 1)
                    .Select(i => startDate.AddDays(i))
                    .Select(date => new
                    {
                        Date = date,
                        Count = caseDates.Count(d => d.Date == date.Date)
                    })
                    .ToList();

                int totalCases = groupedCases.Sum(x => x.Count);
                int maxCases = Math.Max(1, groupedCases.Max(x => x.Count));

                TotalCasesBookedText = $"Total cases booked: {totalCases}";

                double chartLeft = 52;
                double chartTop = 18;
                double chartWidth = 405;
                double chartHeight = 68;

                int pointCount = groupedCases.Count;
                for (int i = 0; i < pointCount; i++)
                {
                    double x = pointCount == 1 ? chartLeft + chartWidth / 2 : chartLeft + (chartWidth / (pointCount - 1)) * i;
                    double y = chartTop + chartHeight - ((double)groupedCases[i].Count / maxCases * chartHeight);

                    CaseChartPoints.Add(new CaseChartPoint
                    {
                        X = x - 16,
                        Y = y - 15,
                        LabelX = x - 27,
                        Label = groupedCases[i].Date.ToString("dd MMM"),
                        Count = groupedCases[i].Count
                    });

                    newPoints.Add(new System.Windows.Point(x, y));

                }

                CaseLinePoints = newPoints;
                OnPropertyChanged(nameof(CaseChartPoints));
            }
            catch
            {
                TotalCasesBookedText = "Total cases booked: 0";
            }
        }

        private LiveRoomStatusItem CreateLiveStatusItem(HospitalRoom room)
        {
            DateTime now = DateTime.Now;

            // --- OT LOGIC ---
            if (string.Equals(room.RoomType, "OT", StringComparison.OrdinalIgnoreCase))
            {
                // Active surgery right now
                var activeSurgery = room.OTSurgeries
                    .Where(s => !s.IsCompleted)
                    .FirstOrDefault(s => now >= s.StartDateTime && now <= s.EndDateTime);

                if (activeSurgery != null)
                {
                    return new LiveRoomStatusItem
                    {
                        Room = room.RoomName, Type = room.RoomType,
                        Status = "Surgery In Progress",
                        TimeRemaining = FormatTimeRemaining(activeSurgery.EndDateTime - now),
                        PatientName = activeSurgery.PatientName,
                        AttendingPhysician = activeSurgery.PrimarySurgeonName,
                        StatusBrush = Brushes.Red
                    };
                }

                // Upcoming surgery TODAY only
                var upcomingSurgery = room.OTSurgeries
                    .Where(s => !s.IsCompleted && s.StartDateTime.Date == now.Date && s.StartDateTime > now)
                    .OrderBy(s => s.StartDateTime)
                    .FirstOrDefault();

                if (upcomingSurgery != null)
                {
                    TimeSpan timeToStart = upcomingSurgery.StartDateTime - now;
                    bool soon = timeToStart.TotalMinutes <= 30;
                    return new LiveRoomStatusItem
                    {
                        Room = room.RoomName, Type = room.RoomType,
                        Status = soon ? "Surgery Starting Soon" : "Scheduled",
                        TimeRemaining = $"Will start in {FormatTimeRemaining(timeToStart)}",
                        PatientName = upcomingSurgery.PatientName,
                        AttendingPhysician = upcomingSurgery.PrimarySurgeonName,
                        StatusBrush = soon ? Brushes.Orange : Brushes.Goldenrod
                    };
                }
            }

            // --- ICU LOGIC ---
            if (string.Equals(room.RoomType, "ICU", StringComparison.OrdinalIgnoreCase))
            {
                var activePatient = room.ICUPatients
                    .Where(p => now.Date >= p.StartDate.Date && now.Date <= p.EndDate.Date)
                    .OrderBy(p => p.StartDate)
                    .FirstOrDefault();

                if (activePatient != null)
                {
                    return new LiveRoomStatusItem
                    {
                        Room = room.RoomName, Type = room.RoomType,
                        Status = "Occupied",
                        TimeRemaining = $"Till {activePatient.EndDate:dd MMM yyyy}",
                        PatientName = activePatient.PatientName,
                        AttendingPhysician = "-",
                        StatusBrush = Brushes.Gray
                    };
                }
            }

            // --- OPD LOGIC ---
            if (string.Equals(room.RoomType, "OPD", StringComparison.OrdinalIgnoreCase))
            {
                var todayAppt = room.OPDPatients
                    .Where(p => p.Date.Date == now.Date)
                    .OrderBy(p => p.Time)
                    .FirstOrDefault();

                if (todayAppt != null)
                {
                    return new LiveRoomStatusItem
                    {
                        Room = room.RoomName, Type = room.RoomType,
                        Status = "Appointments Scheduled",
                        TimeRemaining = $"Today at {todayAppt.Time}",
                        PatientName = todayAppt.PatientName,
                        AttendingPhysician = todayAppt.PhysicianName,
                        StatusBrush = Brushes.Orange
                    };
                }
            }

            // Default: Available — show --:-- for Time Remaining
            return new LiveRoomStatusItem
            {
                Room = room.RoomName, Type = room.RoomType,
                Status = "Available",
                TimeRemaining = "--:--",
                PatientName = "-",
                AttendingPhysician = "-",
                StatusBrush = Brushes.ForestGreen
            };
        }


        private string FormatTimeRemaining(TimeSpan timeSpan)
        {
            if (timeSpan.TotalSeconds <= 0)
                return "00h 00m";

            int hours = (int)timeSpan.TotalHours;
            int minutes = timeSpan.Minutes;

            return $"{hours:00}h {minutes:00}m";
        }

        private int GetRoomTypeOrder(string roomType)
        {
            if (string.Equals(roomType, "OT", StringComparison.OrdinalIgnoreCase))
                return 1;

            if (string.Equals(roomType, "ICU", StringComparison.OrdinalIgnoreCase))
                return 2;

            if (string.Equals(roomType, "OPD", StringComparison.OrdinalIgnoreCase))
                return 3;

            return 4;
        }

        private void AddDefaultLiveStatusRows()
        {
            LiveRoomStatuses.Clear();

            var rooms = _roomSchedulingService.Rooms;

            // Iterate through existing configured rooms instead of hardcoding 1-5
            foreach (var room in rooms.OrderBy(r => GetRoomTypeOrder(r.RoomType)).ThenBy(r => r.RoomName))
            {
                LiveRoomStatuses.Add(new LiveRoomStatusItem
                {
                    Room = room.RoomName,
                    Type = room.RoomType,
                    Status = "Available",
                    TimeRemaining = "Available Now",
                    PatientName = "-",
                    AttendingPhysician = "-",
                    StatusBrush = Brushes.ForestGreen
                });
            }

            OnPropertyChanged(nameof(LiveRoomStatuses));
        }

        private void Surgeons_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null)
            {
                foreach (Surgeon surgeon in e.OldItems)
                {
                    surgeon.PropertyChanged -= Surgeon_PropertyChanged;
                }
            }

            if (e.NewItems != null)
            {
                foreach (Surgeon surgeon in e.NewItems)
                {
                    surgeon.PropertyChanged += Surgeon_PropertyChanged;
                }
            }

            RefreshChart();
        }

        private void Surgeon_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Surgeon.Availability))
            {
                RefreshChart();
            }
        }

        private void RefreshChart()
        {
            AvailableSurgeons = _surgeonService.Surgeons.Count(s => s.Availability == "Available");
            BusySurgeons = _surgeonService.Surgeons.Count(s => s.Availability == "Busy");
            OnLeaveSurgeons = _surgeonService.Surgeons.Count(s => s.Availability == "On Leave");

            PieSlices.Clear();

            int total = TotalSurgeons;

            if (total <= 0)
            {
                OnPropertyChanged(nameof(TotalSurgeons));
                OnPropertyChanged(nameof(TotalPhysicians));
                OnPropertyChanged(nameof(AvailablePhysicians));
                OnPropertyChanged(nameof(PieSlices));
                return;
            }

            double startAngle = -90;

            AddPieSlice("Available", AvailableSurgeons, total, ref startAngle, Color.FromRgb(34, 139, 34));
            AddPieSlice("Busy", BusySurgeons, total, ref startAngle, Color.FromRgb(220, 53, 69));
            AddPieSlice("On Leave", OnLeaveSurgeons, total, ref startAngle, Color.FromRgb(255, 165, 0));

            OnPropertyChanged(nameof(TotalSurgeons));
            OnPropertyChanged(nameof(TotalPhysicians));
            OnPropertyChanged(nameof(AvailablePhysicians));
            OnPropertyChanged(nameof(PieSlices));
        }

        private void AddPieSlice(
            string label,
            int value,
            int total,
            ref double startAngle,
            Color color)
        {
            if (value <= 0)
                return;

            double sweepAngle = (double)value / total * 360;

            PieSlices.Add(new PieSliceViewModel
            {
                Label = label,
                Value = value,
                Fill = new SolidColorBrush(color),
                Geometry = PieGeometryHelper.CreateSlice(startAngle, sweepAngle)
            });

            startAngle += sweepAngle;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class LiveRoomStatusItem
    {
        public string Room { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string TimeRemaining { get; set; } = string.Empty;
        public Brush StatusBrush { get; set; } = Brushes.ForestGreen;

        // Split columns
        public string PatientName { get; set; } = "-";
        public string AttendingPhysician { get; set; } = "-";
    }

    public class CaseChartPoint
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double LabelX { get; set; }
        public string Label { get; set; } = string.Empty;
        public int Count { get; set; }
    }
}

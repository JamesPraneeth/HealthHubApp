using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Input;
using HealthHub.App.Services.Implementations;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;

namespace HealthHub.App.Views.ViewModels.AddSurgeon
{
    public class AddSurgeonViewModel : INotifyPropertyChanged
    {
        private readonly ISurgeonMgmtService _store;
        private readonly HealthHub.App.Services.Interfaces.IDepartmentService _deptService;
        private readonly Surgeon? _originalSurgeon;
        private readonly bool _isEditMode;

        private string _surgeonId = string.Empty;
        private string _name = string.Empty;
        private string _department = string.Empty;
        private string _email = string.Empty;
        private string _contactNo = string.Empty;
        private string _specialization = string.Empty;
        private string _experience = string.Empty;
        private string _availability = "Available";

        private string _nameError = string.Empty;
        private string _departmentError = string.Empty;
        private string _emailError = string.Empty;
        private string _contactNoError = string.Empty;
        private string _specializationError = string.Empty;
        private string _experienceError = string.Empty;

        public event PropertyChangedEventHandler? PropertyChanged;
        public Action? CloseAction { get; set; }

        public string HeaderTitle => _isEditMode ? "Edit Surgeon" : "Add Surgeon";
        public string SaveButtonText => _isEditMode ? "Save" : "Add Surgeon";

        // Loaded from DepartmentsProcedures.xml
        public ObservableCollection<string> DepartmentOptions { get; } = new();
        public ObservableCollection<string> SpecializationOptions { get; } = new();

        public ObservableCollection<string> AvailabilityOptions { get; } = new()
        {
            "Available", "Busy", "On Leave"
        };

        public bool IsDepartmentSelected => !string.IsNullOrWhiteSpace(Department);

        public string SurgeonId
        {
            get => _surgeonId;
            set { if (_surgeonId != value) { _surgeonId = value; OnPropertyChanged(); } }
        }

        public string Name
        {
            get => _name;
            set { if (_name != value) { _name = value; ValidateName(); OnPropertyChanged(); } }
        }

        public string Department
        {
            get => _department;
            set
            {
                if (_department != value)
                {
                    _department = value;
                    ValidateDepartment();
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(IsDepartmentSelected));
                    LoadSpecializations();
                    Specialization = string.Empty; // reset specialization on dept change
                }
            }
        }

        public string Email
        {
            get => _email;
            set { if (_email != value) { _email = value; ValidateEmail(); OnPropertyChanged(); } }
        }

        public string ContactNo
        {
            get => _contactNo;
            set { if (_contactNo != value) { _contactNo = value; ValidateContactNo(); OnPropertyChanged(); } }
        }

        public string Specialization
        {
            get => _specialization;
            set { if (_specialization != value) { _specialization = value; ValidateSpecialization(); OnPropertyChanged(); } }
        }

        public string Experience
        {
            get => _experience;
            set { if (_experience != value) { _experience = value; ValidateExperience(); OnPropertyChanged(); } }
        }

        public string Availability
        {
            get => _availability;
            set { if (_availability != value) { _availability = value; OnPropertyChanged(); } }
        }

        public string NameError { get => _nameError; set { if (_nameError != value) { _nameError = value; OnPropertyChanged(); } } }
        public string DepartmentError { get => _departmentError; set { if (_departmentError != value) { _departmentError = value; OnPropertyChanged(); } } }
        public string EmailError { get => _emailError; set { if (_emailError != value) { _emailError = value; OnPropertyChanged(); } } }
        public string ContactNoError { get => _contactNoError; set { if (_contactNoError != value) { _contactNoError = value; OnPropertyChanged(); } } }
        public string SpecializationError { get => _specializationError; set { if (_specializationError != value) { _specializationError = value; OnPropertyChanged(); } } }
        public string ExperienceError { get => _experienceError; set { if (_experienceError != value) { _experienceError = value; OnPropertyChanged(); } } }

        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        // Add mode
        public AddSurgeonViewModel()
        {
            _store = App.SurgeonService;
            _deptService = App.DepartmentService;
            _isEditMode = false;

            LoadDepartments();
            SurgeonId = GenerateSurgeonId();
            Availability = "Available";

            SaveCommand = new HealthHub.App.Services.Implementations.RelayCommand(Save);
            CancelCommand = new HealthHub.App.Services.Implementations.RelayCommand(() => CloseAction?.Invoke());
        }

        // Edit mode
        public AddSurgeonViewModel(Surgeon surgeonToEdit)
        {
            _store = App.SurgeonService;
            _deptService = App.DepartmentService;
            _originalSurgeon = surgeonToEdit;
            _isEditMode = true;

            LoadDepartments();

            SurgeonId    = surgeonToEdit.SurgeonId;
            Name         = surgeonToEdit.Name;
            Email        = surgeonToEdit.Email;
            ContactNo    = surgeonToEdit.ContactNo;
            Experience   = surgeonToEdit.Experience;
            Availability = surgeonToEdit.Availability;

            // Set department first so specializations load
            _department = surgeonToEdit.Department;
            OnPropertyChanged(nameof(Department));
            OnPropertyChanged(nameof(IsDepartmentSelected));
            LoadSpecializations();

            // Then set specialization (now options are loaded)
            Specialization = surgeonToEdit.Specialization;

            // Ensure edit values exist in options even if not in XML
            EnsureOption(DepartmentOptions, Department);
            EnsureOption(SpecializationOptions, Specialization);
            EnsureOption(AvailabilityOptions, Availability);

            SaveCommand   = new HealthHub.App.Services.Implementations.RelayCommand(Save);
            CancelCommand = new HealthHub.App.Services.Implementations.RelayCommand(() => CloseAction?.Invoke());
        }

        private void LoadDepartments()
        {
            DepartmentOptions.Clear();
            foreach (var d in _deptService.GetDepartments())
                DepartmentOptions.Add(d);
        }

        private void LoadSpecializations()
        {
            SpecializationOptions.Clear();
            if (string.IsNullOrWhiteSpace(Department)) return;
            foreach (var s in _deptService.GetSpecializations(Department))
                SpecializationOptions.Add(s);
        }

        private string GenerateSurgeonId()
        {
            int n = _store.Surgeons.Count + 1;
            while (_store.Surgeons.Any(s => s.SurgeonId == $"SURG{n:000}")) n++;
            return $"SURG{n:000}";
        }

        private void Save()
        {
            if (!ValidateAll()) return;

            if (_isEditMode && _originalSurgeon != null)
            {
                _originalSurgeon.Name           = Name.Trim();
                _originalSurgeon.Department     = Department.Trim();
                _originalSurgeon.Email          = Email.Trim();
                _originalSurgeon.ContactNo      = ContactNo.Trim();
                _originalSurgeon.Specialization = Specialization.Trim();
                _originalSurgeon.Experience     = Experience.Trim();
                _originalSurgeon.Availability   = string.IsNullOrWhiteSpace(Availability) ? "Available" : Availability.Trim();
            }
            else
            {
                _store.Surgeons.Add(new Surgeon
                {
                    SurgeonId      = SurgeonId,
                    Name           = Name.Trim(),
                    Department     = Department.Trim(),
                    Email          = Email.Trim(),
                    ContactNo      = ContactNo.Trim(),
                    Specialization = Specialization.Trim(),
                    Experience     = Experience.Trim(),
                    Availability   = string.IsNullOrWhiteSpace(Availability) ? "Available" : Availability.Trim()
                });
            }

            CloseAction?.Invoke();
        }

        private bool ValidateAll()
        {
            ValidateName(); ValidateDepartment(); ValidateSpecialization();
            ValidateExperience(); ValidateEmail(); ValidateContactNo();
            return string.IsNullOrWhiteSpace(NameError) && string.IsNullOrWhiteSpace(DepartmentError)
                && string.IsNullOrWhiteSpace(SpecializationError) && string.IsNullOrWhiteSpace(ExperienceError)
                && string.IsNullOrWhiteSpace(EmailError) && string.IsNullOrWhiteSpace(ContactNoError);
        }

        private void ValidateName()
        {
            if (string.IsNullOrWhiteSpace(Name))                  { NameError = "Surgeon Name is required."; return; }
            if (Name.Trim().Length <= 1)                           { NameError = "Surgeon Name should be greater than a single character."; return; }
            if (Name.Trim().Length > 50)                           { NameError = "Surgeon Name should not exceed 50 characters."; return; }
            NameError = string.Empty;
        }

        private void ValidateDepartment()
        {
            if (string.IsNullOrWhiteSpace(Department))             { DepartmentError = "Department is required."; return; }
            if (!DepartmentOptions.Contains(Department))           { DepartmentError = "Select a department from the list."; return; }
            DepartmentError = string.Empty;
        }

        private void ValidateSpecialization()
        {
            if (string.IsNullOrWhiteSpace(Specialization))         { SpecializationError = "Specialization is required."; return; }
            if (SpecializationOptions.Count > 0 && !SpecializationOptions.Contains(Specialization))
                                                                   { SpecializationError = "Select a specialization from the list."; return; }
            SpecializationError = string.Empty;
        }

        private void ValidateExperience()
        {
            if (string.IsNullOrWhiteSpace(Experience))             { ExperienceError = "Experience is required."; return; }
            ExperienceError = string.Empty;
        }

        private void ValidateEmail()
        {
            if (string.IsNullOrWhiteSpace(Email))                  { EmailError = "Email is required."; return; }
            if (!Regex.IsMatch(Email.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.IgnoreCase))
                                                                   { EmailError = "Email must contain a valid format with @ and domain."; return; }
            EmailError = string.Empty;
        }

        private void ValidateContactNo()
        {
            if (string.IsNullOrWhiteSpace(ContactNo))              { ContactNoError = "Phone Number is required."; return; }
            if (!Regex.IsMatch(ContactNo.Trim(), @"^\d{10}$"))     { ContactNoError = "Phone Number must be numeric and exactly 10 digits."; return; }
            ContactNoError = string.Empty;
        }

        private static void EnsureOption(ObservableCollection<string> list, string value)
        {
            if (!string.IsNullOrWhiteSpace(value) && !list.Contains(value))
                list.Insert(0, value);
        }

        private void OnPropertyChanged([CallerMemberName] string? p = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));
    }
}

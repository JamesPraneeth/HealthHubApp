using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using HealthHub.Domain.Entities;
using HealthHub.App.Services.Implementations;
using HealthHub.App.Services.Interfaces;

namespace HealthHub.App.Views.ViewModels.PatientDetails
{
    public class EditPatientViewModel
    {
        private readonly Patient _original;

        public Patient Draft { get; }

        public ObservableCollection<string> GenderOptions { get; }

        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        public Action? CloseAction { get; set; }

        public EditPatientViewModel(Patient original)
        {
            _original = original;

            // Work on a copy
            Draft = original.Clone();

            GenderOptions = new ObservableCollection<string>
            {
                "Male",
                "Female",
                "I Prefer Not To Say"
            };

            // Ensure existing value is present
            // Important if older patients have different Gender text
            EnsureOptionExists(GenderOptions, Draft.Gender);

            SaveCommand = new HealthHub.App.Services.Implementations.RelayCommand(Save);
            CancelCommand = new HealthHub.App.Services.Implementations.RelayCommand(Cancel);
        }

        private void Save()
        {
            // Copy edited values back to original object
            _original.CopyFrom(Draft);
            CloseAction?.Invoke();
        }

        private void Cancel()
        {
            CloseAction?.Invoke();
        }

        private static void EnsureOptionExists(ObservableCollection<string> list, string value)
        {
            if (!string.IsNullOrWhiteSpace(value) && !list.Contains(value))
                list.Insert(0, value);
        }
    }
}

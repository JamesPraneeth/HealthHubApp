using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using HealthHub.App.Services.Implementations;
using HealthHub.App.Services.Interfaces;
using HealthHub.App.Views.PatientDetails;
using HealthHub.Domain.Entities;

namespace HealthHub.App.Views.ViewModels.PatientDetails
{
    public class PatientDetailsViewModel : INotifyPropertyChanged
    {
        private readonly IPatientMgmtService _store;

        private int _currentPage = 1;
        private int _pageSize = 10;

        private bool? _areAllFilteredSelected = false;
        private bool _isUpdatingHeaderSelection;

        public ICollectionView PatientsView { get; }

        public ICommand EditCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand DownloadCommand { get; }
        public ICommand ExportSelectedCommand { get; }
        public ICommand NextPageCommand { get; }
        public ICommand PreviousPageCommand { get; }

        public event PropertyChangedEventHandler? PropertyChanged;

        public int CurrentPage
        {
            get => _currentPage;
            set
            {
                if (_currentPage != value)
                {
                    _currentPage = value;
                    OnPropertyChanged(nameof(CurrentPage));

                    (NextPageCommand as RelayCommand)?.RaiseCanExecuteChanged();
                    (PreviousPageCommand as RelayCommand)?.RaiseCanExecuteChanged();

                    PatientsView.Refresh();
                    UpdateHeaderSelectionState();
                }
            }
        }

        public int PageSize
        {
            get => _pageSize;
            set
            {
                if (_pageSize != value)
                {
                    _pageSize = value;
                    CurrentPage = 1;
                    OnPropertyChanged(nameof(PageSize));

                    PatientsView.Refresh();
                    UpdateHeaderSelectionState();
                }
            }
        }

        public bool? AreAllFilteredSelected
        {
            get => _areAllFilteredSelected;
            set
            {
                if (_isUpdatingHeaderSelection)
                    return;

                if (_areAllFilteredSelected != value)
                {
                    _areAllFilteredSelected = value;
                    OnPropertyChanged(nameof(AreAllFilteredSelected));

                    if (value.HasValue)
                    {
                        SetSelectionForFilteredPatients(value.Value);
                    }
                }
            }
        }

        public PatientDetailsViewModel(IPatientMgmtService store)
        {
            _store = store;

            PatientsView = CollectionViewSource.GetDefaultView(_store.Patients);
            PatientsView.Filter = FilterPatient;

            _store.PropertyChanged += Store_PropertyChanged;

            foreach (var patient in _store.Patients)
            {
                patient.PropertyChanged += Patient_PropertyChanged;
            }

            _store.Patients.CollectionChanged += Patients_CollectionChanged;

            EditCommand = new HealthHub.App.Services.Implementations.RelayCommand(OnEdit);
            DeleteCommand = new HealthHub.App.Services.Implementations.RelayCommand(OnDelete);
            DownloadCommand = new HealthHub.App.Services.Implementations.RelayCommand(OnDownload);
            ExportSelectedCommand = new HealthHub.App.Services.Implementations.RelayCommand(OnExportSelected);

            NextPageCommand = new HealthHub.App.Services.Implementations.RelayCommand(_ => NextPage(), _ => CanGoNext());
            PreviousPageCommand = new HealthHub.App.Services.Implementations.RelayCommand(_ => PreviousPage(), _ => CanGoPrevious());

            UpdateHeaderSelectionState();
        }

        private void Patients_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null)
            {
                foreach (Patient patient in e.OldItems)
                {
                    patient.PropertyChanged -= Patient_PropertyChanged;
                }
            }

            if (e.NewItems != null)
            {
                foreach (Patient patient in e.NewItems)
                {
                    patient.PropertyChanged += Patient_PropertyChanged;
                }
            }

            EnsureCurrentPageValid();

            PatientsView.Refresh();

            OnPropertyChanged(nameof(CurrentPage));

            (NextPageCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (PreviousPageCommand as RelayCommand)?.RaiseCanExecuteChanged();

            UpdateHeaderSelectionState();
        }

        private void Patient_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Patient.IsSelected))
            {
                UpdateHeaderSelectionState();
            }
        }

        private void Store_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(IPatientMgmtService.SearchText) ||
                e.PropertyName == nameof(IPatientMgmtService.SelectedSearchBy) ||
                e.PropertyName == nameof(IPatientMgmtService.SelectedFilterBy) ||
                e.PropertyName == nameof(IPatientMgmtService.SelectedFilterValue))
            {
                CurrentPage = 1;
                PatientsView.Refresh();
                UpdateHeaderSelectionState();
            }
        }

        private bool FilterPatient(object obj)
        {
            if (obj is not Patient patient)
                return false;

            if (!MatchesSearch(patient))
                return false;

            if (!MatchesFilter(patient))
                return false;

            var filteredPatients = _store.Patients
                .Where(p => MatchesSearch(p) && MatchesFilter(p))
                .ToList();

            int index = filteredPatients.IndexOf(patient);

            if (index < 0)
                return false;

            int start = (CurrentPage - 1) * PageSize;
            int end = start + PageSize - 1;

            return index >= start && index <= end;
        }

        private bool MatchesSearch(Patient patient)
        {
            if (string.IsNullOrWhiteSpace(_store.SearchText))
                return true;

            string search = "*" + _store.SearchText.Trim() + "*";

            return _store.SelectedSearchBy switch
            {
                "Name" => MatchWildcard(patient.Name ?? "", search),
                "Email ID" => MatchWildcard(patient.Email ?? "", search),
                _ => true
            };
        }

        private bool MatchWildcard(string input, string pattern)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;

            string regexPattern = "^" +
                System.Text.RegularExpressions.Regex.Escape(pattern)
                    .Replace("\\*", ".*")
                    .Replace("\\?", ".") +
                "$";

            return System.Text.RegularExpressions.Regex
                .IsMatch(
                    input,
                    regexPattern,
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        private bool MatchesFilter(Patient patient)
        {
            if (_store.SelectedFilterBy == "None" ||
                string.IsNullOrWhiteSpace(_store.SelectedFilterValue) ||
                _store.SelectedFilterValue == "All")
            {
                return true;
            }

            return _store.SelectedFilterBy switch
            {
                "Gender" => string.Equals(
                    patient.Gender,
                    _store.SelectedFilterValue,
                    StringComparison.OrdinalIgnoreCase),
                _ => true
            };
        }

        private int GetFilteredCount()
        {
            return _store.Patients.Count(p => MatchesSearch(p) && MatchesFilter(p));
        }

        private bool CanGoNext()
        {
            return CurrentPage < Math.Ceiling((double)GetFilteredCount() / PageSize);
        }

        private bool CanGoPrevious()
        {
            return CurrentPage > 1;
        }

        private void NextPage()
        {
            if (CanGoNext())
                CurrentPage++;
        }

        private void PreviousPage()
        {
            if (CanGoPrevious())
                CurrentPage--;
        }

        private void EnsureCurrentPageValid()
        {
            int filteredCount = GetFilteredCount();
            int totalPages = Math.Max(1, (int)Math.Ceiling((double)filteredCount / PageSize));

            if (CurrentPage > totalPages)
            {
                CurrentPage = totalPages;
            }
        }

        private void OnEdit(object? parameter)
        {
            if (parameter is not Patient patient)
                return;

            var vm = new HealthHub.App.Views.ViewModels.PatientDetails.EditPatientViewModel(patient);

            var win = new EditPatientWindow
            {
                DataContext = vm,
                Owner = Application.Current.MainWindow
            };

            vm.CloseAction = () => win.Close();

            win.ShowDialog();

            PatientsView.Refresh();
            UpdateHeaderSelectionState();
        }

        private void OnDelete(object? parameter)
        {
            if (parameter is not Patient patient)
                return;

            var result = MessageBox.Show(
                $"Delete patient: {patient.Name} ?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                string deletedPatientId = patient.PatientId;
                string deletedPatientName = patient.Name;

                _store.Patients.Remove(patient);

                HealthHub.App.Services.Implementations.StatusService.Publish(
                    $"Patient has been deleted. Patient ID: {deletedPatientId}, Name: {deletedPatientName}");

                EnsureCurrentPageValid();

                PatientsView.Refresh();
                UpdateHeaderSelectionState();
            }
        }

        private void OnDownload(object? parameter)
        {
            if (parameter is not Patient patient)
                return;

            try
            {
                var dlg = new Microsoft.Win32.SaveFileDialog
                {
                    FileName = $"{patient.PatientId}_{patient.Name}_PatientDetails",
                    DefaultExt = ".txt",
                    Filter = "Text file (*.txt)|*.txt"
                };

                if (dlg.ShowDialog() == true)
                {
                    var content =
$@"Patient Details
--------------
Patient ID: {patient.PatientId}
Name: {patient.Name}
DOB: {patient.DOB:dd/MM/yyyy}
Gender: {patient.Gender}
Email: {patient.Email}
Phone: {patient.PhoneNo}
Address: {patient.Address}";

                    File.WriteAllText(dlg.FileName, content);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Download failed: {ex.Message}",
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void OnExportSelected()
        {
            var selectedPatients = _store.Patients
                .Where(p => p.IsSelected)
                .ToList();

            if (!selectedPatients.Any())
            {
                MessageBox.Show(
                    "Please select at least one patient record to export.",
                    "No Records Selected",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                return;
            }

            try
            {
                var dlg = new Microsoft.Win32.SaveFileDialog
                {
                    FileName = "Selected_Patient_Records",
                    DefaultExt = ".xlsx",
                    Filter = "Excel Workbook (*.xlsx)|*.xlsx"
                };

                if (dlg.ShowDialog() == true)
                {
                    CreateExcelFile(dlg.FileName, selectedPatients);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Export failed: {ex.Message}",
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void SetSelectionForFilteredPatients(bool isSelected)
        {
            var filteredPatients = _store.Patients
                .Where(p => MatchesSearch(p) && MatchesFilter(p))
                .ToList();

            foreach (var patient in filteredPatients)
            {
                patient.IsSelected = isSelected;
            }

            UpdateHeaderSelectionState();
        }

        private void UpdateHeaderSelectionState()
        {
            var filteredPatients = _store.Patients
                .Where(p => MatchesSearch(p) && MatchesFilter(p))
                .ToList();

            bool? newState;

            if (!filteredPatients.Any())
                newState = false;
            else if (filteredPatients.All(p => p.IsSelected))
                newState = true;
            else if (filteredPatients.All(p => !p.IsSelected))
                newState = false;
            else
                newState = null;

            _isUpdatingHeaderSelection = true;
            _areAllFilteredSelected = newState;
            OnPropertyChanged(nameof(AreAllFilteredSelected));
            _isUpdatingHeaderSelection = false;
        }

        private void CreateExcelFile(string filePath, System.Collections.Generic.List<Patient> patients)
        {
            if (File.Exists(filePath))
                File.Delete(filePath);

            using (var stream = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite))
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                AddZipEntry(archive, "[Content_Types].xml", GetContentTypesXml());
                AddZipEntry(archive, "_rels/.rels", GetRootRelsXml());
                AddZipEntry(archive, "xl/workbook.xml", GetWorkbookXml());
                AddZipEntry(archive, "xl/_rels/workbook.xml.rels", GetWorkbookRelsXml());
                AddZipEntry(archive, "xl/worksheets/sheet1.xml", GetWorksheetXml(patients));
            }
        }

        private void AddZipEntry(ZipArchive archive, string entryName, string content)
        {
            var entry = archive.CreateEntry(entryName);

            using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
            writer.Write(content);
        }

        private string GetContentTypesXml()
        {
            return @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Types xmlns=""http://schemas.openxmlformats.org/package/2006/content-types"">
  <Default Extension=""rels"" ContentType=""application/vnd.openxmlformats-package.relationships+xml""/>
  <Default Extension=""xml"" ContentType=""application/xml""/>
  <Override PartName=""/xl/workbook.xml"" ContentType=""application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml""/>
  <Override PartName=""/xl/worksheets/sheet1.xml"" ContentType=""application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml""/>
</Types>";
        }

        private string GetRootRelsXml()
        {
            return @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"" Target=""xl/workbook.xml""/>
</Relationships>";
        }

        private string GetWorkbookRelsXml()
        {
            return @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"" Target=""worksheets/sheet1.xml""/>
</Relationships>";
        }

        private string GetWorkbookXml()
        {
            return @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<workbook xmlns=""http://schemas.openxmlformats.org/spreadsheetml/2006/main""
          xmlns:r=""http://schemas.openxmlformats.org/officeDocument/2006/relationships"">
  <sheets>
    <sheet name=""Patients"" sheetId=""1"" r:id=""rId1""/>
  </sheets>
</workbook>";
        }

        private string GetWorksheetXml(System.Collections.Generic.List<Patient> patients)
        {
            var sb = new StringBuilder();

            sb.Append(@"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>");
            sb.Append(@"<worksheet xmlns=""http://schemas.openxmlformats.org/spreadsheetml/2006/main"">");
            sb.Append("<sheetData>");

            string[] headers =
            {
                "Patient ID",
                "Name",
                "DOB",
                "Gender",
                "Email",
                "Phone No",
                "Address"
            };

            sb.Append(@"<row r=""1"">");

            for (int i = 0; i < headers.Length; i++)
            {
                string cellRef = $"{GetColumnName(i + 1)}1";
                AppendInlineStringCell(sb, cellRef, headers[i]);
            }

            sb.Append("</row>");

            for (int rowIndex = 0; rowIndex < patients.Count; rowIndex++)
            {
                var patient = patients[rowIndex];
                int excelRow = rowIndex + 2;

                sb.Append($@"<row r=""{excelRow}"">");

                string[] values =
                {
                    patient.PatientId,
                    patient.Name,
                    patient.DOB.ToString("dd/MM/yyyy"),
                    patient.Gender,
                    patient.Email,
                    patient.PhoneNo,
                    patient.Address
                };

                for (int colIndex = 0; colIndex < values.Length; colIndex++)
                {
                    string cellRef = $"{GetColumnName(colIndex + 1)}{excelRow}";
                    AppendInlineStringCell(sb, cellRef, values[colIndex] ?? string.Empty);
                }

                sb.Append("</row>");
            }

            sb.Append("</sheetData>");
            sb.Append("</worksheet>");

            return sb.ToString();
        }

        private void AppendInlineStringCell(StringBuilder sb, string cellReference, string value)
        {
            sb.Append($@"<c r=""{cellReference}"" t=""inlineStr""><is><t xml:space=""preserve"">{EscapeXml(value)}</t></is></c>");
        }

        private string EscapeXml(string value)
        {
            return value
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;")
                .Replace("'", "&apos;");
        }

        private string GetColumnName(int columnNumber)
        {
            string columnName = string.Empty;

            while (columnNumber > 0)
            {
                int remainder = (columnNumber - 1) % 26;
                columnName = (char)(65 + remainder) + columnName;
                columnNumber = (columnNumber - 1) / 26;
            }

            return columnName;
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

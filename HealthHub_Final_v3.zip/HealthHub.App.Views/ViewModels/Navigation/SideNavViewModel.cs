using System; using System.ComponentModel; using System.Windows; using System.Windows.Input;
using HealthHub.App.Services.Implementations;
using HealthHub.App.Services.Interfaces;
namespace HealthHub.App.Views.ViewModels.Navigation
{
    public class SideNavViewModel : INotifyPropertyChanged
    {
        private double _navWidth = 95;
        private Visibility _textVisibility = Visibility.Collapsed;
        private bool _isExpanded;
        public double NavWidth { get => _navWidth; set { if (_navWidth!=value){_navWidth=value;OnPropChanged(nameof(NavWidth));} } }
        public Visibility TextVisibility { get => _textVisibility; set { if (_textVisibility!=value){_textVisibility=value;OnPropChanged(nameof(TextVisibility));} } }
        public ICommand ToggleCommand{get;} public ICommand NavigateHomeCommand{get;} public ICommand NavigatePatientCommand{get;}
        public ICommand NavigateSurgeonCommand{get;} public ICommand NavigateAboutCommand{get;} public ICommand NavigateOTCommand{get;}
        public Action? ShowHome{get;set;} public Action? ShowPatient{get;set;} public Action? ShowSurgeon{get;set;}
        public Action? ShowAbout{get;set;} public Action? ShowOT{get;set;}
        public SideNavViewModel()
        {
            ToggleCommand=new HealthHub.App.Services.Implementations.RelayCommand(Toggle);
            NavigateHomeCommand=new HealthHub.App.Services.Implementations.RelayCommand(()=>ShowHome?.Invoke());
            NavigatePatientCommand=new HealthHub.App.Services.Implementations.RelayCommand(()=>ShowPatient?.Invoke());
            NavigateSurgeonCommand=new HealthHub.App.Services.Implementations.RelayCommand(()=>ShowSurgeon?.Invoke());
            NavigateAboutCommand=new HealthHub.App.Services.Implementations.RelayCommand(()=>ShowAbout?.Invoke());
            NavigateOTCommand=new HealthHub.App.Services.Implementations.RelayCommand(()=>ShowOT?.Invoke());
        }
        private void Toggle(){_isExpanded=!_isExpanded;NavWidth=_isExpanded?300:95;TextVisibility=_isExpanded?Visibility.Visible:Visibility.Collapsed;}
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropChanged(string p)=>PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(p));
    }
}

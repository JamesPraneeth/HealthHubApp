using System.Windows.Media;

namespace HealthHub.App.Views.ViewModels.Home
{
    public class PieSliceViewModel
    {
        public string Label { get; set; } = string.Empty;

        public int Value { get; set; }

        public Brush Fill { get; set; } = Brushes.Gray;

        public Geometry Geometry { get; set; } = Geometry.Empty;

        public double LabelX { get; set; }

        public double LabelY { get; set; }
    }
}

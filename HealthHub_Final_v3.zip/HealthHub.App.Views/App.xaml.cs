using System.Windows;
using HealthHub.App.Services.Implementations;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Repositories.Implementations;

namespace HealthHub.App.Views
{
    public partial class App : Application
    {
        public static IPatientMgmtService       PatientService    { get; private set; } = null!;
        public static ISurgeonMgmtService       SurgeonService    { get; private set; } = null!;
        public static IAppointmentBookingService BookingService    { get; private set; } = null!;
        public static IDepartmentService        DepartmentService { get; private set; } = null!;
        public static IAuthService              AuthService       { get; private set; } = null!;

        public App()
        {
            void ShowError(string msg) =>
                MessageBox.Show(msg, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);

            // Repositories — only ever referenced here
            var patientRepo  = new PatientRepository();
            var surgeonRepo  = new SurgeonRepository();
            var roomRepo     = new AppointmentBookingRepository();
            var logRepo      = new SurgicalDocumentationRepository();
            var userRepo     = new UserRepository();

            patientRepo.Error += ShowError;
            surgeonRepo.Error += ShowError;
            roomRepo.Error    += ShowError;
            logRepo.Error     += ShowError;
            userRepo.Error    += ShowError;

            // Services — PatientService and SurgeonService created first
            // so BookingService can resolve IDs to names on load
            PatientService    = new PatientMgmtService(patientRepo);
            SurgeonService    = new SurgeonMgmtService(surgeonRepo);
            BookingService    = new AppointmentBookingService(roomRepo, logRepo, PatientService, SurgeonService);
            DepartmentService = new DepartmentService();
            AuthService       = new AuthService(userRepo);

            AuthService.RegisterUser("user123", "User@123");
        }
    }
}

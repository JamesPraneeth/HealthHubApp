using System;
using System.Windows.Controls;

namespace HealthHub.App.Views
{
    /// <summary>
    /// Static delegate bridge. Views inside HealthHub.App.Views.Views call through
    /// AppShell rather than referencing MainWindow directly, keeping navigation
    /// decoupled from the shell.
    /// </summary>
    public static class AppShell
    {
        public static Action? ShowLogin                  { get; set; }
        public static Action? LoadApplicationAfterLogin  { get; set; }
        public static Action<UserControl>? Navigate      { get; set; }
        public static Func<string, string, bool>? ValidateUser  { get; set; }
        public static Func<string, string, bool>? RegisterUser  { get; set; }
    }
}

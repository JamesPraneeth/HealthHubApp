using System.Windows.Controls;

namespace HealthHub.App.Views.PatientDetails
{
    public partial class PatientDetailsView : UserControl
    {
        public PatientDetailsView()
        {
            InitializeComponent();
        }
        private void PatientGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) { }
    }
}

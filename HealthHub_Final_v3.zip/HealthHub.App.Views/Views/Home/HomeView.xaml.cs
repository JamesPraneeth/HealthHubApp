using System;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using HealthHub.App.Services.Implementations;

namespace HealthHub.App.Views.Home
{
    public partial class HomeView : UserControl
    {
        private readonly ObservableCollection<string> _recentActivities = new();

        public HomeView(object viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            RecentStatusList.ItemsSource = _recentActivities;
            StatusService.StatusChanged += msg => Dispatcher.Invoke(() =>
            {
                LiveStatusText.Text = msg;
                LiveStatusTimeText.Text = DateTime.Now.ToString("dd MMM yyyy, hh:mm tt");
                _recentActivities.Insert(0, $"{DateTime.Now:hh:mm tt} - {msg}");
                if (_recentActivities.Count > 5)
                    _recentActivities.RemoveAt(_recentActivities.Count - 1);
            });
        }
    }
}

using System.Windows.Controls;

namespace HealthHub.App.Views.AddSurgeon
{
    public partial class AddSurgeonView : UserControl
    {
        public AddSurgeonView()
        {
            InitializeComponent();
        }
    }
}

using System.Windows.Controls;

namespace HealthHub.App.Views.OT
{
    public partial class OTView : UserControl
    {
        public OTView()
        {
            InitializeComponent();
        }
    }
}

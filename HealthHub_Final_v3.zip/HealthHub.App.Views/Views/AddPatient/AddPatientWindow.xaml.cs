using System.Windows;
using System.Windows.Input;

namespace HealthHub.App.Views.AddPatient
{
    public partial class AddPatientWindow : Window
    {
        public AddPatientWindow()
        {
            InitializeComponent();
        }

        private void AddPatientScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta < 0)
                AddPatientScrollViewer.LineDown();
            else
                AddPatientScrollViewer.LineUp();
            e.Handled = true;
        }
    }
}

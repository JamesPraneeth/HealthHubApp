using System.Windows.Controls;

namespace HealthHub.App.Views.SurgeonDetails
{
    public partial class SurgeonDetailsView : UserControl
    {
        public SurgeonDetailsView()
        {
            InitializeComponent();
        }
    }
}

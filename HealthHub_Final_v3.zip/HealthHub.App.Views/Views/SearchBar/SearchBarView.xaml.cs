using System.Windows.Controls;

namespace HealthHub.App.Views.SearchBar
{
    public partial class SearchBarView : UserControl
    {
        public SearchBarView()
        {
            InitializeComponent();
        }
    }
}

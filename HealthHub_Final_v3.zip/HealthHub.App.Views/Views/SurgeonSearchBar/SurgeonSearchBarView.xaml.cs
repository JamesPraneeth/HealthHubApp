using System.Windows.Controls;

namespace HealthHub.App.Views.SurgeonSearchBar
{
    public partial class SurgeonSearchBarView : UserControl
    {
        public SurgeonSearchBarView()
        {
            InitializeComponent();
        }
    }
}

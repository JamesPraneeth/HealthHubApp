using System.Windows;
using System.Windows.Controls;

namespace HealthHub.App.Views.Header
{
    public partial class HeaderView : UserControl
    {
        public HeaderView()
        {
            InitializeComponent();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Logout",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                AppShell.ShowLogin?.Invoke();
        }
    }
}

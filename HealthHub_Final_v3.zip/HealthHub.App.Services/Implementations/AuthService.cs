using System.Collections.Generic;
using System.Linq;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.App.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _repo;
        private readonly List<UserAccount> _users;

        public AuthService(IUserRepository repo)
        {
            _repo  = repo;
            _users = _repo.GetAll();
        }

        public bool RegisterUser(string userId, string password)
        {
            if (_users.Any(u => u.UserId == userId)) return false;
            _users.Add(new UserAccount { UserId = userId, Password = password });
            _repo.SaveAll(_users);
            return true;
        }

        public bool ValidateUser(string userId, string password)
            => _users.Any(u => u.UserId == userId && u.Password == password);
    }
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.App.Services.Implementations
{
    public class PatientMgmtService : IPatientMgmtService
    {
        private readonly IPatientRepository _repo;

        public ObservableCollection<Patient> Patients { get; } = new();

        public event PropertyChangedEventHandler? PropertyChanged;

        private string _searchText = string.Empty;
        private string _selectedSearchBy = "Name";
        private string _selectedFilterBy = "None";
        private string _selectedFilterValue = "All";

        public PatientMgmtService(IPatientRepository repo)
        {
            _repo = repo;
            foreach (var p in _repo.GetAll())
            {
                p.PropertyChanged += Item_Changed;
                Patients.Add(p);
            }
            Patients.CollectionChanged += Collection_Changed;
        }

        private void Collection_Changed(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null) foreach (Patient p in e.OldItems) p.PropertyChanged -= Item_Changed;
            if (e.NewItems != null) foreach (Patient p in e.NewItems) p.PropertyChanged += Item_Changed;
            Persist();
        }

        private void Item_Changed(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(Patient.IsSelected)) Persist();
        }

        private void Persist() => _repo.SaveAll(new List<Patient>(Patients));

        public string AddPatient(Patient patient)
        {
            var error = Validate(patient);
            if (!string.IsNullOrEmpty(error)) return error;
            Patients.Add(patient);
            return string.Empty;
        }

        public string UpdatePatient(Patient patient)
        {
            var error = Validate(patient);
            if (!string.IsNullOrEmpty(error)) return error;
            Persist();
            return string.Empty;
        }

        public void DeletePatient(Patient patient) => Patients.Remove(patient);

        private static string Validate(Patient p)
        {
            if (string.IsNullOrWhiteSpace(p.Name))               return "Patient Name is required.";
            if (p.Name.Trim().Length > 20)                        return "Patient Name cannot exceed 20 characters.";
            if (p.DOB == default || p.DOB.Date > DateTime.Today)  return "Valid Date of Birth is required.";
            if (string.IsNullOrWhiteSpace(p.Email))               return "Email is required.";
            if (!Regex.IsMatch(p.Email.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$"))
                                                                  return "Email must be a valid format.";
            if (string.IsNullOrWhiteSpace(p.PhoneNo))             return "Phone Number is required.";
            if (!Regex.IsMatch(p.PhoneNo.Trim(), @"^\d{10}$|^\+\d{1,3}\d{9,10}$"))
                                                                  return "Enter a valid phone number.";
            if (string.IsNullOrWhiteSpace(p.Address))             return "Address is required.";
            return string.Empty;
        }

        public string SearchText          { get => _searchText;          set => Set(ref _searchText, value); }
        public string SelectedSearchBy    { get => _selectedSearchBy;    set => Set(ref _selectedSearchBy, value); }
        public string SelectedFilterBy    { get => _selectedFilterBy;    set => Set(ref _selectedFilterBy, value); }
        public string SelectedFilterValue { get => _selectedFilterValue; set => Set(ref _selectedFilterValue, value); }

        public void ClearFilters()
        {
            SearchText = string.Empty;
            SelectedSearchBy = "Name";
            SelectedFilterBy = "None";
            SelectedFilterValue = "All";
        }

        private void Set<T>(ref T f, T v, [CallerMemberName] string p = "")
        {
            if (!Equals(f, v)) { f = v; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p)); }
        }
    }
}

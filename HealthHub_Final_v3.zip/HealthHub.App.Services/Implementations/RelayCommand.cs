using System;
using System.Windows.Input;

namespace HealthHub.App.Services.Implementations
{
    public class RelayCommand : ICommand
    {
        private readonly Action? _execute;
        private readonly Action<object?>? _executeParam;
        private readonly Func<bool>? _canExecute;
        private readonly Func<object?, bool>? _canExecuteParam;

        public event EventHandler? CanExecuteChanged;

        public RelayCommand(Action execute, Func<bool>? canExecute = null)
        {
            _execute    = execute;
            _canExecute = canExecute;
        }

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _executeParam    = execute;
            _canExecuteParam = canExecute;
        }

        public bool CanExecute(object? parameter)
        {
            if (_canExecute != null)      return _canExecute();
            if (_canExecuteParam != null) return _canExecuteParam(parameter);
            return true;
        }

        public void Execute(object? parameter)
        {
            _execute?.Invoke();
            _executeParam?.Invoke(parameter);
        }

        public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}

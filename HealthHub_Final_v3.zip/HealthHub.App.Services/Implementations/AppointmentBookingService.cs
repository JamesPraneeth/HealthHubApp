using System;
using System.Collections.Generic;
using System.Linq;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.App.Services.Implementations
{
    public class AppointmentBookingService : RoomMgmtService, IAppointmentBookingService
    {
        public AppointmentBookingService(
            IAppointmentBookingRepository roomRepo,
            ISurgicalDocumentationRepository logRepo,
            IPatientMgmtService patientService,
            ISurgeonMgmtService surgeonService)
            : base(roomRepo, logRepo, patientService, surgeonService)
        {
        }

        public string BookICUAdmission(HospitalRoom room, ICUAdmission admission)
        {
            if (room.RoomType != "ICU")                                   return "Please select an ICU room.";
            if (string.IsNullOrWhiteSpace(admission.PatientId))           return "Please select a patient.";
            if (admission.StartDate == default)                            return "Please select start date.";
            if (admission.EndDate == default)                              return "Please select end date.";
            if (admission.EndDate.Date < admission.StartDate.Date)         return "End date must be on or after start date.";
            if (room.AvailableICUBeds <= 0)                                return $"ICU full. Maximum capacity: {room.MaxCapacity}.";

            admission.PatientName = ResolvePatientName(admission.PatientId);
            room.ICUPatients.Add(admission);
            SaveRooms();
            return string.Empty;
        }

        public string BookOPDAppointment(HospitalRoom room, OPDAppointment appointment)
        {
            if (room.RoomType != "OPD")                                   return "Please select an OPD room.";
            if (string.IsNullOrWhiteSpace(appointment.PatientId))         return "Please select a patient.";
            if (string.IsNullOrWhiteSpace(appointment.SurgeonId))         return "Please select a physician.";
            if (appointment.Date == default)                               return "Please select a date.";
            if (string.IsNullOrWhiteSpace(appointment.Time))              return "Please enter a time.";
            if (string.IsNullOrWhiteSpace(appointment.Reason))            return "Please enter a reason for visit.";
            if (room.AvailableOPDSlots <= 0)                               return $"OPD full. Maximum capacity: {room.MaxCapacity}.";

            appointment.PatientName   = ResolvePatientName(appointment.PatientId);
            appointment.PhysicianName = ResolveSurgeonName(appointment.SurgeonId);
            room.OPDPatients.Add(appointment);
            SaveRooms();
            return string.Empty;
        }

        public string ScheduleSurgery(HospitalRoom room, OTScheduledSurgery surgery)
        {
            if (room.RoomType != "OT")                                    return "Please select an OT room.";
            if (string.IsNullOrWhiteSpace(surgery.SurgeonId))             return "Please select a primary surgeon.";
            if (string.IsNullOrWhiteSpace(surgery.PatientId))             return "Please select a patient.";
            if (string.IsNullOrWhiteSpace(surgery.ProcedureName))         return "Please select a procedure.";
            if (surgery.SurgeryDate == default)                            return "Please select surgery date.";
            if (surgery.StartDateTime == default || surgery.EndDateTime == default)
                                                                          return "Please select start and end time.";
            if (surgery.EndDateTime <= surgery.StartDateTime)              return "End time must be after start time.";

            bool overlaps = room.OTSurgeries.Any(s =>
                !s.IsCompleted &&
                surgery.StartDateTime < s.EndDateTime &&
                surgery.EndDateTime   > s.StartDateTime);
            if (overlaps) return "This OT already has a surgery scheduled during the selected time.";

            surgery.PatientName        = ResolvePatientName(surgery.PatientId);
            surgery.PrimarySurgeonName = ResolveSurgeonName(surgery.SurgeonId);
            room.OTSurgeries.Add(surgery);
            SaveRooms();
            return string.Empty;
        }

        public void CompleteSurgery(OTScheduledSurgery surgery, SurgicalLog log)
        {
            surgery.IsCompleted = true;
            SaveRooms();

            log.PatientName        = ResolvePatientName(log.PatientId);
            log.PrimarySurgeonName = ResolveSurgeonName(log.SurgeonId);
            SurgicalLogs.Add(log);
            _logRepo.SaveAllLogs(new List<SurgicalLog>(SurgicalLogs));
        }
    }
}

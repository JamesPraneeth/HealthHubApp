using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using HealthHub.App.Services.Interfaces;

namespace HealthHub.App.Services.Implementations
{
    public class DepartmentService : IDepartmentService
    {
        private readonly XDocument _doc;

        private static readonly string FilePath = Path.GetFullPath(
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                         @"..\..\..\..\HealthHub.Domain.Repositories\Data\DepartmentsProcedures.xml"));

        public DepartmentService()
        {
            _doc = File.Exists(FilePath)
                ? XDocument.Load(FilePath)
                : new XDocument(new XElement("DepartmentsProcedures"));
        }

        public List<string> GetDepartments() =>
            _doc.Root!.Elements("Department")
                .Select(d => d.Attribute("name")?.Value ?? string.Empty)
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .OrderBy(n => n)
                .ToList();

        public List<string> GetSpecializations(string department)
        {
            if (string.IsNullOrWhiteSpace(department)) return new List<string>();
            return _doc.Root!.Elements("Department")
                .FirstOrDefault(d => d.Attribute("name")?.Value == department)
                ?.Element("Specializations")?.Elements("Specialization")
                .Select(s => s.Attribute("name")?.Value ?? string.Empty)
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .OrderBy(n => n)
                .ToList() ?? new List<string>();
        }

        public List<string> GetProcedures(string specialization)
        {
            if (string.IsNullOrWhiteSpace(specialization)) return new List<string>();
            return _doc.Root!.Elements("Department")
                .SelectMany(d => d.Element("Specializations")?.Elements("Specialization")
                    ?? Enumerable.Empty<XElement>())
                .FirstOrDefault(s => s.Attribute("name")?.Value == specialization)
                ?.Element("Procedures")?.Elements("Procedure")
                .Select(p => p.Value.Trim())
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .ToList() ?? new List<string>();
        }

        public List<string> GetAllProcedures() =>
            _doc.Root!.Elements("Department")
                .SelectMany(d => d.Element("Specializations")?.Elements("Specialization")
                    ?? Enumerable.Empty<XElement>())
                .SelectMany(s => s.Element("Procedures")?.Elements("Procedure")
                    ?? Enumerable.Empty<XElement>())
                .Select(p => p.Value.Trim())
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .Distinct()
                .OrderBy(n => n)
                .ToList();

        public List<string> GetProceduresForSurgeon(string specialization)
        {
            var list = GetProcedures(specialization);
            return list.Count > 0 ? list : GetAllProcedures();
        }
    }
}

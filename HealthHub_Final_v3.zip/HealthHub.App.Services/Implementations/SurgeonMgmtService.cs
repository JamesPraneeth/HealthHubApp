using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.App.Services.Implementations
{
    public class SurgeonMgmtService : ISurgeonMgmtService
    {
        private readonly ISurgeonRepository _repo;

        public ObservableCollection<Surgeon> Surgeons { get; } = new();

        public event PropertyChangedEventHandler? PropertyChanged;

        private string _searchText = string.Empty;
        private string _selectedSearchBy = "Name";
        private string _selectedFilterBy = "None";
        private string _selectedFilterValue = "All";

        public SurgeonMgmtService(ISurgeonRepository repo)
        {
            _repo = repo;
            foreach (var s in _repo.GetAll())
            {
                s.PropertyChanged += Item_Changed;
                Surgeons.Add(s);
            }
            Surgeons.CollectionChanged += Collection_Changed;
        }

        private void Collection_Changed(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems != null) foreach (Surgeon s in e.OldItems) s.PropertyChanged -= Item_Changed;
            if (e.NewItems != null) foreach (Surgeon s in e.NewItems) s.PropertyChanged += Item_Changed;
            Persist();
        }

        private void Item_Changed(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(Surgeon.IsSelected)) Persist();
        }

        private void Persist() => _repo.SaveAll(new List<Surgeon>(Surgeons));

        public string AddSurgeon(Surgeon surgeon)
        {
            var error = Validate(surgeon);
            if (!string.IsNullOrEmpty(error)) return error;
            Surgeons.Add(surgeon);
            return string.Empty;
        }

        public string UpdateSurgeon(Surgeon surgeon)
        {
            var error = Validate(surgeon);
            if (!string.IsNullOrEmpty(error)) return error;
            Persist();
            return string.Empty;
        }

        public void DeleteSurgeon(Surgeon surgeon) => Surgeons.Remove(surgeon);

        private static string Validate(Surgeon s)
        {
            if (string.IsNullOrWhiteSpace(s.Name))              return "Surgeon Name is required.";
            if (s.Name.Trim().Length <= 1)                       return "Surgeon Name must be more than one character.";
            if (s.Name.Trim().Length > 50)                       return "Surgeon Name cannot exceed 50 characters.";
            if (string.IsNullOrWhiteSpace(s.Department))         return "Department is required.";
            if (string.IsNullOrWhiteSpace(s.Specialization))     return "Specialization is required.";
            if (string.IsNullOrWhiteSpace(s.Experience))         return "Experience is required.";
            if (string.IsNullOrWhiteSpace(s.Email))              return "Email is required.";
            if (!Regex.IsMatch(s.Email.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.IgnoreCase))
                                                                 return "Email must be a valid format.";
            if (string.IsNullOrWhiteSpace(s.ContactNo))          return "Phone Number is required.";
            if (!Regex.IsMatch(s.ContactNo.Trim(), @"^\d{10}$")) return "Phone Number must be exactly 10 digits.";
            return string.Empty;
        }

        public string SearchText          { get => _searchText;          set => Set(ref _searchText, value); }
        public string SelectedSearchBy    { get => _selectedSearchBy;    set => Set(ref _selectedSearchBy, value); }
        public string SelectedFilterBy    { get => _selectedFilterBy;    set => Set(ref _selectedFilterBy, value); }
        public string SelectedFilterValue { get => _selectedFilterValue; set => Set(ref _selectedFilterValue, value); }

        public void ClearFilters()
        {
            SearchText = string.Empty;
            SelectedSearchBy = "Name";
            SelectedFilterBy = "None";
            SelectedFilterValue = "All";
        }

        private void Set<T>(ref T f, T v, [CallerMemberName] string p = "")
        {
            if (!Equals(f, v)) { f = v; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p)); }
        }
    }
}

using System;

namespace HealthHub.App.Services.Implementations
{
    public static class StatusService
    {
        public static event Action<string>? StatusChanged;
        public static void Publish(string message) => StatusChanged?.Invoke(message);
    }
}

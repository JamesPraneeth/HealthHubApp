using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using HealthHub.App.Services.Interfaces;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.App.Services.Implementations
{
    /// <summary>
    /// Loads rooms and surgical logs, resolves PatientId/SurgeonId to display names,
    /// and persists changes. Extended by AppointmentBookingService for booking logic.
    /// </summary>
    public class RoomMgmtService : IRoomMgmtService
    {
        protected readonly IAppointmentBookingRepository _roomRepo;
        protected readonly ISurgicalDocumentationRepository _logRepo;
        protected readonly IPatientMgmtService _patientService;
        protected readonly ISurgeonMgmtService _surgeonService;

        public ObservableCollection<HospitalRoom> Rooms       { get; } = new();
        public ObservableCollection<SurgicalLog>  SurgicalLogs { get; } = new();

        public RoomMgmtService(
            IAppointmentBookingRepository roomRepo,
            ISurgicalDocumentationRepository logRepo,
            IPatientMgmtService patientService,
            ISurgeonMgmtService surgeonService)
        {
            _roomRepo       = roomRepo;
            _logRepo        = logRepo;
            _patientService = patientService;
            _surgeonService = surgeonService;

            foreach (var room in _roomRepo.GetAllRooms())
            {
                ResolveRoomNames(room);
                Rooms.Add(room);
            }

            foreach (var log in _logRepo.GetAllLogs())
            {
                ResolveLogNames(log);
                SurgicalLogs.Add(log);
            }
        }

        public void ResolveRoomNames(HospitalRoom room)
        {
            foreach (var icu in room.ICUPatients)
                icu.PatientName = ResolvePatientName(icu.PatientId);

            foreach (var opd in room.OPDPatients)
            {
                opd.PatientName   = ResolvePatientName(opd.PatientId);
                opd.PhysicianName = ResolveSurgeonName(opd.SurgeonId);
            }

            foreach (var surg in room.OTSurgeries)
            {
                surg.PatientName        = ResolvePatientName(surg.PatientId);
                surg.PrimarySurgeonName = ResolveSurgeonName(surg.SurgeonId);
            }
        }

        protected void ResolveLogNames(SurgicalLog log)
        {
            log.PatientName        = ResolvePatientName(log.PatientId);
            log.PrimarySurgeonName = ResolveSurgeonName(log.SurgeonId);
        }

        protected string ResolvePatientName(string patientId)
            => _patientService.Patients.FirstOrDefault(p => p.PatientId == patientId)?.Name ?? patientId;

        protected string ResolveSurgeonName(string surgeonId)
            => _surgeonService.Surgeons.FirstOrDefault(s => s.SurgeonId == surgeonId)?.Name ?? surgeonId;

        public void SaveRooms()
        {
            _roomRepo.SaveAllRooms(new List<HospitalRoom>(Rooms));
            foreach (var room in Rooms) ResolveRoomNames(room);
        }
    }
}

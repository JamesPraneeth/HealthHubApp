namespace HealthHub.App.Services.Interfaces
{
    public interface IAuthService
    {
        bool RegisterUser(string userId, string password);
        bool ValidateUser(string userId, string password);
    }
}

using System.Collections.ObjectModel;
using HealthHub.Domain.Entities;

namespace HealthHub.App.Services.Interfaces
{
    /// <summary>
    /// Provides access to the room collection and name resolution.
    /// Shared between HomeViewModel and OTViewModel so both read the same
    /// in-memory room objects (HomeViewModel shows live room status,
    /// OTViewModel makes bookings — both must see the same data).
    /// </summary>
    public interface IRoomMgmtService
    {
        ObservableCollection<HospitalRoom> Rooms { get; }
        ObservableCollection<SurgicalLog>  SurgicalLogs { get; }

        /// <summary>Resolves PatientId / SurgeonId → display names on a room's sub-lists.</summary>
        void ResolveRoomNames(HospitalRoom room);

        void SaveRooms();
    }
}

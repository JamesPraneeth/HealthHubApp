using System.Collections.ObjectModel;
using System.ComponentModel;
using HealthHub.Domain.Entities;

namespace HealthHub.App.Services.Interfaces
{
    public interface IPatientMgmtService : INotifyPropertyChanged
    {
        ObservableCollection<Patient> Patients { get; }

        string SearchText          { get; set; }
        string SelectedSearchBy    { get; set; }
        string SelectedFilterBy    { get; set; }
        string SelectedFilterValue { get; set; }

        void ClearFilters();

        /// <summary>Validates and adds a new patient. Returns error message or empty string on success.</summary>
        string AddPatient(Patient patient);

        /// <summary>Validates and updates an existing patient. Returns error message or empty string on success.</summary>
        string UpdatePatient(Patient patient);

        void DeletePatient(Patient patient);
    }
}

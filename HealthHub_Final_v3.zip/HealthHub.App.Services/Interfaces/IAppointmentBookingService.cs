using HealthHub.Domain.Entities;

namespace HealthHub.App.Services.Interfaces
{
    /// <summary>
    /// Handles all booking operations with validation.
    /// ViewModels call these methods instead of manipulating room collections directly.
    /// </summary>
    public interface IAppointmentBookingService : IRoomMgmtService
    {
        /// <summary>Validates and books an ICU admission. Returns error message or empty string on success.</summary>
        string BookICUAdmission(HospitalRoom room, ICUAdmission admission);

        /// <summary>Validates and books an OPD appointment. Returns error message or empty string on success.</summary>
        string BookOPDAppointment(HospitalRoom room, OPDAppointment appointment);

        /// <summary>Validates and schedules an OT surgery. Returns error message or empty string on success.</summary>
        string ScheduleSurgery(HospitalRoom room, OTScheduledSurgery surgery);

        /// <summary>Marks a surgery complete, saves document log, and persists.</summary>
        void CompleteSurgery(OTScheduledSurgery surgery, SurgicalLog log);
    }
}

using System.Collections.Generic;

namespace HealthHub.App.Services.Interfaces
{
    public interface IDepartmentService
    {
        List<string> GetDepartments();
        List<string> GetSpecializations(string department);
        List<string> GetProcedures(string specialization);
        List<string> GetAllProcedures();
        List<string> GetProceduresForSurgeon(string specialization);
    }
}

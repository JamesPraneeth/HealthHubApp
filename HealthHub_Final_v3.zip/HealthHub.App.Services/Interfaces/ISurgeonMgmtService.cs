using System.Collections.ObjectModel;
using System.ComponentModel;
using HealthHub.Domain.Entities;

namespace HealthHub.App.Services.Interfaces
{
    public interface ISurgeonMgmtService : INotifyPropertyChanged
    {
        ObservableCollection<Surgeon> Surgeons { get; }

        string SearchText          { get; set; }
        string SelectedSearchBy    { get; set; }
        string SelectedFilterBy    { get; set; }
        string SelectedFilterValue { get; set; }

        void ClearFilters();

        /// <summary>Validates and adds a new surgeon. Returns error message or empty string on success.</summary>
        string AddSurgeon(Surgeon surgeon);

        /// <summary>Validates and updates an existing surgeon. Returns error message or empty string on success.</summary>
        string UpdateSurgeon(Surgeon surgeon);

        void DeleteSurgeon(Surgeon surgeon);
    }
}

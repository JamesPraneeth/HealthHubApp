using System.Collections.Generic;
using HealthHub.Domain.Entities;

namespace HealthHub.Domain.Repositories.Interfaces
{
    public interface ISurgeonRepository
    {
        List<Surgeon> GetAll();
        void SaveAll(List<Surgeon> surgeons);
    }
}

using System.Collections.Generic;
using HealthHub.Domain.Entities;

namespace HealthHub.Domain.Repositories.Interfaces
{
    public interface ISurgicalDocumentationRepository
    {
        List<SurgicalLog> GetAllLogs();
        void SaveAllLogs(List<SurgicalLog> logs);
    }
}

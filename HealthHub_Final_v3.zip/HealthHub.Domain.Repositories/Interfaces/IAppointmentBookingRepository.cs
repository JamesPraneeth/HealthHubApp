using System.Collections.Generic;
using HealthHub.Domain.Entities;

namespace HealthHub.Domain.Repositories.Interfaces
{
    public interface IAppointmentBookingRepository
    {
        List<HospitalRoom> GetAllRooms();
        void SaveAllRooms(List<HospitalRoom> rooms);
    }
}

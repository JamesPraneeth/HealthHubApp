using System.Collections.Generic;
using HealthHub.Domain.Entities;

namespace HealthHub.Domain.Repositories.Interfaces
{
    public interface IPatientRepository
    {
        List<Patient> GetAll();
        void SaveAll(List<Patient> patients);
    }
}

using System.Collections.Generic;
using HealthHub.Domain.Entities;

namespace HealthHub.Domain.Repositories.Interfaces
{
    public interface IUserRepository
    {
        List<UserAccount> GetAll();
        void SaveAll(List<UserAccount> users);
    }
}

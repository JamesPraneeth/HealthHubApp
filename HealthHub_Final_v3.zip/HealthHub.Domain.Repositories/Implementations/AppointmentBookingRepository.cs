using System.Collections.Generic;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.Domain.Repositories.Implementations
{
    public class AppointmentBookingRepository : XmlRepository<HospitalRoom>, IAppointmentBookingRepository
    {
        public AppointmentBookingRepository() : base("Rooms.xml", "Rooms") { }

        List<HospitalRoom> IAppointmentBookingRepository.GetAllRooms() => LoadAll();
        void IAppointmentBookingRepository.SaveAllRooms(List<HospitalRoom> rooms) => SaveAll(rooms);
    }
}

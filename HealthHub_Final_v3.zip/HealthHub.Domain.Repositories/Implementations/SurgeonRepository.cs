using System.Collections.Generic;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.Domain.Repositories.Implementations
{
    public class SurgeonRepository : XmlRepository<Surgeon>, ISurgeonRepository
    {
        public SurgeonRepository() : base("Surgeons.xml", "Surgeons") { }

        List<Surgeon> ISurgeonRepository.GetAll() => LoadAll();
        void ISurgeonRepository.SaveAll(List<Surgeon> surgeons) => SaveAll(surgeons);
    }
}

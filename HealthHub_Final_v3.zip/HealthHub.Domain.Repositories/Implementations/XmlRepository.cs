using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace HealthHub.Domain.Repositories.Implementations
{
    public abstract class XmlRepository<T> where T : class
    {
        private readonly string _filePath;
        private readonly XmlSerializer _serializer;

        public event Action<string>? Error;

        protected XmlRepository(string fileName, string rootElement)
        {
            // Data folder lives inside the HealthHub.Domain.Repositories project folder.
            // From bin\Debug\net10.0-windows\ go up 4 levels to the solution root,
            // then into HealthHub.Domain.Repositories\Data\.
            string dataDir = Path.GetFullPath(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                             @"..\..\..\..\HealthHub.Domain.Repositories\Data"));
            Directory.CreateDirectory(dataDir);
            _filePath   = Path.Combine(dataDir, fileName);
            _serializer = new XmlSerializer(typeof(List<T>), new XmlRootAttribute(rootElement));
        }

        protected List<T> LoadAll()
        {
            if (!File.Exists(_filePath)) return new List<T>();
            try
            {
                using var stream = new FileStream(_filePath, FileMode.Open, FileAccess.Read);
                return (List<T>?)_serializer.Deserialize(stream) ?? new List<T>();
            }
            catch (Exception ex)
            {
                Error?.Invoke($"Failed to read {Path.GetFileName(_filePath)}.\n\nError: {ex.Message}");
                return new List<T>();
            }
        }

        protected void SaveAll(List<T> items)
        {
            try
            {
                using var stream = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                _serializer.Serialize(stream, items);
            }
            catch (Exception ex)
            {
                Error?.Invoke($"Failed to save {Path.GetFileName(_filePath)}: {ex.Message}");
            }
        }
    }
}

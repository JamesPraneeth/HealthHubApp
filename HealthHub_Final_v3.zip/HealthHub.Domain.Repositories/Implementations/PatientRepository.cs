using System.Collections.Generic;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.Domain.Repositories.Implementations
{
    public class PatientRepository : XmlRepository<Patient>, IPatientRepository
    {
        public PatientRepository() : base("Patients.xml", "Patients") { }

        List<Patient> IPatientRepository.GetAll() => LoadAll();
        void IPatientRepository.SaveAll(List<Patient> patients) => SaveAll(patients);
    }
}

using System.Collections.Generic;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.Domain.Repositories.Implementations
{
    public class SurgicalDocumentationRepository : XmlRepository<SurgicalLog>, ISurgicalDocumentationRepository
    {
        public SurgicalDocumentationRepository() : base("SurgicalLogs.xml", "SurgicalLogs") { }

        List<SurgicalLog> ISurgicalDocumentationRepository.GetAllLogs() => LoadAll();
        void ISurgicalDocumentationRepository.SaveAllLogs(List<SurgicalLog> logs) => SaveAll(logs);
    }
}

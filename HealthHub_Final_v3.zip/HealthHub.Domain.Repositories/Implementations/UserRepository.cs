using System.Collections.Generic;
using HealthHub.Domain.Entities;
using HealthHub.Domain.Repositories.Interfaces;

namespace HealthHub.Domain.Repositories.Implementations
{
    public class UserRepository : XmlRepository<UserAccount>, IUserRepository
    {
        public UserRepository() : base("Users.xml", "Users") { }

        List<UserAccount> IUserRepository.GetAll() => LoadAll();
        void IUserRepository.SaveAll(List<UserAccount> users) => SaveAll(users);
    }
}
